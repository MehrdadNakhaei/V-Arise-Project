import { createFileRoute } from "@tanstack/react-router";
import { AriseApp } from "@/components/arise/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AriseApp />;
}
