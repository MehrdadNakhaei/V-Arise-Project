import { useState } from "react";
import {
  DIFFICULTIES,
  allDungeons,
  runPercent,
  uid,
  type Difficulty,
  type DungeonDef,
  type QuestLink,
  type SaveData,
} from "@/lib/arise/engine";
import { useArise } from "@/lib/arise/store";
import { Panel, SysButton, diffTone } from "./ui";
import { useNow } from "./time";

export function DungeonsScreen({ data }: { data: SaveData }) {
  const openGate = useArise((s) => s.openGate);
  const logObjective = useArise((s) => s.logObjective);
  const logBoss = useArise((s) => s.logBoss);
  const withdrawGate = useArise((s) => s.withdrawGate);
  const forgeGate = useArise((s) => s.forgeGate);
  const deleteGate = useArise((s) => s.deleteGate);
  const [lighter, setLighter] = useState(true);
  const [forging, setForging] = useState(false);
  const now = useNow();
  const run = data.dungeonRun;
  const gates = allDungeons(data);

  return (
    <div className="grid gap-4">
      <div className="relative overflow-hidden">
        <img src="/art/gate.jpg" alt="A circular gate of cyan fire over a dark street" className="h-40 w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-abyss via-abyss/20 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-1">
          <p className="kicker">System // Gates</p>
          <h1 className="display text-3xl">Dungeons</h1>
        </div>
      </div>
      <p className="text-sm text-mist">
        Volume is a ceiling, not a dare. The lighter gate is the default. Recovery seals every door. Log only what you completed.
      </p>

      {run && (
        <Panel>
          <p className="kicker">
            Active · {run.rank}-RANK {run.lighter ? "· lighter" : ""}
          </p>
          <h2 className="display mt-1 text-2xl">{run.name}</h2>
          <p className="mt-1 text-sm text-mist">
            {runPercent(run)}% · {formatClock(Math.floor((now - run.startedAt) / 1000))} · {run.xp} XP
          </p>
          <div className="xp-track mt-3">
            <div className="xp-fill" style={{ transform: `scaleX(${runPercent(run) / 100})` }} />
          </div>
          <div className="mt-4 grid gap-3">
            {run.objectives.map((objective) => (
              <ObjectiveRow
                key={objective.id}
                label={objective.label}
                progress={objective.progress}
                target={objective.target}
                unit={objective.unit}
                done={objective.rewarded}
                onAdd={(delta) => logObjective(objective.id, delta)}
              />
            ))}
            <ObjectiveRow
              label={`${run.bossName} — ${run.bossLabel}`}
              progress={run.bossProgress}
              target={run.bossTarget}
              unit={run.bossUnit}
              done={run.bossRewarded}
              locked={!run.objectives.every((o) => o.progress >= o.target)}
              onAdd={(delta) => logBoss(delta)}
            />
          </div>
          <SysButton variant="danger" className="mt-4" onClick={withdrawGate}>
            Withdraw
          </SysButton>
        </Panel>
      )}

      <label className="flex min-h-11 items-center gap-3 text-sm">
        <input type="checkbox" checked={lighter} onChange={(e) => setLighter(e.target.checked)} />
        Enter on the lighter gate (about half volume, full credit)
      </label>

      <div className="grid gap-3">
        {gates.map((gate) => {
          const record = data.dungeonRecords[gate.id];
          const sealed = !gate.custom && data.player.level < gate.levelRequired;
          return (
            <Panel key={gate.id}>
              <p className={`kicker ${diffTone(gate.rank)}`}>
                {gate.rank}-RANK {sealed ? `· level ${gate.levelRequired}` : ""}
              </p>
              <h2 className="mt-1 text-xl font-semibold">{gate.name}</h2>
              <p className="mt-1 text-sm text-mist">{gate.lore}</p>
              <ul className="mt-3 grid gap-1 text-sm text-ink">
                {gate.objectives.map((objective) => (
                  <li key={objective.id}>{objective.label}</li>
                ))}
                <li>
                  Boss · {gate.bossName}: {gate.bossLabel}
                </li>
              </ul>
              <p className="mt-2 text-sm text-cyan">
                Clear +{gate.clearXp} XP
                {record ? ` · ${record.clears} clear${record.clears === 1 ? "" : "s"}` : ""}
                {record?.bestSec ? ` · best ${formatClock(record.bestSec)}` : ""}
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <SysButton disabled={sealed || Boolean(run) || data.player.recovery} onClick={() => openGate(gate.id, lighter)}>
                  {sealed ? "Sealed" : "Enter"}
                </SysButton>
                {gate.custom && (
                  <SysButton variant="danger" onClick={() => deleteGate(gate.id)}>
                    Delete
                  </SysButton>
                )}
              </div>
            </Panel>
          );
        })}
      </div>

      {forging ? (
        <ForgeForm
          onCancel={() => setForging(false)}
          onSubmit={(def) => {
            forgeGate(def);
            setForging(false);
          }}
        />
      ) : (
        <SysButton variant="ghost" onClick={() => setForging(true)}>
          Forge a gate
        </SysButton>
      )}

      {data.dungeonHistory.length > 0 && (
        <Panel>
          <p className="kicker">History</p>
          <ul className="mt-3 grid gap-2 text-sm">
            {[...data.dungeonHistory].reverse().slice(0, 8).map((row) => (
              <li key={row.id} className="flex justify-between gap-3 border-b border-blue/20 pb-2">
                <span>
                  {row.name} · {row.rank}
                  <span className="text-mist"> {row.cleared ? "cleared" : "withdrew"}</span>
                </span>
                <span className="text-mist">
                  {formatClock(row.sec)} · {row.xp} XP
                </span>
              </li>
            ))}
          </ul>
        </Panel>
      )}
    </div>
  );
}

function ObjectiveRow({
  label,
  progress,
  target,
  unit,
  done,
  locked,
  onAdd,
}: {
  label: string;
  progress: number;
  target: number;
  unit: "reps" | "sec";
  done: boolean;
  locked?: boolean;
  onAdd: (delta: number) => void;
}) {
  const step = unit === "sec" ? 15 : 5;
  return (
    <div className={locked ? "opacity-50" : undefined}>
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm font-semibold">{label}</p>
        <p className="text-sm text-mist">
          {progress}/{target}
          {unit === "sec" ? "s" : ""} {done ? "· cleared" : ""} {locked ? "· sealed" : ""}
        </p>
      </div>
      <div className="xp-track mt-1">
        <div className="xp-fill" style={{ transform: `scaleX(${target ? progress / target : 0})` }} />
      </div>
      <div className="mt-2 flex gap-2">
        <SysButton variant="ghost" className="px-3" disabled={locked} onClick={() => onAdd(-step)}>
          −{step}
        </SysButton>
        <SysButton className="px-3" disabled={locked || done} onClick={() => onAdd(step)}>
          +{step}
        </SysButton>
        <SysButton variant="ghost" disabled={locked || done} onClick={() => onAdd(target - progress)}>
          Finish
        </SysButton>
      </div>
    </div>
  );
}

function ForgeForm({ onSubmit, onCancel }: { onSubmit: (def: DungeonDef) => void; onCancel: () => void }) {
  const [name, setName] = useState("Unnamed Gate");
  const [rank, setRank] = useState<Difficulty>("E");
  const [a, setA] = useState("20 Push-ups");
  const [b, setB] = useState("20 Squats");
  const [boss, setBoss] = useState("Final effort");
  return (
    <form
      className="sys-panel grid gap-3 p-4"
      onSubmit={(event) => {
        event.preventDefault();
        const id = uid("gate");
        onSubmit({
          id,
          name: name.trim().slice(0, 40) || "Unnamed Gate",
          rank,
          levelRequired: 1,
          lore: "A gate you forged. Keep the targets honest.",
          custom: true,
          clearXp: 100,
          bossName: "Warden",
          bossLabel: boss.trim().slice(0, 40) || "Final effort",
          bossTarget: 15,
          bossUnit: "reps",
          bossXp: 40,
          bossLink: null,
          objectives: [
            { id: `${id}-a`, label: a.trim().slice(0, 40) || "Objective A", target: 20, unit: "reps", xp: 30, link: "push" as QuestLink },
            { id: `${id}-b`, label: b.trim().slice(0, 40) || "Objective B", target: 20, unit: "reps", xp: 30, link: "squat" },
          ],
        });
      }}
    >
      <p className="kicker">Forge</p>
      <p className="text-sm text-mist">Two objectives, twenty reps each, and a fifteen-rep boss. Caps stay low on purpose.</p>
      <input className="field" value={name} maxLength={40} onChange={(e) => setName(e.target.value)} aria-label="Gate name" />
      <select className="field" value={rank} onChange={(e) => setRank(e.target.value as Difficulty)} aria-label="Rank">
        {DIFFICULTIES.map((item) => (
          <option key={item}>{item}</option>
        ))}
      </select>
      <input className="field" value={a} maxLength={40} onChange={(e) => setA(e.target.value)} aria-label="First objective" />
      <input className="field" value={b} maxLength={40} onChange={(e) => setB(e.target.value)} aria-label="Second objective" />
      <input className="field" value={boss} maxLength={40} onChange={(e) => setBoss(e.target.value)} aria-label="Boss label" />
      <div className="flex gap-2">
        <SysButton type="submit">Forge</SysButton>
        <SysButton variant="ghost" onClick={onCancel}>
          Cancel
        </SysButton>
      </div>
    </form>
  );
}

function formatClock(total: number) {
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}
