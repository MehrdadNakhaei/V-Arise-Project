import { skillProgress, type SaveData, type SkillBranch } from "@/lib/arise/engine";
import { Panel } from "./ui";
import { Lock } from "lucide-react";

const BRANCHES: SkillBranch[] = ["Strength", "Calisthenics", "Endurance", "Mobility"];

export function SkillsScreen({ data }: { data: SaveData }) {
  const owned = data.skills.filter((skill) => skill.unlockedAt).length;
  return (
    <div className="grid gap-4">
      <div className="relative overflow-hidden">
        <img src="/art/shadows.jpg" alt="" className="h-36 w-full object-cover opacity-70" />
        <div className="absolute inset-0 bg-gradient-to-t from-abyss via-abyss/30 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-1">
          <p className="kicker">System // Skill tree</p>
          <h1 className="display text-3xl">Skills</h1>
        </div>
      </div>
      <p className="text-sm text-mist">
        {owned} / {data.skills.length} acquired. Locked skills open only when the training log crosses the line. No purchase. No shortcut.
      </p>
      {BRANCHES.map((branch) => (
        <section key={branch} className="grid gap-3">
          <h2 className="kicker">{branch}</h2>
          <div className="grid gap-3 md:grid-cols-2">
            {data.skills
              .filter((skill) => skill.branch === branch)
              .map((skill) => {
                const progress = skillProgress(data, skill);
                const unlocked = Boolean(skill.unlockedAt);
                const pct = Math.min(1, progress.current / skill.threshold);
                return (
                  <Panel key={skill.id} className={unlocked ? "border-cyan" : "opacity-80"}>
                    <div className="flex gap-3">
                      <div className="relative h-16 w-16 shrink-0 overflow-hidden border border-blue/40">
                        <img
                          src="/art/shadows.jpg"
                          alt=""
                          className={`h-full w-full object-cover ${unlocked ? "opacity-90" : "opacity-30 grayscale"}`}
                        />
                        {!unlocked && (
                          <span className="absolute inset-0 flex items-center justify-center text-cyan">
                            <Lock size={16} aria-hidden />
                          </span>
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="kicker">{unlocked ? "Acquired" : "Sealed"}</p>
                        <h3 className="text-lg font-semibold">{skill.name}</h3>
                        <p className="text-sm text-mist">{unlocked ? skill.description : skill.requirement}</p>
                      </div>
                    </div>
                    <p className="mt-3 text-sm text-cyan">{progress.label}</p>
                    <div className="xp-track mt-2">
                      <div className="xp-fill" style={{ transform: `scaleX(${pct})` }} />
                    </div>
                  </Panel>
                );
              })}
          </div>
        </section>
      ))}
    </div>
  );
}
