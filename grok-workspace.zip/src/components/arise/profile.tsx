import { useState } from "react";
import {
  nationalGoals,
  rankLabel,
  weekBuckets,
  type SaveData,
} from "@/lib/arise/engine";
import { useArise } from "@/lib/arise/store";
import { Panel, SysButton, rankTone } from "./ui";
import { Area, AreaChart, Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export function ProfileScreen({ data }: { data: SaveData }) {
  const setIdentity = useArise((s) => s.setIdentity);
  const toggleSound = useArise((s) => s.toggleSound);
  const toggleRecovery = useArise((s) => s.toggleRecovery);
  const setRecoveryNote = useArise((s) => s.setRecoveryNote);
  const addMeasure = useArise((s) => s.addMeasure);
  const importSave = useArise((s) => s.importSave);
  const resetAll = useArise((s) => s.resetAll);
  const [name, setName] = useState(data.player.name);
  const [title, setTitle] = useState(data.player.title);
  const [weight, setWeight] = useState("");
  const [sleep, setSleep] = useState("");
  const [fatigue, setFatigue] = useState(2);
  const [soreness, setSoreness] = useState(2);
  const [note, setNote] = useState(data.player.recoveryNote);
  const [importError, setImportError] = useState<string | null>(null);
  const [armed, setArmed] = useState(false);
  const rank = rankLabel(data);
  const buckets = weekBuckets(data.logs);
  const weights = data.measures
    .filter((m) => m.weightKg != null)
    .slice(-12)
    .map((m) => ({
      label: new Date(m.at).toLocaleDateString(undefined, { month: "numeric", day: "numeric" }),
      kg: m.weightKg,
    }));
  const records = data.exercises.filter((exercise) => exercise.prReps > 0 || exercise.prHold > 0);
  const goals = nationalGoals(data);

  return (
    <div className="grid gap-4">
      <div>
        <p className="kicker">System // Profile</p>
        <h1 className="display mt-1 text-3xl">Profile</h1>
      </div>

      <Panel>
        <p className={`kicker ${rankTone(rank.code)}`}>{rank.name}</p>
        <form
          className="mt-3 grid gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            setIdentity(name, title);
          }}
        >
          <label className="grid gap-1 text-sm text-mist">
            Name
            <input className="field" value={name} maxLength={24} onChange={(e) => setName(e.target.value)} />
          </label>
          <label className="grid gap-1 text-sm text-mist">
            Title
            <input className="field" value={title} maxLength={32} onChange={(e) => setTitle(e.target.value)} />
          </label>
          <SysButton type="submit">Update identity</SysButton>
        </form>
        <p className="mt-3 text-sm text-mist">
          Level {data.player.level} · lifetime {data.player.lifetimeXp} XP · {data.player.totalWorkouts} workouts · streak {data.player.streak}
        </p>
      </Panel>

      <Panel>
        <p className="kicker">National level</p>
        <ul className="mt-3 grid gap-2 text-sm">
          {goals.map((goal) => (
            <li key={goal.label} className="flex justify-between gap-3">
              <span className={goal.done ? "text-cyan" : "text-mist"}>{goal.label}</span>
              <span className="text-ink">{goal.done ? "Done" : goal.detail || "Open"}</span>
            </li>
          ))}
        </ul>
      </Panel>

      <Panel>
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="kicker">Recovery</p>
            <p className="mt-1 text-sm text-mist">Pauses gate entry and streak loss. Quests can still be suspended one by one.</p>
          </div>
          <SysButton variant={data.player.recovery ? "legend" : "ghost"} onClick={toggleRecovery}>
            {data.player.recovery ? "Active" : "Off"}
          </SysButton>
        </div>
        <label className="mt-3 grid gap-1 text-sm text-mist">
          Note
          <input
            className="field"
            value={note}
            maxLength={140}
            onChange={(e) => setNote(e.target.value)}
            onBlur={() => setRecoveryNote(note)}
          />
        </label>
      </Panel>

      <Panel>
        <p className="kicker">Body and recovery log</p>
        <form
          className="mt-3 grid gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            const weightKg = weight.trim() === "" ? null : Number(weight);
            const sleepH = sleep.trim() === "" ? null : Number(sleep);
            addMeasure({
              weightKg: weightKg != null && Number.isFinite(weightKg) ? Math.min(400, Math.max(20, weightKg)) : null,
              sleepH: sleepH != null && Number.isFinite(sleepH) ? Math.min(16, Math.max(0, sleepH)) : null,
              fatigue,
              soreness,
              note,
            });
            setWeight("");
            setSleep("");
          }}
        >
          <div className="grid grid-cols-2 gap-2">
            <label className="grid gap-1 text-sm text-mist">
              Weight (kg)
              <input className="field" inputMode="decimal" value={weight} onChange={(e) => setWeight(e.target.value)} />
            </label>
            <label className="grid gap-1 text-sm text-mist">
              Sleep (hours)
              <input className="field" inputMode="decimal" value={sleep} onChange={(e) => setSleep(e.target.value)} />
            </label>
          </div>
          <Range label="Fatigue" value={fatigue} onChange={setFatigue} />
          <Range label="Soreness" value={soreness} onChange={setSoreness} />
          <SysButton type="submit">File measurement</SysButton>
        </form>
        <ul className="mt-4 grid gap-2 text-sm">
          {[...data.measures].reverse().slice(0, 6).map((measure) => (
            <li key={measure.id} className="text-mist">
              {new Date(measure.at).toLocaleDateString()} · {measure.weightKg != null ? `${measure.weightKg} kg` : "no weight"} · sleep {measure.sleepH ?? "—"}h · fatigue {measure.fatigue} · sore {measure.soreness}
            </li>
          ))}
          {data.measures.length === 0 && <li className="text-mist">No measurements yet.</li>}
        </ul>
      </Panel>

      <Panel>
        <p className="kicker">Training minutes · 8 weeks</p>
        <div className="mt-3 h-48">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={buckets}>
              <XAxis dataKey="label" stroke="var(--color-mist)" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="var(--color-mist)" fontSize={12} tickLine={false} axisLine={false} width={28} />
              <Tooltip contentStyle={{ background: "var(--color-panel)", border: "1px solid var(--color-blue)", color: "var(--color-ink)" }} />
              <Area dataKey="minutes" stroke="#63D9FF" fill="#258BFF" fillOpacity={0.25} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Panel>

      <Panel>
        <p className="kicker">Rep volume · 8 weeks</p>
        <div className="mt-3 h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={buckets}>
              <XAxis dataKey="label" stroke="var(--color-mist)" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="var(--color-mist)" fontSize={12} tickLine={false} axisLine={false} width={32} />
              <Tooltip contentStyle={{ background: "var(--color-panel)", border: "1px solid var(--color-blue)", color: "var(--color-ink)" }} />
              <Bar dataKey="reps" fill="#258BFF" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        {data.logs.length === 0 && <p className="mt-2 text-sm text-mist">Charts fill in after the first logged mission.</p>}
      </Panel>

      {weights.length > 1 && (
        <Panel>
          <p className="kicker">Bodyweight</p>
          <div className="mt-3 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weights}>
                <XAxis dataKey="label" stroke="var(--color-mist)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="var(--color-mist)" fontSize={12} tickLine={false} axisLine={false} width={32} domain={["dataMin - 1", "dataMax + 1"]} />
                <Tooltip contentStyle={{ background: "var(--color-panel)", border: "1px solid var(--color-blue)", color: "var(--color-ink)" }} />
                <Area dataKey="kg" stroke="#D6A7FF" fill="#D6A7FF" fillOpacity={0.2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Panel>
      )}

      <Panel>
        <p className="kicker">Personal records</p>
        <ul className="mt-3 grid gap-2 text-sm">
          {records.map((exercise) => (
            <li key={exercise.id} className="flex justify-between gap-3">
              <span>{exercise.name}</span>
              <span className="text-cyan">
                {exercise.prReps > 0 ? `${exercise.prReps} reps` : `${exercise.prHold}s`}
              </span>
            </li>
          ))}
          {records.length === 0 && <li className="text-mist">Records appear when a logged set beats the previous best.</li>}
        </ul>
      </Panel>

      <Panel>
        <p className="kicker">System data</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <SysButton
            variant="ghost"
            onClick={() => {
              const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
              const url = URL.createObjectURL(blob);
              const link = document.createElement("a");
              link.href = url;
              link.download = `arise-${data.daily.date}.json`;
              link.click();
              URL.revokeObjectURL(url);
            }}
          >
            Export
          </SysButton>
          <label className="inline-flex min-h-11 cursor-pointer items-center border border-blue/50 px-4 text-cyan">
            Import
            <input
              type="file"
              accept="application/json"
              className="sr-only"
              onChange={async (event) => {
                const file = event.target.files?.[0];
                event.target.value = "";
                if (!file) return;
                const text = await file.text();
                setImportError(importSave(text));
              }}
            />
          </label>
          <SysButton variant={data.settings.sound ? "primary" : "ghost"} onClick={toggleSound}>
            Sound {data.settings.sound ? "on" : "off"}
          </SysButton>
        </div>
        {importError && <p className="mt-2 text-sm text-danger">{importError}</p>}
        <div className="mt-4">
          {armed ? (
            <div className="flex flex-wrap gap-2">
              <SysButton variant="danger" onClick={resetAll}>
                Confirm wipe
              </SysButton>
              <SysButton variant="ghost" onClick={() => setArmed(false)}>
                Cancel
              </SysButton>
            </div>
          ) : (
            <SysButton variant="danger" onClick={() => setArmed(true)}>
              Reset system
            </SysButton>
          )}
          <p className="mt-2 text-sm text-mist">Reset erases this device's record. Export first if you want it back.</p>
        </div>
      </Panel>
    </div>
  );
}

function Range({ label, value, onChange }: { label: string; value: number; onChange: (n: number) => void }) {
  return (
    <div>
      <div className="flex justify-between text-sm text-mist">
        <span>{label}</span>
        <span className="text-ink">{value}/5</span>
      </div>
      <input className="mt-1 w-full accent-blue" type="range" min={0} max={5} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </div>
  );
}
