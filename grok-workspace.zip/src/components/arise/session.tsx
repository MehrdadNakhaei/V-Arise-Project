import { useEffect, useState } from "react";
import type { SaveData } from "@/lib/arise/engine";
import { useArise } from "@/lib/arise/store";
import { Panel, SysButton, diffTone } from "./ui";
import { useNow } from "./time";

export function SessionScreen({ data }: { data: SaveData }) {
  const session = data.session;
  const now = useNow();
  const logReps = useArise((s) => s.logReps);
  const startHold = useArise((s) => s.startHold);
  const finishHold = useArise((s) => s.finishHold);
  const restSkip = useArise((s) => s.restSkip);
  const restAdjust = useArise((s) => s.restAdjust);
  const skipCurrent = useArise((s) => s.skipCurrent);
  const extractMission = useArise((s) => s.extractMission);
  const [reps, setReps] = useState(10);
  const [showHow, setShowHow] = useState(false);

  const item = session?.items[session.index];
  const doneCount = item?.sets.filter((set) => set.done).length ?? 0;
  useEffect(() => {
    if (item?.mode === "reps") setReps(item.targetReps);
    setShowHow(false);
  }, [item?.exerciseId, item?.mode, item?.targetReps, session?.index, doneCount]);

  if (!session || !item) return null;
  const resting = session.restEndsAt != null && now < session.restEndsAt;
  const restLeft = resting ? Math.ceil((session.restEndsAt! - now) / 1000) : 0;
  const holding = item.holdEndsAt != null && item.holdStartedAt != null;
  const holdLeft = holding ? Math.max(0, Math.ceil((item.holdEndsAt! - now) / 1000)) : item.targetHold;
  const cleared = session.items.filter((row) => row.skipped || row.sets.every((set) => set.done)).length;
  const elapsed = Math.max(0, Math.floor((now - session.startedAt) / 1000));

  return (
    <div className="grid gap-4">
      <p className="kicker">Combat mission</p>
      <div className="flex items-end justify-between gap-3">
        <h1 className="display text-3xl">{session.name}</h1>
        <p className="text-sm text-mist">{formatClock(elapsed)}</p>
      </div>
      <div className="xp-track">
        <div className="xp-fill" style={{ transform: `scaleX(${cleared / session.items.length})` }} />
      </div>
      <p className="text-sm text-mist">
        Target {session.index + 1} / {session.items.length} · {session.xp} XP earned · {session.prs.length ? `Records: ${session.prs.join(", ")}` : "No records yet"}
      </p>

      <Panel>
        <p className={`kicker ${diffTone(item.difficulty)}`}>
          {item.category} · {item.difficulty}-RANK
        </p>
        <h2 className="display mt-2 text-4xl">{item.name}</h2>
        <p className="mt-2 text-mist">
          Set {Math.min(doneCount + 1, item.sets.length)} / {item.sets.length}
          {item.mode === "reps" ? ` · target ${item.targetReps} reps` : ` · target ${item.targetHold}s`}
        </p>
        <div className="mt-3 flex gap-2">
          {item.sets.map((set, i) => (
            <span key={i} className={`h-2 flex-1 ${set.done ? "bg-cyan" : "bg-blue/20"}`} />
          ))}
        </div>

        {resting ? (
          <div className="mt-6 text-center">
            <p className="kicker">Rest</p>
            <p className="display mt-2 text-6xl text-cyan">{restLeft}</p>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              <SysButton variant="ghost" onClick={() => restAdjust(-15)}>
                −15s
              </SysButton>
              <SysButton onClick={restSkip}>Skip rest</SysButton>
              <SysButton variant="ghost" onClick={() => restAdjust(15)}>
                +15s
              </SysButton>
            </div>
          </div>
        ) : item.mode === "reps" ? (
          <form
            className="mt-6 grid gap-3"
            onSubmit={(event) => {
              event.preventDefault();
              logReps(reps);
            }}
          >
            <label className="grid gap-1 text-sm text-mist">
              Reps completed
              <input className="field text-center text-2xl" type="number" min={1} max={80} value={reps} onChange={(e) => setReps(Number(e.target.value))} />
            </label>
            <SysButton type="submit">Set cleared</SysButton>
          </form>
        ) : (
          <div className="mt-6 text-center">
            <p className="kicker">{holding ? "Hold" : "Ready"}</p>
            <p className="display mt-2 text-6xl text-cyan">{holdLeft}</p>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              {!holding ? (
                <SysButton onClick={startHold}>
                  <span>Start hold</span>
                </SysButton>
              ) : (
                <SysButton variant="ghost" onClick={() => finishHold(true)}>
                  End early
                </SysButton>
              )}
            </div>
          </div>
        )}

        <button type="button" className="mt-4 min-h-11 text-sm text-cyan" onClick={() => setShowHow((v) => !v)}>
          {showHow ? "Hide instructions" : "Instructions"}
        </button>
        {showHow && <p className="mt-2 text-sm text-mist">{item.instructions}</p>}
      </Panel>

      <div className="flex flex-wrap gap-2">
        <SysButton variant="ghost" onClick={skipCurrent}>
          Skip exercise
        </SysButton>
        <SysButton variant="danger" onClick={extractMission}>
          Extract
        </SysButton>
      </div>
      <p className="text-sm text-mist">Extract keeps credit for sets already logged. A skipped exercise forfeits the clear bonus.</p>
    </div>
  );
}

function formatClock(total: number) {
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}
