import { useMemo, useState } from "react";
import { CATEGORIES, type Category, type Difficulty, type Exercise, type RoutineItem, type SaveData } from "@/lib/arise/engine";
import { useArise } from "@/lib/arise/store";
import { Panel, SysButton, diffTone } from "./ui";

export function WorkoutScreen({ data }: { data: SaveData }) {
  const startRoutine = useArise((s) => s.startRoutine);
  const startItems = useArise((s) => s.startItems);
  const saveRoutine = useArise((s) => s.saveRoutine);
  const deleteRoutine = useArise((s) => s.deleteRoutine);
  const addExercise = useArise((s) => s.addExercise);
  const deleteExercise = useArise((s) => s.deleteExercise);
  const [filter, setFilter] = useState<Category | "All">("All");
  const [builder, setBuilder] = useState<RoutineItem[]>([]);
  const [routineName, setRoutineName] = useState("Custom mission");
  const [creating, setCreating] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);

  function updateRow(index: number, patch: Partial<RoutineItem>) {
    setBuilder((rows) => rows.map((row, i) => (i === index ? { ...row, ...patch } : row)));
  }

  const exercises = useMemo(
    () => data.exercises.filter((exercise) => filter === "All" || exercise.category === filter),
    [data.exercises, filter],
  );

  function addToBuilder(exercise: Exercise) {
    setBuilder((rows) => [
      ...rows,
      {
        exerciseId: exercise.id,
        sets: exercise.defaultSets,
        reps: exercise.defaultReps,
        hold: exercise.defaultHold,
        rest: exercise.defaultRest,
      },
    ]);
  }

  return (
    <div className="grid w-full min-w-0 max-w-full gap-4 [&>*]:min-w-0 [&>*]:max-w-full">
      <div className="min-w-0 max-w-full">
        <p className="kicker">System // Training</p>
        <h1 className="display mt-1 break-words text-3xl">Workout</h1>
        <p className="mt-2 max-w-full break-words text-sm text-mist">Home training only. Leave a rep in reserve. If a joint speaks, the mission is over.</p>
      </div>

      {builder.length > 0 && (
        <Panel>
          <p className="kicker">Mission builder</p>
          <label className="mt-3 grid gap-1 text-sm text-mist">
            Name
            <input className="field" value={routineName} maxLength={40} onChange={(e) => setRoutineName(e.target.value)} />
          </label>
          <ul className="mt-3 grid gap-2">
            {builder.map((row, index) => {
              const exercise = data.exercises.find((e) => e.id === row.exerciseId);
              return (
                <li key={`${row.exerciseId}-${index}`} className="flex w-full min-w-0 max-w-full flex-wrap items-center gap-2 border border-blue/30 p-2">
                  <span className="min-w-0 flex-1 break-words text-ink">{exercise?.name ?? "Missing"}</span>
                  <Count label="Sets" value={row.sets} min={1} max={8} onChange={(sets) => updateRow(index, { sets })} />
                  {exercise?.mode === "hold" ? (
                    <Count label="Sec" value={row.hold} min={5} max={180} step={5} onChange={(hold) => updateRow(index, { hold })} />
                  ) : (
                    <Count label="Reps" value={row.reps} min={1} max={50} onChange={(reps) => updateRow(index, { reps })} />
                  )}
                  <SysButton variant="ghost" className="px-3" onClick={() => setBuilder((rows) => rows.filter((_, i) => i !== index))}>
                    Remove
                  </SysButton>
                </li>
              );
            })}
          </ul>
          <div className="mt-3 flex flex-wrap gap-2">
            <SysButton onClick={() => startItems(routineName.trim() || "Custom mission", builder)}>Start mission</SysButton>
            <SysButton variant="ghost" onClick={() => saveRoutine(routineName, "Custom", builder)}>
              Save routine
            </SysButton>
            <SysButton variant="danger" onClick={() => setBuilder([])}>
              Clear
            </SysButton>
          </div>
        </Panel>
      )}

      <div className="min-w-0 max-w-full">
        <p className="kicker">Routines</p>
        <div className="mt-3 grid w-full min-w-0 gap-3">
          {data.routines.map((routine) => (
            <Panel key={routine.id} className="flex w-full min-w-0 max-w-full flex-wrap items-center justify-between gap-2 px-3 py-2.5">
              <div className="min-w-0 flex-1">
                <h2 className="break-words text-lg font-semibold leading-tight">{routine.name}</h2>
                <p className="break-words text-sm text-mist">
                  {routine.focus} · {routine.items.length} exercises
                </p>
              </div>
              <div className="flex shrink-0 gap-2">
                <SysButton onClick={() => startRoutine(routine.id)}>Start</SysButton>
                {routine.custom && (
                  <SysButton variant="danger" onClick={() => deleteRoutine(routine.id)}>
                    Delete
                  </SysButton>
                )}
              </div>
            </Panel>
          ))}
        </div>
      </div>

      <div className="min-w-0 max-w-full">
        <p className="kicker">Library</p>
        <div className="mt-3 flex w-full min-w-0 max-w-full gap-2 overflow-x-auto pb-1">
          {(["All", ...CATEGORIES] as const).map((category) => (
            <button
              key={category}
              type="button"
              onClick={() => setFilter(category)}
              className={`min-h-11 shrink-0 border px-3 text-sm ${filter === category ? "border-cyan text-cyan" : "border-blue/40 text-mist"}`}
            >
              {category}
            </button>
          ))}
        </div>
        <div className="mt-3 grid min-w-0 gap-3">
          {exercises.map((exercise) => (
            <Panel key={exercise.id} className="px-3 py-3">
              <div className="flex min-w-0 items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className={`kicker ${diffTone(exercise.difficulty)}`}>
                    {exercise.category} · {exercise.difficulty}
                  </p>
                  <h2 className="mt-1 break-words text-lg font-semibold leading-tight">{exercise.name}</h2>
                  <p className="break-words text-sm text-mist">
                    {exercise.mode === "reps" ? `${exercise.defaultSets} × ${exercise.defaultReps}` : `${exercise.defaultSets} × ${exercise.defaultHold}s`} · +{exercise.xpPerSet} XP / set
                  </p>
                  <p className="text-sm text-cyan">
                    Record {exercise.mode === "reps" ? (exercise.prReps ? `${exercise.prReps} reps` : "none") : exercise.prHold ? `${exercise.prHold}s` : "none"}
                    {exercise.prAt ? ` · ${exercise.prAt}` : ""}
                  </p>
                </div>
              </div>
              {openId === exercise.id && <p className="mt-3 break-words text-sm text-mist">{exercise.instructions}</p>}
              <div className="mt-3 flex flex-wrap gap-2">
                <SysButton onClick={() => startItems(exercise.name, [{ exerciseId: exercise.id, sets: exercise.defaultSets, reps: exercise.defaultReps, hold: exercise.defaultHold, rest: exercise.defaultRest }])}>
                  Start
                </SysButton>
                <SysButton variant="ghost" onClick={() => addToBuilder(exercise)}>
                  Add
                </SysButton>
                <SysButton variant="ghost" onClick={() => setOpenId(openId === exercise.id ? null : exercise.id)}>
                  {openId === exercise.id ? "Hide" : "How"}
                </SysButton>
                {exercise.custom && (
                  <SysButton variant="danger" onClick={() => deleteExercise(exercise.id)}>
                    Delete
                  </SysButton>
                )}
              </div>
            </Panel>
          ))}
        </div>
      </div>

      {creating ? (
        <ExerciseForm
          onCancel={() => setCreating(false)}
          onSubmit={(draft) => {
            addExercise(draft);
            setCreating(false);
          }}
        />
      ) : (
        <SysButton variant="ghost" onClick={() => setCreating(true)}>
          Create exercise
        </SysButton>
      )}
    </div>
  );
}

function Count({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
}) {
  return (
    <span className="inline-flex items-center gap-1 text-sm text-mist">
      {label}
      <button type="button" className="min-h-11 min-w-11 border border-blue/40 text-ink" onClick={() => onChange(Math.max(min, value - step))}>
        −
      </button>
      <span className="w-8 text-center text-ink">{value}</span>
      <button type="button" className="min-h-11 min-w-11 border border-blue/40 text-ink" onClick={() => onChange(Math.min(max, value + step))}>
        +
      </button>
    </span>
  );
}

function ExerciseForm({
  onSubmit,
  onCancel,
}: {
  onSubmit: (exercise: Omit<Exercise, "prReps" | "prHold" | "prAt" | "custom" | "id" | "xpPerSet">) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState("");
  const [category, setCategory] = useState<Category>("Full Body");
  const [mode, setMode] = useState<"reps" | "hold">("reps");
  const [difficulty, setDifficulty] = useState<Difficulty>("E");
  const [link, setLink] = useState<Exercise["link"]>(null);
  const [instructions, setInstructions] = useState("");
  const [sets, setSets] = useState(3);
  const [reps, setReps] = useState(8);
  const [hold, setHold] = useState(30);
  const [rest, setRest] = useState(60);

  return (
    <form
      className="sys-panel grid gap-3 p-4"
      onSubmit={(event) => {
        event.preventDefault();
        onSubmit({
          name,
          category,
          mode,
          link,
          instructions,
          difficulty,
          defaultSets: sets,
          defaultReps: mode === "reps" ? reps : 0,
          defaultHold: mode === "hold" ? hold : 0,
          defaultRest: rest,
        });
      }}
    >
      <p className="kicker">Custom exercise</p>
      <input className="field" placeholder="Name" value={name} maxLength={40} required onChange={(e) => setName(e.target.value)} />
      <div className="grid grid-cols-2 gap-2">
        <select className="field" value={category} onChange={(e) => setCategory(e.target.value as Category)}>
          {CATEGORIES.map((item) => (
            <option key={item}>{item}</option>
          ))}
        </select>
        <select className="field" value={mode} onChange={(e) => setMode(e.target.value as "reps" | "hold")}>
          <option value="reps">Reps</option>
          <option value="hold">Hold</option>
        </select>
        <select className="field" value={difficulty} onChange={(e) => setDifficulty(e.target.value as Difficulty)}>
          {(["E", "D", "C", "B", "A", "S"] as Difficulty[]).map((item) => (
            <option key={item}>{item}</option>
          ))}
        </select>
        <select className="field" value={link ?? ""} onChange={(e) => setLink((e.target.value || null) as Exercise["link"])}>
          <option value="">No quest link</option>
          <option value="push">Push</option>
          <option value="squat">Squat</option>
          <option value="pull">Pull</option>
          <option value="plank">Plank</option>
          <option value="mobility">Mobility</option>
        </select>
      </div>
      <textarea className="field min-h-24" placeholder="Instructions" maxLength={240} value={instructions} onChange={(e) => setInstructions(e.target.value)} />
      <div className="grid grid-cols-3 gap-2">
        <input className="field" type="number" min={1} max={8} value={sets} onChange={(e) => setSets(Number(e.target.value))} aria-label="Sets" />
        {mode === "reps" ? (
          <input className="field" type="number" min={1} max={50} value={reps} onChange={(e) => setReps(Number(e.target.value))} aria-label="Reps" />
        ) : (
          <input className="field" type="number" min={5} max={180} value={hold} onChange={(e) => setHold(Number(e.target.value))} aria-label="Hold seconds" />
        )}
        <input className="field" type="number" min={10} max={180} value={rest} onChange={(e) => setRest(Number(e.target.value))} aria-label="Rest seconds" />
      </div>
      <div className="flex gap-2">
        <SysButton type="submit">Save exercise</SysButton>
        <SysButton variant="ghost" onClick={onCancel}>
          Cancel
        </SysButton>
      </div>
    </form>
  );
}
