import { useEffect, useRef } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Castle, ScrollText, Shield, Sparkles, Swords, UserRound } from "lucide-react";
import { useArise } from "@/lib/arise/store";
import type { Tab } from "@/lib/arise/engine";
import { HomeScreen } from "./home";
import { QuestsScreen } from "./quests";
import { WorkoutScreen } from "./workout";
import { SessionScreen } from "./session";
import { SkillsScreen } from "./skills";
import { DungeonsScreen } from "./dungeons";
import { ProfileScreen } from "./profile";
import { ClockProvider } from "./time";
import { Panel, SysButton } from "./ui";

const TABS: { id: Tab; label: string; icon: typeof Shield }[] = [
  { id: "home", label: "Home", icon: Shield },
  { id: "quests", label: "Quests", icon: ScrollText },
  { id: "workout", label: "Workout", icon: Swords },
  { id: "skills", label: "Skills", icon: Sparkles },
  { id: "dungeons", label: "Dungeons", icon: Castle },
  { id: "profile", label: "Profile", icon: UserRound },
];

export function AriseApp() {
  const ready = useArise((s) => s.ready);
  const boot = useArise((s) => s.boot);
  useEffect(() => {
    void boot();
  }, [boot]);
  if (!ready) return <BootScreen />;
  return (
    <ClockProvider>
      <Shell />
    </ClockProvider>
  );
}

function BootScreen() {
  return (
    <main className="vignette relative flex min-h-dvh items-center justify-center overflow-hidden px-6">
      <div className="boot-scan pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-transparent via-cyan/20 to-transparent" />
      <div className="text-center">
        <p className="kicker">Establishing link</p>
        <h1 className="display mt-3 text-5xl text-ink">ARISE</h1>
        <p className="mt-2 text-mist">The Player System</p>
      </div>
    </main>
  );
}

function Shell() {
  const data = useArise((s) => s.data);
  const tab = useArise((s) => s.tab);
  const setTab = useArise((s) => s.setTab);
  const notices = useArise((s) => s.notices);
  const dismissNotice = useArise((s) => s.dismissNotice);
  const levelUps = useArise((s) => s.levelUps);
  const dismissLevel = useArise((s) => s.dismissLevel);
  const reduce = useReducedMotion();
  const notice = notices[0];
  const level = levelUps[0];
  const inMission = Boolean(data.session);

  useEffect(() => {
    if (!notice) return;
    const id = window.setTimeout(dismissNotice, 3200);
    return () => window.clearTimeout(id);
  }, [notice, dismissNotice]);

  return (
    <div className="vignette min-h-dvh text-ink">
      <Particles />
      <div className="scanlines pointer-events-none fixed inset-0 z-[1]" aria-hidden />
      <div className="mx-auto flex min-h-dvh w-full min-w-0 max-w-5xl md:pl-52">
        <aside className="fixed inset-y-0 left-0 z-20 hidden w-52 flex-col border-r border-blue/30 bg-panel/90 px-3 py-6 md:flex">
          <p className="display px-2 text-xl">ARISE</p>
          <p className="kicker px-2">Player system</p>
          <nav className="mt-8 grid gap-1">
            {TABS.map((item) => (
              <NavButton key={item.id} item={item} active={tab === item.id} onClick={() => setTab(item.id)} />
            ))}
          </nav>
        </aside>
        <main className={`relative z-10 w-full min-w-0 max-w-full px-4 pt-5 ${inMission ? "pb-8" : "pb-28 md:pb-10"}`}>
          <AnimatePresence mode="wait">
            <motion.div
              key={inMission ? "mission" : tab}
              className="w-full min-w-0 max-w-full"
              initial={reduce ? false : { opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={reduce ? undefined : { opacity: 0, y: -8 }}
              transition={{ duration: 0.22 }}
            >
              {inMission ? (
                <SessionScreen data={data} />
              ) : tab === "home" ? (
                <HomeScreen data={data} />
              ) : tab === "quests" ? (
                <QuestsScreen data={data} />
              ) : tab === "workout" ? (
                <WorkoutScreen data={data} />
              ) : tab === "skills" ? (
                <SkillsScreen data={data} />
              ) : tab === "dungeons" ? (
                <DungeonsScreen data={data} />
              ) : (
                <ProfileScreen data={data} />
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {!inMission && (
        <nav className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-blue/30 bg-panel/95 backdrop-blur md:hidden">
          <div className="grid grid-cols-6">
            {TABS.map((item) => (
              <NavButton key={item.id} item={item} active={tab === item.id} compact onClick={() => setTab(item.id)} />
            ))}
          </div>
        </nav>
      )}

      <AnimatePresence>
        {notice && !level && (
          <motion.div
            key={notice.id}
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="fixed inset-x-4 top-4 z-40 mx-auto max-w-md"
          >
            <Panel className="sys-toast">
              <p className="kicker">[ System ]</p>
              <p className="mt-1 text-lg font-semibold">{notice.title}</p>
              <p className="text-sm text-mist">{notice.body}</p>
            </Panel>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {level && (
          <motion.div
            key={level.id}
            initial={reduce ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={reduce ? undefined : { opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-abyss/85 px-6 backdrop-blur-sm"
          >
            {!reduce && (
              <>
                <span className="level-ring" aria-hidden />
                <span className="level-ring late" aria-hidden />
              </>
            )}
            <motion.div
              className="relative w-full max-w-sm"
              initial={reduce ? false : { scale: 0.86, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 260, damping: 22 }}
            >
              <Panel className="text-center">
                <p className="kicker">[ System ]</p>
                <p className="display mt-3 text-5xl text-cyan">Level up</p>
                <p className="display mt-2 text-7xl">{String(level.level).padStart(2, "0")}</p>
                <p className="mt-2 text-legend">{level.rankUp ? `Rank ascended · ${level.rank}` : level.rank}</p>
                <p className="mt-3 text-sm text-mist">3 stat points have been granted. Place them on the status window.</p>
                <SysButton className="mt-5 w-full" onClick={dismissLevel}>
                  Accept
                </SysButton>
              </Panel>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {!data.seenIntro && !inMission && <Intro />}
    </div>
  );
}

function NavButton({
  item,
  active,
  compact,
  onClick,
}: {
  item: (typeof TABS)[number];
  active: boolean;
  compact?: boolean;
  onClick: () => void;
}) {
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={`relative flex min-h-11 items-center gap-2 px-2 py-2 text-xs ${compact ? "flex-col justify-center" : "w-full"} ${active ? "text-cyan" : "text-mist"}`}
    >
      {active && <span className={compact ? "absolute inset-x-3 top-0 h-0.5 bg-cyan" : "absolute inset-y-2 left-0 w-0.5 bg-cyan"} aria-hidden />}
      <Icon size={18} aria-hidden />
      <span>{item.label}</span>
    </button>
  );
}

function Intro() {
  const acceptProtocol = useArise((s) => s.acceptProtocol);
  const dismissIntro = useArise((s) => s.dismissIntro);
  return (
    <div className="fixed inset-0 z-40 overflow-y-auto bg-abyss">
      <img src="/art/hunter.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
      <div className="absolute inset-0 bg-gradient-to-b from-abyss via-abyss/75 to-abyss" />
      <div className="boot-scan pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-transparent via-cyan/30 to-transparent" />
      <div className="relative flex min-h-dvh items-end px-4 py-8 sm:items-center sm:justify-center">
        <div className="w-full max-w-md">
        <p className="kicker">[ System ]</p>
        <h2 className="display mt-3 text-5xl">You have awakened.</h2>
        <p className="mt-3 text-mist">
          The Player System is online. Rank moves only when the work is real. The standard board is 30 push-ups, 40 squats, 10 pull-ups, a 60-second plank, and 10 minutes of mobility.
        </p>
        <p className="mt-2 text-sm text-mist">Choose the volume your body can finish cleanly. Pain is a stop, not a quest.</p>
        <div className="mt-5 grid gap-2">
          <SysButton variant="ghost" onClick={() => acceptProtocol("awakening")}>
            Awakening — lighter
          </SysButton>
          <SysButton onClick={dismissIntro}>Accept standard</SysButton>
          <SysButton variant="legend" onClick={() => acceptProtocol("monarch")}>
            Monarch — harder
          </SysButton>
        </div>
        </div>
      </div>
    </div>
  );
}

function Particles() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dots = Array.from({ length: 36 }, () => ({
      x: Math.random(),
      y: Math.random(),
      r: Math.random() * 1.4 + 0.4,
      s: Math.random() * 0.00025 + 0.00008,
    }));
    let frame = 0;
    const draw = () => {
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }
      ctx.clearRect(0, 0, width, height);
      for (const dot of dots) {
        dot.y -= dot.s;
        if (dot.y < 0) dot.y = 1;
        ctx.beginPath();
        ctx.fillStyle = "rgba(99, 217, 255, 0.26)";
        ctx.arc(dot.x * width, dot.y * height, dot.r, 0, Math.PI * 2);
        ctx.fill();
      }
      frame = window.requestAnimationFrame(draw);
    };
    frame = window.requestAnimationFrame(draw);
    return () => window.cancelAnimationFrame(frame);
  }, []);
  return <canvas ref={ref} className="pointer-events-none fixed inset-0 z-0 h-full w-full" aria-hidden />;
}
