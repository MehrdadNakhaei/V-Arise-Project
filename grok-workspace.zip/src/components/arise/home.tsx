import { STATS, dailyQuestDoneCount, formatProgress, measured, rankLabel, trainingDaysThisWeek, xpNeeded, type SaveData } from "@/lib/arise/engine";
import { useArise } from "@/lib/arise/store";
import { Panel, SysButton, XpBar, rankTone } from "./ui";

export function HomeScreen({ data }: { data: SaveData }) {
  const allocate = useArise((s) => s.allocate);
  const setTab = useArise((s) => s.setTab);
  const rank = rankLabel(data);
  const need = xpNeeded(data.player.level);
  const quests = dailyQuestDoneCount(data);
  const records = measured(data);
  const week = trainingDaysThisWeek(data);
  const level = String(data.player.level).padStart(2, "0");

  return (
    <div className="grid gap-4">
      <header>
        <p className="kicker">[ System ] · Player status</p>
        <h1 className="display mt-1 text-4xl">Status window</h1>
      </header>

      <Panel className="relative w-full max-w-full overflow-hidden p-0">
        <div className="relative h-72 w-full sm:h-80 md:h-[28rem]">
          <img
            src="/art/hunter.jpg"
            alt="A hunter standing in a field of cyan light"
            className="absolute inset-0 h-full w-full object-cover object-[center_22%]"
          />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-abyss via-abyss/30 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-4">
            <div className="min-w-0">
              <p className={`display text-2xl ${rankTone(rank.code)}`}>{rank.name}</p>
              <p className="text-sm text-mist">Level {level}</p>
            </div>
            <span className={`display grid h-14 w-14 shrink-0 place-items-center border border-cyan text-2xl ${rankTone(rank.code)}`} aria-hidden>
              {rank.code}
            </span>
          </div>
        </div>
      </Panel>

      <Panel>
          <p className="kicker">Player information</p>
          <dl className="mt-3">
            <StatusLine label="Name" value={data.player.name} />
            <StatusLine label="Title" value={data.player.title} />
            <StatusLine label="Rank" value={rank.name} tone={rankTone(rank.code)} />
            <StatusLine label="Level" value={level} />
          </dl>
          <div className="mt-4 flex items-end justify-between gap-3">
            <p className="text-sm text-mist">
              EXP {Math.floor(data.player.xp)} / {need}
            </p>
            <p className="text-sm text-cyan">{data.player.points} stat points</p>
          </div>
          <div className="mt-2">
            <XpBar value={data.player.xp} max={need} />
          </div>
          <p className="mt-3 text-sm text-mist">Points are a reward. The numbers under each attribute are what you actually logged.</p>
      </Panel>

      <Panel>
        <p className="kicker">Attributes</p>
        <div className="mt-2">
          {STATS.map((stat) => (
            <div key={stat.key} className="flex min-h-14 items-center gap-2 border-b border-blue/30 py-2 last:border-b-0">
              <p className="kicker w-12 shrink-0">{stat.label}</p>
              <div className="min-w-0 flex-1">
                <p className="truncate text-ink">{stat.name}</p>
                <p className="truncate text-xs text-mist">
                  {stat.blurb} · {records[stat.key]}
                </p>
              </div>
              <p className="display w-8 shrink-0 text-right text-2xl">{data.player.stats[stat.key]}</p>
              <SysButton
                variant="ghost"
                className="min-h-11 min-w-11 shrink-0 px-0"
                disabled={data.player.points <= 0 || data.player.stats[stat.key] >= 99}
                onClick={() => allocate(stat.key)}
                aria-label={`Invest one point in ${stat.name}`}
              >
                +
              </SysButton>
            </div>
          ))}
        </div>
      </Panel>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Metric label="Daily quests" value={data.daily.rest ? "REST" : `${quests.done}/${quests.total || 0}`} detail={quests.claimed ? "Board cleared" : "In progress"} />
        <Metric label="Streak" value={`${data.player.streak}`} detail={`Best ${data.player.longestStreak}`} />
        <Metric label="Workouts" value={`${data.player.totalWorkouts}`} detail="Logged missions" />
        <Metric label="This week" value={`${week}/4`} detail="Training days" />
      </div>

      <Panel>
        <div className="flex items-center justify-between gap-3">
          <p className="kicker">Daily quest</p>
          <SysButton variant="ghost" className="px-3" onClick={() => setTab("quests")}>
            Open board
          </SysButton>
        </div>
        {data.daily.rest ? (
          <p className="mt-3 text-mist">Rest day. The streak holds. Nothing on this board is required.</p>
        ) : (
          <ul className="mt-2">
            {data.daily.quests.map((quest) => {
              const done = quest.rewarded || quest.suspended;
              return (
                <li key={quest.id}>
                  <button type="button" onClick={() => setTab("quests")} className="flex min-h-11 w-full items-center gap-3 text-left">
                    <span className={`h-4 w-4 shrink-0 border ${quest.rewarded ? "border-cyan bg-cyan" : quest.suspended ? "border-legend" : "border-blue"}`} aria-hidden />
                    <span className={`min-w-0 flex-1 truncate ${done ? "text-mist" : "text-ink"}`}>{quest.title}</span>
                    <span className="text-sm text-mist">
                      {quest.suspended ? "Held" : formatProgress(quest.progress, quest.target, quest.unit)}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </Panel>

      {data.player.recovery && (
        <Panel>
          <p className="kicker text-legend">Recovery active</p>
          <p className="mt-2 text-mist">Gates are shut. The streak will not break. Train only if it helps.</p>
          {data.player.recoveryNote && <p className="mt-2 text-ink">{data.player.recoveryNote}</p>}
        </Panel>
      )}
    </div>
  );
}

function StatusLine({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="status-line">
      <dt className="kicker">{label}</dt>
      <dd className={`truncate text-lg font-semibold ${tone ?? "text-ink"}`}>{value}</dd>
    </div>
  );
}

function Metric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <Panel className="p-3">
      <p className="kicker">{label}</p>
      <p className="display mt-2 text-2xl">{value}</p>
      <p className="text-sm text-mist">{detail}</p>
    </Panel>
  );
}
