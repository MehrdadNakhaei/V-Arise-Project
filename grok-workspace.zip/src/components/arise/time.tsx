import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useArise } from "@/lib/arise/store";

interface Clock {
  now: () => number;
  subscribe: (fn: () => void) => () => void;
}

const ClockContext = createContext<Clock | null>(null);

export function ClockProvider({ children }: { children: ReactNode }) {
  const pump = useArise((s) => s.pump);
  const nowRef = useRef(Date.now());
  const subs = useRef(new Set<() => void>());
  const api = useMemo<Clock>(
    () => ({
      now: () => nowRef.current,
      subscribe: (fn) => {
        subs.current.add(fn);
        return () => subs.current.delete(fn);
      },
    }),
    [],
  );

  useEffect(() => {
    const id = window.setInterval(() => {
      nowRef.current = Date.now();
      pump();
      subs.current.forEach((fn) => fn());
    }, 250);
    return () => window.clearInterval(id);
  }, [pump]);

  return <ClockContext.Provider value={api}>{children}</ClockContext.Provider>;
}

export function useNow() {
  const clock = useContext(ClockContext);
  const [now, setNow] = useState(() => clock?.now() ?? Date.now());
  useEffect(() => {
    if (!clock) return;
    return clock.subscribe(() => setNow(clock.now()));
  }, [clock]);
  return now;
}
