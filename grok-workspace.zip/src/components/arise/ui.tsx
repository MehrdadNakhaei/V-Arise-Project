import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/cn";
import type { Difficulty } from "@/lib/arise/engine";

export function Panel({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <section className={cn("sys-panel p-4", className)}>
      <span className="corner tl" />
      <span className="corner tr" />
      <span className="corner bl" />
      <span className="corner br" />
      {children}
    </section>
  );
}

const VARIANTS = {
  primary: "border border-blue bg-blue text-abyss hover:bg-cyan",
  ghost: "border border-blue/50 bg-transparent text-cyan hover:border-cyan",
  danger: "border border-danger/60 bg-transparent text-danger hover:bg-danger/10",
  legend: "border border-legend/50 bg-legend/10 text-legend hover:bg-legend/20",
} as const;

export function SysButton({
  variant = "primary",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: keyof typeof VARIANTS }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 px-4 text-base font-semibold tracking-wide",
        "transition-transform duration-150 ease-out active:scale-[0.96] disabled:cursor-not-allowed disabled:opacity-40 disabled:active:scale-100",
        VARIANTS[variant],
        className,
      )}
      {...props}
    />
  );
}

export function XpBar({ value, max }: { value: number; max: number }) {
  const pct = max <= 0 ? 0 : Math.max(0, Math.min(1, value / max));
  return (
    <div className="xp-track" role="meter" aria-valuenow={Math.round(value)} aria-valuemax={max} aria-label="Experience">
      <div className="xp-fill" style={{ transform: `scaleX(${pct})` }} />
    </div>
  );
}

export function rankTone(code: string) {
  if (code === "N" || code === "S" || code === "A") return "text-legend";
  if (code === "B" || code === "C") return "text-cyan";
  return "text-blue";
}

export function diffTone(d: Difficulty) {
  if (d === "S" || d === "A") return "text-legend";
  if (d === "B" || d === "C") return "text-cyan";
  return "text-blue";
}

export function formatUnit(value: number, unit: "reps" | "sec" | "min") {
  if (unit === "sec") return `${Math.floor(value)}s`;
  if (unit === "min") return `${Math.floor(value)}m`;
  return `${Math.floor(value)}`;
}
