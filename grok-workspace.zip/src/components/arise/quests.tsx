import { useState } from "react";
import {
  DIFFICULTIES,
  weeklyChallenges,
  type Difficulty,
  type Quest,
  type QuestLink,
  type SaveData,
  type Unit,
} from "@/lib/arise/engine";
import { useArise } from "@/lib/arise/store";
import { Panel, SysButton, diffTone, formatUnit } from "./ui";

const LINKS: { id: QuestLink | "none"; label: string }[] = [
  { id: "none", label: "No auto-count" },
  { id: "push", label: "Push-ups" },
  { id: "squat", label: "Squats" },
  { id: "pull", label: "Pulls / rows" },
  { id: "plank", label: "Core holds" },
  { id: "mobility", label: "Mobility" },
];

export function QuestsScreen({ data }: { data: SaveData }) {
  const addQuestProgress = useArise((s) => s.addQuestProgress);
  const suspendQuest = useArise((s) => s.suspendQuest);
  const saveQuest = useArise((s) => s.saveQuest);
  const addQuest = useArise((s) => s.addQuest);
  const deleteQuest = useArise((s) => s.deleteQuest);
  const toggleRest = useArise((s) => s.toggleRest);
  const acceptProtocol = useArise((s) => s.acceptProtocol);
  const claimChallenge = useArise((s) => s.claimChallenge);
  const [editing, setEditing] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const week = weeklyChallenges(data);
  const lockedPreset = data.daily.quests.some((q) => q.rewarded || q.bonus?.rewarded);

  return (
    <div className="grid gap-4">
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="kicker">System // Daily quest</p>
          <h1 className="display mt-1 text-3xl">Quests</h1>
        </div>
        <SysButton variant={data.daily.rest ? "legend" : "ghost"} onClick={toggleRest}>
          {data.daily.rest ? "Resting" : "Rest day"}
        </SysButton>
      </div>
      <p className="text-sm text-mist">
        Pain, illness, or a joint that complains means suspend the quest. A rest day protects the streak. The System will not demand an unsafe volume — edit every target.
      </p>
      {data.daily.rest && (
        <Panel>
          <p className="kicker">Rest day</p>
          <p className="mt-2 text-ink">Nothing is required. Training still counts if you choose it. The daily clear bonus waits.</p>
        </Panel>
      )}

      <div className="grid gap-3">
        {data.daily.quests.map((quest, index) => (
          <QuestCard
            key={quest.id}
            index={index + 1}
            quest={quest}
            editing={editing === quest.id}
            onEdit={() => setEditing(editing === quest.id ? null : quest.id)}
            onProgress={addQuestProgress}
            onSuspend={suspendQuest}
            onSave={(next) => {
              saveQuest(next);
              setEditing(null);
            }}
            onDelete={deleteQuest}
          />
        ))}
      </div>

      {creating ? (
        <QuestForm
          title="New quest"
          initial={{
            id: "new",
            title: "",
            detail: "",
            target: 10,
            unit: "reps",
            progress: 0,
            xp: 25,
            difficulty: "E",
            link: null,
            bonus: null,
            suspended: false,
            rewarded: false,
            custom: true,
          }}
          onCancel={() => setCreating(false)}
          onSubmit={(quest) => {
            addQuest(quest);
            setCreating(false);
          }}
        />
      ) : (
        <SysButton variant="ghost" onClick={() => setCreating(true)}>
          Create quest
        </SysButton>
      )}

      <Panel>
        <p className="kicker">Protocol</p>
        <p className="mt-2 text-sm text-mist">
          {lockedPreset ? "Locked after the first reward today." : "Replace today's board. Progress today is cleared."}
        </p>
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          <SysButton variant="ghost" disabled={lockedPreset} onClick={() => acceptProtocol("awakening")}>
            Awakening
          </SysButton>
          <SysButton variant="ghost" disabled={lockedPreset} onClick={() => acceptProtocol("standard")}>
            Standard
          </SysButton>
          <SysButton variant="legend" disabled={lockedPreset} onClick={() => acceptProtocol("monarch")}>
            Monarch
          </SysButton>
        </div>
      </Panel>

      <div>
        <p className="kicker">Weekly challenges</p>
        <div className="mt-3 grid gap-3">
          {week.map((challenge) => {
            const pct = Math.min(100, Math.round((challenge.progress / challenge.target) * 100));
            return (
              <Panel key={challenge.id}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-semibold">{challenge.title}</h2>
                    <p className="text-sm text-mist">{challenge.detail}</p>
                  </div>
                  <p className="text-cyan">+{challenge.xp} XP</p>
                </div>
                <p className="mt-3 text-sm text-mist">
                  {Math.min(challenge.progress, challenge.target)} / {challenge.target}
                </p>
                <div className="xp-track mt-2">
                  <div className="xp-fill" style={{ transform: `scaleX(${pct / 100})` }} />
                </div>
                <SysButton
                  className="mt-3"
                  disabled={challenge.claimed || challenge.progress < challenge.target}
                  onClick={() => claimChallenge(challenge.id)}
                >
                  {challenge.claimed ? "Claimed" : "Claim reward"}
                </SysButton>
              </Panel>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function QuestCard({
  index,
  quest,
  editing,
  onEdit,
  onProgress,
  onSuspend,
  onSave,
  onDelete,
}: {
  index: number;
  quest: Quest;
  editing: boolean;
  onEdit: () => void;
  onProgress: (id: string, delta: number) => void;
  onSuspend: (id: string) => void;
  onSave: (quest: Quest) => void;
  onDelete: (id: string) => void;
}) {
  const main = Math.min(quest.progress, quest.target);
  const bonusProgress = quest.bonus ? Math.max(0, quest.progress - quest.target) : 0;
  const step = quest.unit === "sec" ? 15 : 1;
  return (
    <Panel className={quest.suspended ? "opacity-60" : undefined}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="kicker">
            {String(index).padStart(2, "0")} · <span className={diffTone(quest.difficulty)}>{quest.difficulty}-RANK</span>
          </p>
          <h2 className="mt-1 text-xl font-semibold">{quest.title}</h2>
          {quest.detail && <p className="mt-1 text-sm text-mist">{quest.detail}</p>}
        </div>
        <p className="shrink-0 text-cyan">+{quest.xp} XP</p>
      </div>
      <p className="mt-3 text-sm text-mist">
        {formatUnit(main, quest.unit)} / {formatUnit(quest.target, quest.unit)}
        {quest.rewarded ? " · cleared" : ""}
        {quest.suspended ? " · suspended" : ""}
      </p>
      <div className="xp-track mt-2">
        <div className="xp-fill" style={{ transform: `scaleX(${quest.target ? main / quest.target : 0})` }} />
      </div>
      {quest.bonus && (
        <p className="mt-2 text-sm text-legend">
          {quest.bonus.title}: {formatUnit(Math.min(bonusProgress, quest.bonus.target), quest.unit)} / {formatUnit(quest.bonus.target, quest.unit)} · +{quest.bonus.xp} XP
        </p>
      )}
      <div className="mt-3 flex flex-wrap gap-2">
        <SysButton variant="ghost" className="min-w-11 px-3" onClick={() => onProgress(quest.id, -step)} aria-label="Decrease progress">
          −
        </SysButton>
        <SysButton className="min-w-11 px-3" onClick={() => onProgress(quest.id, step)} disabled={quest.suspended}>
          +{step}
        </SysButton>
        <SysButton
          variant="ghost"
          disabled={quest.suspended || quest.rewarded}
          onClick={() => onProgress(quest.id, Math.max(0, quest.target - quest.progress))}
        >
          Complete
        </SysButton>
        <SysButton variant="ghost" onClick={() => onSuspend(quest.id)}>
          {quest.suspended ? "Restore" : "Suspend"}
        </SysButton>
        <SysButton variant="ghost" onClick={onEdit}>
          {editing ? "Close" : "Edit"}
        </SysButton>
      </div>
      {editing && <QuestForm className="mt-4" title="Edit quest" initial={quest} submitLabel="Save" onSubmit={onSave} onDelete={() => onDelete(quest.id)} />}
    </Panel>
  );
}

function QuestForm({
  title,
  initial,
  submitLabel = "Add quest",
  onSubmit,
  onCancel,
  onDelete,
  className,
}: {
  title: string;
  initial: Quest;
  submitLabel?: string;
  onSubmit: (quest: Quest) => void;
  onCancel?: () => void;
  onDelete?: () => void;
  className?: string;
}) {
  const [draft, setDraft] = useState(initial);
  const [bonusOn, setBonusOn] = useState(Boolean(initial.bonus));
  return (
    <form
      className={className ? `mt-4 grid gap-3 ${className}` : "sys-panel grid gap-3 p-4"}
      onSubmit={(event) => {
        event.preventDefault();
        onSubmit({
          ...draft,
          title: draft.title.trim() || "Untitled quest",
          bonus: bonusOn
            ? {
                title: draft.bonus?.title?.trim() || "Bonus",
                target: Math.max(1, draft.bonus?.target || 5),
                xp: draft.bonus?.xp || 10,
                rewarded: draft.bonus?.rewarded || false,
              }
            : null,
        });
      }}
    >
      <p className="kicker">{title}</p>
      <label className="grid gap-1 text-sm text-mist">
        Title
        <input className="field" value={draft.title} maxLength={48} onChange={(e) => setDraft({ ...draft, title: e.target.value })} required />
      </label>
      <label className="grid gap-1 text-sm text-mist">
        Note
        <input className="field" value={draft.detail} maxLength={180} onChange={(e) => setDraft({ ...draft, detail: e.target.value })} />
      </label>
      <div className="grid grid-cols-2 gap-2">
        <label className="grid gap-1 text-sm text-mist">
          Target
          <input
            className="field"
            type="number"
            min={1}
            max={draft.unit === "min" ? 45 : draft.unit === "sec" ? 600 : 200}
            value={draft.target}
            onChange={(e) => setDraft({ ...draft, target: Number(e.target.value) })}
          />
        </label>
        <label className="grid gap-1 text-sm text-mist">
          Unit
          <select className="field" value={draft.unit} onChange={(e) => setDraft({ ...draft, unit: e.target.value as Unit })}>
            <option value="reps">Reps</option>
            <option value="sec">Seconds</option>
            <option value="min">Minutes</option>
          </select>
        </label>
        <label className="grid gap-1 text-sm text-mist">
          XP
          <input className="field" type="number" min={5} max={300} value={draft.xp} onChange={(e) => setDraft({ ...draft, xp: Number(e.target.value) })} />
        </label>
        <label className="grid gap-1 text-sm text-mist">
          Rank
          <select className="field" value={draft.difficulty} onChange={(e) => setDraft({ ...draft, difficulty: e.target.value as Difficulty })}>
            {DIFFICULTIES.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </label>
      </div>
      <label className="grid gap-1 text-sm text-mist">
        Counts from training
        <select
          className="field"
          value={draft.link ?? "none"}
          onChange={(e) => setDraft({ ...draft, link: e.target.value === "none" ? null : (e.target.value as QuestLink) })}
        >
          {LINKS.map((link) => (
            <option key={link.id} value={link.id}>
              {link.label}
            </option>
          ))}
        </select>
      </label>
      <label className="flex min-h-11 items-center gap-2 text-sm">
        <input type="checkbox" checked={bonusOn} onChange={(e) => setBonusOn(e.target.checked)} />
        Optional bonus objective
      </label>
      {bonusOn && (
        <div className="grid grid-cols-2 gap-2">
          <input
            className="field col-span-2"
            placeholder="Bonus title"
            value={draft.bonus?.title ?? ""}
            onChange={(e) => setDraft({ ...draft, bonus: { title: e.target.value, target: draft.bonus?.target || 5, xp: draft.bonus?.xp || 10, rewarded: false } })}
          />
          <input
            className="field"
            type="number"
            min={1}
            max={100}
            value={draft.bonus?.target ?? 5}
            onChange={(e) =>
              setDraft({
                ...draft,
                bonus: { title: draft.bonus?.title || "Bonus", target: Number(e.target.value), xp: draft.bonus?.xp || 10, rewarded: false },
              })
            }
          />
          <input
            className="field"
            type="number"
            min={5}
            max={200}
            value={draft.bonus?.xp ?? 10}
            onChange={(e) =>
              setDraft({
                ...draft,
                bonus: { title: draft.bonus?.title || "Bonus", target: draft.bonus?.target || 5, xp: Number(e.target.value), rewarded: false },
              })
            }
          />
        </div>
      )}
      <div className="flex flex-wrap gap-2">
        <SysButton type="submit">{submitLabel}</SysButton>
        {onCancel && (
          <SysButton variant="ghost" onClick={onCancel}>
            Cancel
          </SysButton>
        )}
        {onDelete && (
          <SysButton variant="danger" onClick={onDelete}>
            Delete
          </SysButton>
        )}
      </div>
    </form>
  );
}
