import { create } from "zustand";
import { idbGet, idbSet } from "./db";
import {
  adjustRest,
  applyPreset,
  beginHold,
  buildSession,
  bumpBoss,
  bumpObjective,
  bumpQuest,
  chime,
  claimWeek,
  completeHold,
  createInitial,
  emptyFx,
  endDungeon,
  finishSession,
  freshQuest,
  logRepSet,
  normalize,
  notice,
  pumpSession,
  reconcile,
  recheckDaily,
  skipExercise,
  skipRest,
  startDungeon,
  syncQuestEdit,
  todayKey,
  touch,
  uid,
  xpForDifficulty,
  type Difficulty,
  type DungeonDef,
  type Exercise,
  type Fx,
  type LevelUp,
  type Notice,
  type Quest,
  type RoutineItem,
  type SaveData,
  type StatKey,
  type Tab,
} from "./engine";

interface AriseStore {
  ready: boolean;
  data: SaveData;
  tab: Tab;
  notices: Notice[];
  levelUps: LevelUp[];
  boot: () => Promise<void>;
  pump: () => void;
  dismissNotice: () => void;
  dismissLevel: () => void;
  setTab: (tab: Tab) => void;
  allocate: (stat: StatKey) => void;
  setIdentity: (name: string, title: string) => void;
  toggleSound: () => void;
  toggleRecovery: () => void;
  setRecoveryNote: (note: string) => void;
  toggleRest: () => void;
  addQuestProgress: (id: string, delta: number) => void;
  suspendQuest: (id: string) => void;
  saveQuest: (quest: Quest) => void;
  addQuest: (quest: Quest) => void;
  deleteQuest: (id: string) => void;
  acceptProtocol: (preset: "awakening" | "standard" | "monarch") => void;
  dismissIntro: () => void;
  addExercise: (exercise: Omit<Exercise, "prReps" | "prHold" | "prAt" | "custom" | "id" | "xpPerSet"> & { id?: string }) => void;
  deleteExercise: (id: string) => void;
  startRoutine: (routineId: string) => void;
  startItems: (name: string, items: RoutineItem[]) => void;
  saveRoutine: (name: string, focus: string, items: RoutineItem[]) => void;
  deleteRoutine: (id: string) => void;
  logReps: (reps: number) => void;
  startHold: () => void;
  finishHold: (early: boolean) => void;
  restSkip: () => void;
  restAdjust: (delta: number) => void;
  skipCurrent: () => void;
  extractMission: () => void;
  openGate: (id: string, lighter: boolean) => void;
  logObjective: (id: string, delta: number) => void;
  logBoss: (delta: number) => void;
  withdrawGate: () => void;
  forgeGate: (def: DungeonDef) => void;
  deleteGate: (id: string) => void;
  addMeasure: (measure: { weightKg: number | null; sleepH: number | null; fatigue: number; soreness: number; note: string }) => void;
  claimChallenge: (id: string) => void;
  importSave: (raw: string) => string | null;
  resetAll: () => void;
}

function commit(
  set: (fn: (state: AriseStore) => Partial<AriseStore>) => void,
  get: () => AriseStore,
  mut: (data: SaveData, fx: Fx) => void,
) {
  const fx = emptyFx();
  set((state) => {
    const data = structuredClone(state.data);
    mut(data, fx);
    touch(data, fx);
    return {
      data,
      notices: fx.notices.length ? [...state.notices, ...fx.notices].slice(-5) : state.notices,
      levelUps: fx.levels.length ? [...state.levelUps, ...fx.levels] : state.levelUps,
    };
  });
  const next = get();
  void idbSet(next.data);
  if (next.data.settings.sound && (fx.levels.length > 0 || fx.notices.some((n) => n.chime))) {
    chime(true, fx.levels.length > 0 ? "level" : "quest");
  }
}

export const useArise = create<AriseStore>((set, get) => ({
  ready: false,
  data: createInitial(),
  tab: "home",
  notices: [],
  levelUps: [],
  boot: async () => {
    if (get().ready) return;
    try {
      const saved = await idbGet();
      const data = saved ? normalize(saved) : createInitial();
      reconcile(data);
      set({ data, ready: true });
      await idbSet(data);
    } catch {
      const data = createInitial();
      reconcile(data);
      set({ data, ready: true });
    }
  },
  pump: () => {
    const state = get();
    if (!state.ready) return;
    const session = state.data.session;
    const item = session?.items[session.index];
    const holdDue = Boolean(item?.holdEndsAt && Date.now() >= item.holdEndsAt);
    const dayDue = state.data.daily.date !== todayKey();
    if (!holdDue && !dayDue) return;
    const fx = emptyFx();
    const data = structuredClone(state.data);
    if (holdDue) pumpSession(data, fx);
    if (data.daily.date !== todayKey()) reconcile(data);
    touch(data, fx);
    set({
      data,
      notices: fx.notices.length ? [...state.notices, ...fx.notices].slice(-5) : state.notices,
      levelUps: fx.levels.length ? [...state.levelUps, ...fx.levels] : state.levelUps,
    });
    void idbSet(get().data);
    if (get().data.settings.sound && (fx.levels.length > 0 || fx.notices.some((n) => n.chime))) {
      chime(true, fx.levels.length > 0 ? "level" : "quest");
    }
  },
  dismissNotice: () => set((state) => ({ notices: state.notices.slice(1) })),
  dismissLevel: () => set((state) => ({ levelUps: state.levelUps.slice(1) })),
  setTab: (tab) => set({ tab }),
  allocate: (stat) =>
    commit(set, get, (data, fx) => {
      if (data.player.points <= 0) return;
      if (data.player.stats[stat] >= 99) {
        fx.notices.push(notice("CAP", "That attribute is full."));
        return;
      }
      data.player.points -= 1;
      data.player.stats[stat] += 1;
    }),
  setIdentity: (name, title) =>
    commit(set, get, (data) => {
      data.player.name = name.trim().slice(0, 24) || "THE PLAYER";
      data.player.title = title.trim().slice(0, 32) || "Unknown";
    }),
  toggleSound: () =>
    commit(set, get, (data) => {
      data.settings.sound = !data.settings.sound;
    }),
  toggleRecovery: () =>
    commit(set, get, (data, fx) => {
      data.player.recovery = !data.player.recovery;
      data.player.lastMeaningfulDate = todayKey();
      if (data.player.recovery) {
        data.session = null;
        if (data.dungeonRun) endDungeon(data, fx, false);
        fx.notices.push(notice("RECOVERY", "Quests may be suspended. The streak will hold."));
      } else {
        fx.notices.push(notice("RECOVERY LIFTED", "Train only if you are ready."));
      }
    }),
  setRecoveryNote: (note) =>
    commit(set, get, (data) => {
      data.player.recoveryNote = note.slice(0, 140);
    }),
  toggleRest: () =>
    commit(set, get, (data, fx) => {
      const today = todayKey();
      data.daily.rest = !data.daily.rest;
      if (data.daily.rest) {
        if (!data.restDays.includes(today)) data.restDays.push(today);
        data.player.lastMeaningfulDate = today;
        fx.notices.push(notice("REST DAY", "The streak is protected. Nothing is required."));
      } else {
        data.restDays = data.restDays.filter((day) => day !== today);
        fx.notices.push(notice("REST CANCELLED", "Today is a training day again."));
      }
    }),
  addQuestProgress: (id, delta) => commit(set, get, (data, fx) => bumpQuest(data, id, delta, fx)),
  suspendQuest: (id) =>
    commit(set, get, (data, fx) => {
      const q = data.daily.quests.find((item) => item.id === id);
      if (!q) return;
      q.suspended = !q.suspended;
      recheckDaily(data, fx);
      fx.notices.push(notice(q.suspended ? "QUEST SUSPENDED" : "QUEST RESTORED", q.title));
    }),
  saveQuest: (quest) =>
    commit(set, get, (data, fx) => {
      syncQuestEdit(data, quest);
      recheckDaily(data, fx);
    }),
  addQuest: (quest) =>
    commit(set, get, (data, fx) => {
      if (data.questTemplate.length >= 8) {
        fx.notices.push(notice("LIMIT", "Eight quests is the board's limit."));
        return;
      }
      const next = freshQuest({ ...quest, id: uid("quest"), custom: true });
      data.questTemplate.push(next);
      data.daily.quests.push(freshQuest(next));
    }),
  deleteQuest: (id) =>
    commit(set, get, (data, fx) => {
      if (data.questTemplate.length <= 1) {
        fx.notices.push(notice("LIMIT", "The board needs at least one quest."));
        return;
      }
      data.questTemplate = data.questTemplate.filter((q) => q.id !== id);
      data.daily.quests = data.daily.quests.filter((q) => q.id !== id);
      recheckDaily(data, fx);
    }),
  acceptProtocol: (preset) => commit(set, get, (data, fx) => applyPreset(data, preset, fx)),
  dismissIntro: () =>
    commit(set, get, (data) => {
      data.seenIntro = true;
    }),
  addExercise: (exercise) =>
    commit(set, get, (data, fx) => {
      const difficulty = exercise.difficulty;
      data.exercises.push({
        ...exercise,
        id: uid("ex"),
        name: exercise.name.trim().slice(0, 40) || "Custom exercise",
        instructions: exercise.instructions.trim().slice(0, 240),
        xpPerSet: xpForDifficulty(difficulty as Difficulty),
        prReps: 0,
        prHold: 0,
        prAt: null,
        custom: true,
      });
      fx.notices.push(notice("EXERCISE RECORDED", exercise.name.trim() || "Custom exercise"));
    }),
  deleteExercise: (id) =>
    commit(set, get, (data, fx) => {
      const exercise = data.exercises.find((e) => e.id === id);
      if (!exercise?.custom) return;
      if (data.session?.items.some((item) => item.exerciseId === id)) {
        fx.notices.push(notice("IN USE", "Extract from the open mission first."));
        return;
      }
      data.exercises = data.exercises.filter((e) => e.id !== id);
      data.routines = data.routines
        .map((routine) => ({ ...routine, items: routine.items.filter((item) => item.exerciseId !== id) }))
        .filter((routine) => !routine.custom || routine.items.length > 0);
    }),
  startRoutine: (routineId) =>
    commit(set, get, (data, fx) => {
      if (data.session) {
        fx.notices.push(notice("MISSION OPEN", "Extract before starting another."));
        return;
      }
      if (data.dungeonRun) {
        fx.notices.push(notice("GATE OPEN", "Withdraw from the gate before another mission."));
        return;
      }
      const routine = data.routines.find((r) => r.id === routineId);
      if (!routine) return;
      const session = buildSession(data, routine.name, routine.items);
      if (!session) {
        fx.notices.push(notice("EMPTY", "That routine has no available exercises."));
        return;
      }
      data.session = session;
    }),
  startItems: (name, items) =>
    commit(set, get, (data, fx) => {
      if (data.session) {
        fx.notices.push(notice("MISSION OPEN", "Extract before starting another."));
        return;
      }
      if (data.dungeonRun) {
        fx.notices.push(notice("GATE OPEN", "Withdraw from the gate before another mission."));
        return;
      }
      const session = buildSession(data, name, items);
      if (!session) return;
      data.session = session;
    }),
  saveRoutine: (name, focus, items) =>
    commit(set, get, (data, fx) => {
      if (!items.length) return;
      data.routines.push({
        id: uid("routine"),
        name: name.trim().slice(0, 40) || "Custom mission",
        focus: focus.trim().slice(0, 24) || "Custom",
        custom: true,
        items,
      });
      fx.notices.push(notice("ROUTINE SAVED", name.trim() || "Custom mission"));
    }),
  deleteRoutine: (id) =>
    commit(set, get, (data) => {
      data.routines = data.routines.filter((routine) => routine.id !== id || !routine.custom);
    }),
  logReps: (reps) => commit(set, get, (data, fx) => logRepSet(data, reps, fx)),
  startHold: () =>
    commit(set, get, (data) => {
      beginHold(data);
    }),
  finishHold: (early) => commit(set, get, (data, fx) => completeHold(data, fx, early)),
  restSkip: () =>
    commit(set, get, (data) => {
      skipRest(data);
    }),
  restAdjust: (delta) =>
    commit(set, get, (data) => {
      adjustRest(data, delta);
    }),
  skipCurrent: () => commit(set, get, (data, fx) => skipExercise(data, fx)),
  extractMission: () => commit(set, get, (data, fx) => finishSession(data, fx, true)),
  openGate: (id, lighter) => commit(set, get, (data, fx) => startDungeon(data, id, lighter, fx)),
  logObjective: (id, delta) => commit(set, get, (data, fx) => bumpObjective(data, id, delta, fx)),
  logBoss: (delta) => commit(set, get, (data, fx) => bumpBoss(data, delta, fx)),
  withdrawGate: () => commit(set, get, (data, fx) => endDungeon(data, fx, false)),
  forgeGate: (def) =>
    commit(set, get, (data, fx) => {
      if (data.customDungeons.length >= 8) {
        fx.notices.push(notice("LIMIT", "Eight forged gates is enough."));
        return;
      }
      data.customDungeons.push(def);
      fx.notices.push(notice("GATE FORGED", def.name));
    }),
  deleteGate: (id) =>
    commit(set, get, (data, fx) => {
      if (data.dungeonRun?.dungeonId === id) {
        fx.notices.push(notice("IN USE", "Withdraw before deleting this gate."));
        return;
      }
      data.customDungeons = data.customDungeons.filter((d) => d.id !== id);
    }),
  addMeasure: (measure) =>
    commit(set, get, (data, fx) => {
      data.measures.push({
        id: uid("m"),
        at: Date.now(),
        weightKg: measure.weightKg,
        sleepH: measure.sleepH,
        fatigue: measure.fatigue,
        soreness: measure.soreness,
        note: measure.note.slice(0, 140),
      });
      if (measure.sleepH != null && measure.sleepH > 0) {
        data.player.lastMeaningfulDate = todayKey();
      }
      fx.notices.push(notice("RECORD FILED", "Recovery log updated."));
    }),
  claimChallenge: (id) => commit(set, get, (data, fx) => claimWeek(data, id, fx)),
  importSave: (raw) => {
    try {
      const data = normalize(JSON.parse(raw));
      reconcile(data);
      set({ data, notices: [notice("IMPORT COMPLETE", "The System restored your record.")], levelUps: [] });
      void idbSet(data);
      return null;
    } catch {
      return "The System could not read that file.";
    }
  },
  resetAll: () => {
    const data = createInitial();
    data.seenIntro = true;
    set({ data, notices: [notice("SYSTEM RESET", "All progress was erased.")], levelUps: [], tab: "home" });
    void idbSet(data);
  },
}));
