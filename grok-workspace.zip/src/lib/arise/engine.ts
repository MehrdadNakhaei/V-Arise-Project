export type StatKey = "str" | "agi" | "vit" | "end" | "flex" | "disc";
export type Difficulty = "E" | "D" | "C" | "B" | "A" | "S";
export type QuestLink = "push" | "squat" | "pull" | "plank" | "mobility";
export type Unit = "reps" | "sec" | "min";
export type Tab = "home" | "quests" | "workout" | "skills" | "dungeons" | "profile";
export type Category =
  | "Chest"
  | "Back"
  | "Shoulders"
  | "Biceps"
  | "Triceps"
  | "Legs"
  | "Core"
  | "Full Body"
  | "Mobility"
  | "Skills";
export type SkillMetric = "prReps" | "prHold" | "workouts" | "minutes" | "bestSessionMin" | "streak";
export type SkillBranch = "Strength" | "Calisthenics" | "Endurance" | "Mobility";

export interface QuestBonus {
  title: string;
  target: number;
  xp: number;
  rewarded: boolean;
}

export interface Quest {
  id: string;
  title: string;
  detail: string;
  target: number;
  unit: Unit;
  progress: number;
  xp: number;
  difficulty: Difficulty;
  link: QuestLink | null;
  bonus: QuestBonus | null;
  suspended: boolean;
  rewarded: boolean;
  custom: boolean;
}

export interface Exercise {
  id: string;
  name: string;
  category: Category;
  mode: "reps" | "hold";
  link: QuestLink | null;
  instructions: string;
  difficulty: Difficulty;
  xpPerSet: number;
  defaultSets: number;
  defaultReps: number;
  defaultHold: number;
  defaultRest: number;
  prReps: number;
  prHold: number;
  prAt: string | null;
  custom: boolean;
}

export interface RoutineItem {
  exerciseId: string;
  sets: number;
  reps: number;
  hold: number;
  rest: number;
}

export interface Routine {
  id: string;
  name: string;
  focus: string;
  custom: boolean;
  items: RoutineItem[];
}

export interface SessionSet {
  reps: number;
  hold: number;
  done: boolean;
}

export interface SessionItem {
  exerciseId: string;
  name: string;
  category: Category;
  mode: "reps" | "hold";
  link: QuestLink | null;
  instructions: string;
  difficulty: Difficulty;
  xpPerSet: number;
  targetReps: number;
  targetHold: number;
  rest: number;
  sets: SessionSet[];
  skipped: boolean;
  holdEndsAt: number | null;
  holdStartedAt: number | null;
}

export interface Session {
  name: string;
  startedAt: number;
  index: number;
  restEndsAt: number | null;
  items: SessionItem[];
  xp: number;
  prs: string[];
}

export interface LogExercise {
  name: string;
  link: QuestLink | null;
  category: Category;
  reps: number;
  hold: number;
  sets: number;
}

export interface WorkoutLog {
  id: string;
  name: string;
  at: number;
  durationSec: number;
  volumeReps: number;
  volumeHold: number;
  xp: number;
  kind: "workout" | "dungeon";
  exercises: LogExercise[];
  prs: string[];
}

export interface Skill {
  id: string;
  branch: SkillBranch;
  name: string;
  description: string;
  requirement: string;
  metric: SkillMetric;
  exerciseId: string | null;
  threshold: number;
  unlockedAt: string | null;
}

export interface DungeonObjective {
  id: string;
  label: string;
  target: number;
  unit: "reps" | "sec";
  xp: number;
  link: QuestLink | null;
}

export interface DungeonDef {
  id: string;
  name: string;
  rank: Difficulty;
  levelRequired: number;
  lore: string;
  objectives: DungeonObjective[];
  bossName: string;
  bossLabel: string;
  bossTarget: number;
  bossUnit: "reps" | "sec";
  bossXp: number;
  bossLink: QuestLink | null;
  clearXp: number;
  custom: boolean;
}

export interface RunObjective extends DungeonObjective {
  progress: number;
  rewarded: boolean;
}

export interface DungeonRun {
  dungeonId: string;
  name: string;
  rank: Difficulty;
  startedAt: number;
  lighter: boolean;
  objectives: RunObjective[];
  bossName: string;
  bossLabel: string;
  bossTarget: number;
  bossProgress: number;
  bossUnit: "reps" | "sec";
  bossXp: number;
  bossLink: QuestLink | null;
  bossRewarded: boolean;
  clearXp: number;
  xp: number;
}

export interface DungeonRecord {
  clears: number;
  bestSec: number | null;
  lastClear: string | null;
}

export interface DungeonClear {
  id: string;
  dungeonId: string;
  name: string;
  rank: Difficulty;
  at: number;
  sec: number;
  xp: number;
  cleared: boolean;
}

export interface Measure {
  id: string;
  at: number;
  weightKg: number | null;
  sleepH: number | null;
  fatigue: number;
  soreness: number;
  note: string;
}

export interface WeeklyClaim {
  week: string;
  ids: string[];
}

export interface Player {
  name: string;
  title: string;
  level: number;
  xp: number;
  lifetimeXp: number;
  points: number;
  stats: Record<StatKey, number>;
  streak: number;
  longestStreak: number;
  lastTrainingDate: string | null;
  lastMeaningfulDate: string | null;
  totalWorkouts: number;
  recovery: boolean;
  recoveryNote: string;
}

export interface SaveData {
  v: 1;
  player: Player;
  settings: { sound: boolean };
  seenIntro: boolean;
  nationalSeen: boolean;
  questTemplate: Quest[];
  daily: { date: string; rest: boolean; bonusClaimed: boolean; quests: Quest[] };
  exercises: Exercise[];
  routines: Routine[];
  session: Session | null;
  logs: WorkoutLog[];
  skills: Skill[];
  customDungeons: DungeonDef[];
  dungeonRecords: Record<string, DungeonRecord>;
  dungeonHistory: DungeonClear[];
  dungeonRun: DungeonRun | null;
  measures: Measure[];
  weeklyClaims: WeeklyClaim[];
  questDays: string[];
  restDays: string[];
}

export interface Notice {
  id: string;
  title: string;
  body: string;
  chime?: boolean;
}

export interface LevelUp {
  id: string;
  level: number;
  rank: string;
  rankUp: boolean;
}

export interface Fx {
  notices: Notice[];
  levels: LevelUp[];
}

export const STATS: { key: StatKey; label: string; name: string; blurb: string }[] = [
  { key: "str", label: "STR", name: "Strength", blurb: "Force you choose to build." },
  { key: "agi", label: "AGI", name: "Agility", blurb: "Control under speed." },
  { key: "vit", label: "VIT", name: "Vitality", blurb: "How well you recover." },
  { key: "end", label: "END", name: "Endurance", blurb: "How long you can stay." },
  { key: "flex", label: "FLEX", name: "Flexibility", blurb: "Range you can actually use." },
  { key: "disc", label: "DISC", name: "Discipline", blurb: "Showing up again." },
];

const XP_FOR_DIFF: Record<Difficulty, number> = { E: 8, D: 10, C: 14, B: 18, A: 24, S: 30 };

export function uid(prefix = "id"): string {
  const rand =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : Math.random().toString(36).slice(2, 12);
  return `${prefix}-${rand}`;
}

export function emptyFx(): Fx {
  return { notices: [], levels: [] };
}

export function notice(title: string, body: string, chime = false): Notice {
  return { id: uid("n"), title, body, chime };
}

export function todayKey(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function parseDay(key: string): Date {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

export function daysBetween(from: string, to: string): number {
  return Math.round((parseDay(to).getTime() - parseDay(from).getTime()) / 86_400_000);
}

export function weekStartKey(d = new Date()): string {
  const date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const day = date.getDay();
  const diff = day === 0 ? 6 : day - 1;
  date.setDate(date.getDate() - diff);
  return todayKey(date);
}

export function xpNeeded(level: number): number {
  const l = Math.max(1, level);
  return Math.round(100 + (l - 1) * 40 + (l - 1) ** 2 * 8);
}

export function rankForLevel(level: number): { name: string; code: string } {
  if (level >= 71) return { name: "S-RANK", code: "S" };
  if (level >= 51) return { name: "A-RANK", code: "A" };
  if (level >= 36) return { name: "B-RANK", code: "B" };
  if (level >= 21) return { name: "C-RANK", code: "C" };
  if (level >= 11) return { name: "D-RANK", code: "D" };
  return { name: "E-RANK", code: "E" };
}

export function isNational(data: SaveData): boolean {
  const need = ["lsit", "handstand", "front", "back", "planche"];
  const skills = need.every((id) => data.skills.some((s) => s.id === id && s.unlockedAt));
  return data.player.level >= 71 && skills && data.player.totalWorkouts >= 40 && data.player.longestStreak >= 14;
}

export function rankLabel(data: SaveData): { name: string; code: string } {
  if (isNational(data)) return { name: "NATIONAL LEVEL", code: "N" };
  return rankForLevel(data.player.level);
}

export function nationalGoals(data: SaveData) {
  const need = ["lsit", "handstand", "front", "back", "planche"];
  const unlocked = need.filter((id) => data.skills.some((s) => s.id === id && s.unlockedAt)).length;
  return [
    { label: "Reach S-RANK (level 71)", done: data.player.level >= 71 },
    { label: "Acquire all five calisthenics skills", done: unlocked === need.length, detail: `${unlocked}/5` },
    { label: "Log 40 workouts", done: data.player.totalWorkouts >= 40, detail: `${data.player.totalWorkouts}/40` },
    { label: "Hold a 14-day streak", done: data.player.longestStreak >= 14, detail: `${data.player.longestStreak}/14` },
  ];
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function num(v: unknown, fallback: number) {
  return typeof v === "number" && Number.isFinite(v) ? v : fallback;
}

export function grantXp(data: SaveData, amount: number, fx: Fx, reason?: { title: string; body: string; chime?: boolean }) {
  const gain = Math.round(amount);
  if (gain <= 0) return;
  data.player.xp += gain;
  data.player.lifetimeXp += gain;
  if (reason) fx.notices.push(notice(reason.title, reason.body, Boolean(reason.chime)));
  let guard = 0;
  while (data.player.xp >= xpNeeded(data.player.level) && guard++ < 40) {
    data.player.xp -= xpNeeded(data.player.level);
    data.player.level += 1;
    data.player.points += 3;
    const next = rankForLevel(data.player.level);
    const prev = rankForLevel(data.player.level - 1);
    fx.levels.push({
      id: uid("lv"),
      level: data.player.level,
      rank: isNational({ ...data, nationalSeen: true }) ? "NATIONAL LEVEL" : next.name,
      rankUp: next.name !== prev.name,
    });
  }
}

export function reconcileStreak(data: SaveData) {
  if (data.player.recovery) return;
  const last = data.player.lastMeaningfulDate;
  if (!last) return;
  if (daysBetween(last, todayKey()) > 1) data.player.streak = 0;
}

export function markTraining(data: SaveData, fx: Fx) {
  const today = todayKey();
  reconcileStreak(data);
  if (data.player.lastTrainingDate === today) return;
  if (!data.player.recovery) {
    const last = data.player.lastMeaningfulDate;
    if (!last || daysBetween(last, today) > 1) data.player.streak = 1;
    else data.player.streak += 1;
    if (data.player.streak > data.player.longestStreak) data.player.longestStreak = data.player.streak;
    if (data.player.streak >= 3) fx.notices.push(notice("STREAK", `${data.player.streak} consecutive days.`));
  }
  data.player.lastTrainingDate = today;
  data.player.lastMeaningfulDate = today;
}

function questCap(q: Quest) {
  return q.target + (q.bonus?.target ?? 0);
}

export function bumpQuest(data: SaveData, id: string, delta: number, fx: Fx) {
  const q = data.daily.quests.find((item) => item.id === id);
  if (!q || q.suspended || delta === 0) return;
  const next = clamp(q.progress + delta, 0, questCap(q));
  if (q.rewarded && next < q.target) return;
  q.progress = next;
  if (q.progress >= q.target && !q.rewarded) {
    q.rewarded = true;
    grantXp(data, q.xp, fx, { title: "QUEST CLEARED", body: q.title, chime: true });
  }
  if (q.bonus && q.progress >= q.target + q.bonus.target && !q.bonus.rewarded) {
    q.bonus.rewarded = true;
    grantXp(data, q.bonus.xp, fx, { title: "BONUS OBJECTIVE", body: q.bonus.title, chime: true });
  }
  maybeDaily(data, fx);
}

export function applyLink(data: SaveData, link: QuestLink | null, amount: number, unit: Unit, fx: Fx) {
  if (!link || amount <= 0) return;
  const q = data.daily.quests.find((item) => item.link === link && !item.suspended);
  if (!q) return;
  if (q.unit === "reps" && unit !== "reps") return;
  let delta = amount;
  if (q.unit === "min" && unit === "sec") delta = amount / 60;
  if (q.unit === "sec" && unit === "min") delta = amount * 60;
  bumpQuest(data, q.id, delta, fx);
}

export function recheckDaily(data: SaveData, fx: Fx) {
  maybeDaily(data, fx);
}

function maybeDaily(data: SaveData, fx: Fx) {
  if (data.daily.bonusClaimed || data.daily.rest) return;
  const active = data.daily.quests.filter((q) => !q.suspended);
  if (active.length === 0 || !active.every((q) => q.progress >= q.target)) return;
  data.daily.bonusClaimed = true;
  const today = todayKey();
  if (!data.questDays.includes(today)) data.questDays.push(today);
  grantXp(data, 80, fx, {
    title: "DAILY QUEST COMPLETED",
    body: "Rewards have been distributed.",
    chime: true,
  });
  markTraining(data, fx);
}

export function freshQuest(q: Quest): Quest {
  return {
    ...q,
    progress: 0,
    rewarded: false,
    suspended: false,
    bonus: q.bonus ? { ...q.bonus, rewarded: false } : null,
  };
}

export function reconcile(data: SaveData) {
  reconcileStreak(data);
  const today = todayKey();
  if (data.daily.date !== today) {
    data.daily = {
      date: today,
      rest: false,
      bonusClaimed: false,
      quests: data.questTemplate.map(freshQuest),
    };
  }
  if (data.logs.length > 400) data.logs = data.logs.slice(-400);
  if (data.measures.length > 400) data.measures = data.measures.slice(-400);
  if (data.questDays.length > 180) data.questDays = data.questDays.slice(-180);
  if (data.restDays.length > 180) data.restDays = data.restDays.slice(-180);
  if (data.dungeonHistory.length > 60) data.dungeonHistory = data.dungeonHistory.slice(-60);
}

function totalMinutes(data: SaveData) {
  return data.logs.reduce((sum, log) => sum + log.durationSec, 0) / 60;
}

function bestSessionMin(data: SaveData) {
  return data.logs.reduce((max, log) => Math.max(max, log.durationSec / 60), 0);
}

export function skillProgress(data: SaveData, skill: Skill): { current: number; label: string } {
  if (skill.metric === "prReps" || skill.metric === "prHold") {
    const ex = data.exercises.find((e) => e.id === skill.exerciseId);
    const current = skill.metric === "prReps" ? (ex?.prReps ?? 0) : (ex?.prHold ?? 0);
    const unit = skill.metric === "prReps" ? "reps" : "sec";
    return { current, label: `${Math.floor(current)} / ${skill.threshold} ${unit}` };
  }
  if (skill.metric === "workouts") return { current: data.player.totalWorkouts, label: `${data.player.totalWorkouts} / ${skill.threshold} workouts` };
  if (skill.metric === "minutes") {
    const current = Math.floor(totalMinutes(data));
    return { current, label: `${current} / ${skill.threshold} min` };
  }
  if (skill.metric === "bestSessionMin") {
    const current = Math.floor(bestSessionMin(data));
    return { current, label: `${current} / ${skill.threshold} min in one mission` };
  }
  return { current: data.player.longestStreak, label: `${data.player.longestStreak} / ${skill.threshold} day streak` };
}

export function touch(data: SaveData, fx: Fx) {
  for (const skill of data.skills) {
    if (skill.unlockedAt) continue;
    if (skillProgress(data, skill).current + 1e-6 >= skill.threshold) {
      skill.unlockedAt = new Date().toISOString();
      fx.notices.push(notice("SKILL ACQUIRED", skill.name, true));
      grantXp(data, 25, fx);
    }
  }
  if (isNational(data) && !data.nationalSeen) {
    data.nationalSeen = true;
    fx.notices.push(notice("NATIONAL LEVEL", "The System recognizes you.", true));
  }
}

export function measured(data: SaveData): Record<StatKey, string> {
  const pr = (id: string, mode: "reps" | "hold") => {
    const ex = data.exercises.find((e) => e.id === id);
    if (!ex) return "—";
    if (mode === "reps") return ex.prReps > 0 ? String(ex.prReps) : "—";
    return ex.prHold > 0 ? `${ex.prHold}s` : "—";
  };
  const sleep = [...data.measures].reverse().find((m) => m.sleepH != null);
  return {
    str: pr("push-standard", "reps"),
    agi: pr("squat", "reps"),
    vit: sleep?.sleepH != null ? `${sleep.sleepH}h` : "—",
    end: pr("plank", "hold"),
    flex: pr("hamstring-reach", "hold"),
    disc: data.player.longestStreak > 0 ? `${data.player.longestStreak}d` : "—",
  };
}

export interface WeekChallenge {
  id: string;
  title: string;
  detail: string;
  progress: number;
  target: number;
  xp: number;
  claimed: boolean;
}

export function weeklyChallenges(data: SaveData): WeekChallenge[] {
  const week = weekStartKey();
  const start = parseDay(week).getTime();
  const claimed = new Set(data.weeklyClaims.find((w) => w.week === week)?.ids ?? []);
  const logs = data.logs.filter((log) => log.at >= start);
  const days = new Set<string>();
  for (const log of logs) days.add(todayKey(new Date(log.at)));
  for (const day of data.questDays) if (day >= week) days.add(day);
  const push = logs.reduce(
    (sum, log) => sum + log.exercises.reduce((inner, ex) => inner + (ex.link === "push" ? ex.reps : 0), 0),
    0,
  );
  const boards = data.questDays.filter((day) => day >= week).length;
  const best = logs.reduce((max, log) => Math.max(max, log.durationSec / 60), 0);
  return [
    {
      id: "days",
      title: "Train 4 days",
      detail: "A workout log or a cleared daily board.",
      progress: days.size,
      target: 4,
      xp: 120,
      claimed: claimed.has("days"),
    },
    {
      id: "push",
      title: "100 push-ups",
      detail: "Counted from logged sets and cleared gates.",
      progress: Math.round(push),
      target: 100,
      xp: 100,
      claimed: claimed.has("push"),
    },
    {
      id: "boards",
      title: "Clear 3 daily boards",
      detail: "Full daily quest completion.",
      progress: boards,
      target: 3,
      xp: 150,
      claimed: claimed.has("boards"),
    },
    {
      id: "long",
      title: "One 20-minute mission",
      detail: "A single logged session.",
      progress: Math.min(20, Math.floor(best)),
      target: 20,
      xp: 80,
      claimed: claimed.has("long"),
    },
  ];
}

export function weekBuckets(logs: WorkoutLog[]) {
  const start = parseDay(weekStartKey());
  const buckets: { label: string; reps: number; minutes: number }[] = [];
  for (let i = 7; i >= 0; i--) {
    const from = new Date(start);
    from.setDate(from.getDate() - i * 7);
    const to = new Date(from);
    to.setDate(to.getDate() + 7);
    const rows = logs.filter((log) => log.at >= from.getTime() && log.at < to.getTime());
    buckets.push({
      label: `${from.getMonth() + 1}/${from.getDate()}`,
      reps: rows.reduce((sum, log) => sum + log.volumeReps, 0),
      minutes: Math.round(rows.reduce((sum, log) => sum + log.durationSec, 0) / 60),
    });
  }
  return buckets;
}

export function runPercent(run: DungeonRun): number {
  const open = run.objectives.every((o) => o.progress >= o.target);
  const ratios = run.objectives.map((o) => (o.target ? o.progress / o.target : 0));
  if (open) ratios.push(run.bossTarget ? run.bossProgress / run.bossTarget : 0);
  if (!ratios.length) return 0;
  return Math.round((ratios.reduce((a, b) => a + b, 0) / ratios.length) * 100);
}

function scaleTarget(n: number, unit: "reps" | "sec", lighter: boolean) {
  if (!lighter) return n;
  const v = Math.round(n * 0.55);
  return unit === "reps" ? Math.max(8, v) : Math.max(30, v);
}

export function allDungeons(data: SaveData): DungeonDef[] {
  return [...DUNGEONS, ...data.customDungeons];
}

export function chime(enabled: boolean, kind: "level" | "quest") {
  if (!enabled || typeof window === "undefined") return;
  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtx) return;
  try {
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = kind === "level" ? 680 : 496;
    gain.gain.value = 0.035;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.frequency.exponentialRampToValueAtTime(kind === "level" ? 980 : 660, ctx.currentTime + 0.12);
    osc.stop(ctx.currentTime + 0.16);
    osc.onended = () => void ctx.close();
  } catch {
    /* autoplay or audio policy */
  }
}

function quest(
  partial: Pick<Quest, "id" | "title" | "detail" | "target" | "unit" | "xp" | "difficulty" | "link"> & {
    bonus?: { title: string; target: number; xp: number } | null;
  },
): Quest {
  return {
    ...partial,
    progress: 0,
    suspended: false,
    rewarded: false,
    custom: false,
    bonus: partial.bonus ? { ...partial.bonus, rewarded: false } : null,
  };
}

export function standardQuests(): Quest[] {
  return [
    quest({
      id: "push",
      title: "30 Push-ups",
      detail: "Stop the set if your hips collapse or your shoulders hurt.",
      target: 30,
      unit: "reps",
      xp: 40,
      difficulty: "E",
      link: "push",
      bonus: { title: "Bonus +10 push-ups", target: 10, xp: 15 },
    }),
    quest({
      id: "squat",
      title: "40 Squats",
      detail: "Depth you control. Knees track over the toes.",
      target: 40,
      unit: "reps",
      xp: 40,
      difficulty: "E",
      link: "squat",
      bonus: { title: "Bonus +10 squats", target: 10, xp: 15 },
    }),
    quest({
      id: "pull",
      title: "10 Pull-ups",
      detail: "Use Australian rows if you cannot hang yet. Edit the target.",
      target: 10,
      unit: "reps",
      xp: 50,
      difficulty: "D",
      link: "pull",
      bonus: null,
    }),
    quest({
      id: "plank",
      title: "60-second Plank",
      detail: "Ribs down, glutes on. End it if your back starts to sag.",
      target: 60,
      unit: "sec",
      xp: 35,
      difficulty: "E",
      link: "plank",
      bonus: { title: "Bonus +30 seconds", target: 30, xp: 15 },
    }),
    quest({
      id: "mobility",
      title: "10 minutes Mobility",
      detail: "Hips, shoulders, hamstrings. Breathe. Do not force range.",
      target: 10,
      unit: "min",
      xp: 30,
      difficulty: "E",
      link: "mobility",
      bonus: null,
    }),
  ];
}

export function presetQuests(preset: "awakening" | "standard" | "monarch"): Quest[] {
  if (preset === "standard") return standardQuests();
  if (preset === "awakening") {
    return [
      quest({
        id: "push",
        title: "10 Push-ups",
        detail: "Knees or an incline are allowed. Pain is a stop.",
        target: 10,
        unit: "reps",
        xp: 30,
        difficulty: "E",
        link: "push",
        bonus: { title: "Bonus +5", target: 5, xp: 10 },
      }),
      quest({
        id: "squat",
        title: "15 Squats",
        detail: "Sit to a chair if you need a target depth.",
        target: 15,
        unit: "reps",
        xp: 30,
        difficulty: "E",
        link: "squat",
        bonus: null,
      }),
      quest({
        id: "pull",
        title: "8 Australian Rows",
        detail: "A table or bar you trust. Keep the body rigid.",
        target: 8,
        unit: "reps",
        xp: 30,
        difficulty: "E",
        link: "pull",
        bonus: null,
      }),
      quest({
        id: "plank",
        title: "20-second Plank",
        detail: "Short and honest beats a long sag.",
        target: 20,
        unit: "sec",
        xp: 25,
        difficulty: "E",
        link: "plank",
        bonus: null,
      }),
      quest({
        id: "mobility",
        title: "5 minutes Mobility",
        detail: "Easy range only.",
        target: 5,
        unit: "min",
        xp: 25,
        difficulty: "E",
        link: "mobility",
        bonus: null,
      }),
    ];
  }
  return [
    quest({
      id: "push",
      title: "50 Push-ups",
      detail: "Break into sets. Form ends the set, not pride.",
      target: 50,
      unit: "reps",
      xp: 55,
      difficulty: "D",
      link: "push",
      bonus: { title: "Bonus +10", target: 10, xp: 15 },
    }),
    quest({
      id: "squat",
      title: "60 Squats",
      detail: "Leave two reps in reserve.",
      target: 60,
      unit: "reps",
      xp: 55,
      difficulty: "D",
      link: "squat",
      bonus: null,
    }),
    quest({
      id: "pull",
      title: "15 Pull-ups",
      detail: "Rows count if the bar is not available. Edit if needed.",
      target: 15,
      unit: "reps",
      xp: 60,
      difficulty: "C",
      link: "pull",
      bonus: null,
    }),
    quest({
      id: "plank",
      title: "90-second Plank",
      detail: "Split it if one hold is too long.",
      target: 90,
      unit: "sec",
      xp: 45,
      difficulty: "D",
      link: "plank",
      bonus: null,
    }),
    quest({
      id: "mobility",
      title: "15 minutes Mobility",
      detail: "Unhurried. No bouncing into pain.",
      target: 15,
      unit: "min",
      xp: 40,
      difficulty: "D",
      link: "mobility",
      bonus: null,
    }),
  ];
}

function ex(partial: Omit<Exercise, "prReps" | "prHold" | "prAt" | "custom">): Exercise {
  return { ...partial, prReps: 0, prHold: 0, prAt: null, custom: false };
}

const EXERCISES: Exercise[] = [
  ex({ id: "push-standard", name: "Standard Push-ups", category: "Chest", mode: "reps", link: "push", difficulty: "E", xpPerSet: 10, defaultSets: 3, defaultReps: 10, defaultHold: 0, defaultRest: 60, instructions: "Hands under shoulders. Body one line. Chest travels to just above the floor. Full lockout." }),
  ex({ id: "push-diamond", name: "Diamond Push-ups", category: "Triceps", mode: "reps", link: "push", difficulty: "C", xpPerSet: 14, defaultSets: 3, defaultReps: 6, defaultHold: 0, defaultRest: 75, instructions: "Hands together under the chest, thumbs and index fingers forming a diamond. Elbows track back, not flared." }),
  ex({ id: "push-archer", name: "Archer Push-ups", category: "Chest", mode: "reps", link: "push", difficulty: "C", xpPerSet: 16, defaultSets: 3, defaultReps: 4, defaultHold: 0, defaultRest: 80, instructions: "Wide hands. Bend one arm while the other stays mostly straight. Alternate sides. Count a rep per working arm." }),
  ex({ id: "push-pike", name: "Pike Push-ups", category: "Shoulders", mode: "reps", link: "push", difficulty: "C", xpPerSet: 14, defaultSets: 3, defaultReps: 6, defaultHold: 0, defaultRest: 75, instructions: "Hips high, body an inverted V. Lower the crown between the hands. Elevate the feet only when the floor version is easy." }),
  ex({ id: "push-decline", name: "Decline Push-ups", category: "Chest", mode: "reps", link: "push", difficulty: "D", xpPerSet: 12, defaultSets: 3, defaultReps: 8, defaultHold: 0, defaultRest: 70, instructions: "Feet on a low step. Keep the ribs tucked so the low back does not dump." }),
  ex({ id: "pull-up", name: "Pull-ups", category: "Back", mode: "reps", link: "pull", difficulty: "C", xpPerSet: 16, defaultSets: 3, defaultReps: 5, defaultHold: 0, defaultRest: 90, instructions: "Dead hang to chin over the bar. No kipping. Step down if the shoulder complains." }),
  ex({ id: "chin-up", name: "Chin-ups", category: "Biceps", mode: "reps", link: "pull", difficulty: "C", xpPerSet: 16, defaultSets: 3, defaultReps: 5, defaultHold: 0, defaultRest: 90, instructions: "Palms toward you. Same full hang. Elbows drive down, not forward into a shrug." }),
  ex({ id: "row-australian", name: "Australian Rows", category: "Back", mode: "reps", link: "pull", difficulty: "E", xpPerSet: 10, defaultSets: 3, defaultReps: 8, defaultHold: 0, defaultRest: 60, instructions: "Bar or sturdy table at hip height. Body straight, pull the chest to the bar. Walk your feet back to make it harder." }),
  ex({ id: "row-inverted", name: "Inverted Rows", category: "Back", mode: "reps", link: "pull", difficulty: "D", xpPerSet: 12, defaultSets: 3, defaultReps: 8, defaultHold: 0, defaultRest: 70, instructions: "Lower bar than the Australian row, body closer to the floor. Pause at the chest." }),
  ex({ id: "squat", name: "Squats", category: "Legs", mode: "reps", link: "squat", difficulty: "E", xpPerSet: 10, defaultSets: 3, defaultReps: 15, defaultHold: 0, defaultRest: 60, instructions: "Feet about shoulder width. Sit between the hips. Heels stay down. Stand tall without locking hard." }),
  ex({ id: "split-squat", name: "Bulgarian Split Squats", category: "Legs", mode: "reps", link: "squat", difficulty: "D", xpPerSet: 14, defaultSets: 3, defaultReps: 6, defaultHold: 0, defaultRest: 70, instructions: "Rear foot on a low bench. Short stance. Front knee tracks the toes. Count reps per leg, then switch." }),
  ex({ id: "lunge", name: "Lunges", category: "Legs", mode: "reps", link: "squat", difficulty: "E", xpPerSet: 10, defaultSets: 3, defaultReps: 8, defaultHold: 0, defaultRest: 60, instructions: "Step long enough that the back knee lowers under the hip. Torso tall. Alternate or complete one side." }),
  ex({ id: "pistol", name: "Pistol Squats", category: "Legs", mode: "reps", link: "squat", difficulty: "A", xpPerSet: 22, defaultSets: 3, defaultReps: 3, defaultHold: 0, defaultRest: 90, instructions: "Hold a support. Free leg forward. Only go as deep as the knee allows. Pain in the joint means regress to a box pistol." }),
  ex({ id: "nordic", name: "Nordic Curls", category: "Legs", mode: "reps", link: null, difficulty: "A", xpPerSet: 20, defaultSets: 3, defaultReps: 3, defaultHold: 0, defaultRest: 90, instructions: "Anchor the ankles safely. Lower as slowly as you can and push back up with your hands. Skip if the knee is irritated." }),
  ex({ id: "plank", name: "Plank", category: "Core", mode: "hold", link: "plank", difficulty: "E", xpPerSet: 10, defaultSets: 3, defaultReps: 0, defaultHold: 30, defaultRest: 45, instructions: "Forearms down, pelvis slightly tucked, neck long. End the hold when the back sags." }),
  ex({ id: "hollow", name: "Hollow Body Hold", category: "Core", mode: "hold", link: "plank", difficulty: "D", xpPerSet: 12, defaultSets: 3, defaultReps: 0, defaultHold: 20, defaultRest: 45, instructions: "Low back pressed into the floor. Arms and legs long. Bend the knees if the back peels up." }),
  ex({ id: "lsit", name: "L-Sit", category: "Skills", mode: "hold", link: null, difficulty: "B", xpPerSet: 18, defaultSets: 3, defaultReps: 0, defaultHold: 10, defaultRest: 75, instructions: "Hands beside the hips, fingers forward. Lift the feet. Tuck the knees if a full L is not there yet. Log the honest variation." }),
  ex({ id: "leg-raise", name: "Leg Raises", category: "Core", mode: "reps", link: null, difficulty: "D", xpPerSet: 12, defaultSets: 3, defaultReps: 8, defaultHold: 0, defaultRest: 50, instructions: "Lying or hanging. Low back stays quiet. Lower only as far as you can keep it there." }),
  ex({ id: "sit-up", name: "Sit-ups", category: "Core", mode: "reps", link: null, difficulty: "E", xpPerSet: 8, defaultSets: 3, defaultReps: 10, defaultHold: 0, defaultRest: 45, instructions: "Feet free or lightly anchored. Do not yank the neck. A crunch is enough if a full sit-up bothers the back." }),
  ex({ id: "handstand", name: "Handstand", category: "Skills", mode: "hold", link: null, difficulty: "B", xpPerSet: 18, defaultSets: 4, defaultReps: 0, defaultHold: 15, defaultRest: 70, instructions: "Face a wall. Kick up with control. Bail by stepping down, not crashing. Chest-to-wall is the cleaner version." }),
  ex({ id: "front-lever", name: "Front Lever", category: "Skills", mode: "hold", link: null, difficulty: "A", xpPerSet: 22, defaultSets: 3, defaultReps: 0, defaultHold: 8, defaultRest: 90, instructions: "Tuck, advanced tuck, or one-leg. Hips level with shoulders. A short clean tuck outranks a sagging full lever." }),
  ex({ id: "back-lever", name: "Back Lever", category: "Skills", mode: "hold", link: null, difficulty: "A", xpPerSet: 22, defaultSets: 3, defaultReps: 0, defaultHold: 8, defaultRest: 90, instructions: "Rings or bar. Tuck first. Shoulders stay depressed. Stop at any sharp front-shoulder pain." }),
  ex({ id: "planche", name: "Planche", category: "Skills", mode: "hold", link: null, difficulty: "S", xpPerSet: 24, defaultSets: 3, defaultReps: 0, defaultHold: 8, defaultRest: 90, instructions: "Lean forward in a planche lean or tuck planche. Protract the shoulders. Wrists warm. Stop if they ache." }),
  ex({ id: "hspu", name: "Handstand Push-ups", category: "Shoulders", mode: "reps", link: null, difficulty: "A", xpPerSet: 22, defaultSets: 3, defaultReps: 3, defaultHold: 0, defaultRest: 90, instructions: "Wall behind you. Head to a pad, not the bare floor, until you own the range. Partial range counts if you log it honestly." }),
  ex({ id: "hip-openers", name: "Hip Openers", category: "Mobility", mode: "hold", link: "mobility", difficulty: "E", xpPerSet: 8, defaultSets: 2, defaultReps: 0, defaultHold: 60, defaultRest: 20, instructions: "Half-kneeling hip flexor. Tuck the pelvis. A gentle stretch, not a shove. 60 calm seconds." }),
  ex({ id: "shoulder-circles", name: "Shoulder Circles", category: "Mobility", mode: "hold", link: "mobility", difficulty: "E", xpPerSet: 8, defaultSets: 2, defaultReps: 0, defaultHold: 60, defaultRest: 20, instructions: "Slow arm circles and a light sleeper or doorway chest opener. No pinching. Log the time you spent moving well." }),
  ex({ id: "hamstring-reach", name: "Hamstring Reach", category: "Mobility", mode: "hold", link: "mobility", difficulty: "E", xpPerSet: 8, defaultSets: 2, defaultReps: 0, defaultHold: 60, defaultRest: 20, instructions: "One leg long, hinge from the hips with a flat back. Reach until strong tension, never nerve pain." }),
  ex({ id: "wgs", name: "World's Greatest Stretch", category: "Mobility", mode: "reps", link: "mobility", difficulty: "E", xpPerSet: 8, defaultSets: 2, defaultReps: 5, defaultHold: 0, defaultRest: 20, instructions: "Deep lunge, elbow toward the instep, rotate the chest open. Slow reps. Each rep is one side." }),
  ex({ id: "squat-thrust", name: "Squat Thrusts", category: "Full Body", mode: "reps", link: null, difficulty: "D", xpPerSet: 14, defaultSets: 3, defaultReps: 8, defaultHold: 0, defaultRest: 60, instructions: "Squat, step or jump the feet back to a plank, return, stand. Step back if impact is unwelcome. No flopping the hips." }),
];

function skill(
  partial: Omit<Skill, "unlockedAt">,
): Skill {
  return { ...partial, unlockedAt: null };
}

const SKILLS: Skill[] = [
  skill({ id: "push-mastery", branch: "Strength", name: "Push-up Mastery", description: "A single clean set of thirty. The floor stopped being an excuse.", requirement: "30 standard push-ups in one logged set.", metric: "prReps", exerciseId: "push-standard", threshold: 30 }),
  skill({ id: "pull-mastery", branch: "Strength", name: "Pull-up Mastery", description: "Chin over the bar, eight times, without a kip.", requirement: "8 pull-ups in one logged set.", metric: "prReps", exerciseId: "pull-up", threshold: 8 }),
  skill({ id: "explosive", branch: "Strength", name: "Explosive Strength", description: "The diamond variation yields. Triceps and chest agree.", requirement: "15 diamond push-ups in one logged set.", metric: "prReps", exerciseId: "push-diamond", threshold: 15 }),
  skill({ id: "lsit", branch: "Calisthenics", name: "L-Sit", description: "The body leaves the floor and holds a line.", requirement: "Hold an L-sit, tuck allowed, for 15 seconds.", metric: "prHold", exerciseId: "lsit", threshold: 15 }),
  skill({ id: "handstand", branch: "Calisthenics", name: "Handstand", description: "Balance becomes a place you can stand.", requirement: "Hold a handstand for 20 seconds.", metric: "prHold", exerciseId: "handstand", threshold: 20 }),
  skill({ id: "front", branch: "Calisthenics", name: "Front Lever", description: "A straight line facing the sky. Tuck counts.", requirement: "Hold a front lever variation for 10 seconds.", metric: "prHold", exerciseId: "front-lever", threshold: 10 }),
  skill({ id: "back", branch: "Calisthenics", name: "Back Lever", description: "Shoulders open. The body hangs behind the hands.", requirement: "Hold a back lever variation for 10 seconds.", metric: "prHold", exerciseId: "back-lever", threshold: 10 }),
  skill({ id: "planche", branch: "Calisthenics", name: "Planche", description: "Weight shifts forward until the feet no longer matter.", requirement: "Hold a planche lean or tuck for 10 seconds.", metric: "prHold", exerciseId: "planche", threshold: 10 }),
  skill({ id: "conditioning", branch: "Endurance", name: "Conditioning", description: "Work stops feeling like an event and starts feeling like weather.", requirement: "Log 120 total training minutes.", metric: "minutes", exerciseId: null, threshold: 120 }),
  skill({ id: "capacity", branch: "Endurance", name: "Work Capacity", description: "You return often enough that the System expects you.", requirement: "Finish 12 meaningful workouts.", metric: "workouts", exerciseId: null, threshold: 12 }),
  skill({ id: "cardio", branch: "Endurance", name: "Cardiovascular Endurance", description: "One mission long enough to change your breathing.", requirement: "Complete a single session of 25 minutes.", metric: "bestSessionMin", exerciseId: null, threshold: 25 }),
  skill({ id: "hip", branch: "Mobility", name: "Hip Mobility", description: "The front of the hip learns to yield.", requirement: "Hold Hip Openers for 60 seconds in one set.", metric: "prHold", exerciseId: "hip-openers", threshold: 60 }),
  skill({ id: "shoulder", branch: "Mobility", name: "Shoulder Mobility", description: "The joint moves without a story of pinching.", requirement: "Log 60 seconds of Shoulder Circles in one set.", metric: "prHold", exerciseId: "shoulder-circles", threshold: 60 }),
  skill({ id: "hamstring", branch: "Mobility", name: "Hamstring Flexibility", description: "A hinge, not a yank. Tension without nerve pain.", requirement: "Hold Hamstring Reach for 60 seconds.", metric: "prHold", exerciseId: "hamstring-reach", threshold: 60 }),
];

function gate(
  partial: Omit<DungeonDef, "custom">,
): DungeonDef {
  return { ...partial, custom: false };
}

export const DUNGEONS: DungeonDef[] = [
  gate({
    id: "goblin-cave",
    name: "Goblin Cave",
    rank: "E",
    levelRequired: 1,
    lore: "A low gate. The things inside are not impressive. Quitting is.",
    clearXp: 120,
    objectives: [
      { id: "g-push", label: "50 Push-ups", target: 50, unit: "reps", xp: 40, link: "push" },
      { id: "g-squat", label: "50 Squats", target: 50, unit: "reps", xp: 40, link: "squat" },
      { id: "g-sit", label: "30 Sit-ups", target: 30, unit: "reps", xp: 30, link: null },
      { id: "g-core", label: "5 minutes Core Work", target: 300, unit: "sec", xp: 40, link: "plank" },
    ],
    bossName: "Hobgoblin",
    bossLabel: "20 Push-ups",
    bossTarget: 20,
    bossUnit: "reps",
    bossXp: 60,
    bossLink: "push",
  }),
  gate({
    id: "ash-wolf",
    name: "Ash Wolf Den",
    rank: "D",
    levelRequired: 11,
    lore: "The pack does not rush. It waits for your elbows to drop.",
    clearXp: 160,
    objectives: [
      { id: "w-row", label: "40 Australian Rows", target: 40, unit: "reps", xp: 45, link: "pull" },
      { id: "w-lunge", label: "40 Lunges", target: 40, unit: "reps", xp: 40, link: "squat" },
      { id: "w-hollow", label: "90-second Hollow Hold", target: 90, unit: "sec", xp: 40, link: "plank" },
    ],
    bossName: "Den Mother",
    bossLabel: "12 Pull-ups or rows",
    bossTarget: 12,
    bossUnit: "reps",
    bossXp: 70,
    bossLink: "pull",
  }),
  gate({
    id: "frost",
    name: "Frost Cistern",
    rank: "C",
    levelRequired: 21,
    lore: "Cold stone. The only heat is the work.",
    clearXp: 200,
    objectives: [
      { id: "f-squat", label: "60 Squats", target: 60, unit: "reps", xp: 50, link: "squat" },
      { id: "f-push", label: "40 Push-ups", target: 40, unit: "reps", xp: 45, link: "push" },
      { id: "f-plank", label: "2-minute Plank", target: 120, unit: "sec", xp: 45, link: "plank" },
    ],
    bossName: "Cistern Warden",
    bossLabel: "20 Pike Push-ups",
    bossTarget: 20,
    bossUnit: "reps",
    bossXp: 80,
    bossLink: "push",
  }),
  gate({
    id: "crimson",
    name: "Crimson Gate",
    rank: "B",
    levelRequired: 36,
    lore: "A gate that prefers quality. Sloppy reps do not count. You are the referee.",
    clearXp: 260,
    objectives: [
      { id: "c-diamond", label: "25 Diamond Push-ups", target: 25, unit: "reps", xp: 55, link: "push" },
      { id: "c-pull", label: "20 Pull-ups", target: 20, unit: "reps", xp: 60, link: "pull" },
      { id: "c-lunge", label: "40 Walking Lunges", target: 40, unit: "reps", xp: 50, link: "squat" },
    ],
    bossName: "Gate Knight",
    bossLabel: "30-second L-Sit",
    bossTarget: 30,
    bossUnit: "sec",
    bossXp: 90,
    bossLink: null,
  }),
  gate({
    id: "obsidian",
    name: "Obsidian Keep",
    rank: "A",
    levelRequired: 51,
    lore: "The keep does not care how many times you have cleared easier doors.",
    clearXp: 340,
    objectives: [
      { id: "o-archer", label: "30 Archer Push-ups", target: 30, unit: "reps", xp: 70, link: "push" },
      { id: "o-pull", label: "25 Pull-ups", target: 25, unit: "reps", xp: 70, link: "pull" },
      { id: "o-core", label: "3 minutes Core", target: 180, unit: "sec", xp: 55, link: "plank" },
    ],
    bossName: "Keep Warden",
    bossLabel: "20-second Handstand",
    bossTarget: 20,
    bossUnit: "sec",
    bossXp: 100,
    bossLink: null,
  }),
  gate({
    id: "ordeal",
    name: "Final Gate: Ordeal",
    rank: "S",
    levelRequired: 71,
    lore: "Not a monster. A mirror. Leave if anything hurts in the wrong way.",
    clearXp: 420,
    objectives: [
      { id: "s-pike", label: "40 Pike Push-ups", target: 40, unit: "reps", xp: 80, link: "push" },
      { id: "s-pull", label: "20 Pull-ups", target: 20, unit: "reps", xp: 70, link: "pull" },
      { id: "s-skill", label: "20-second Skill Hold", target: 20, unit: "sec", xp: 80, link: null },
    ],
    bossName: "The Quiet",
    bossLabel: "40 Push-ups",
    bossTarget: 40,
    bossUnit: "reps",
    bossXp: 120,
    bossLink: "push",
  }),
];

function item(exerciseId: string, sets: number, reps: number, hold: number, rest: number): RoutineItem {
  return { exerciseId, sets, reps, hold, rest };
}

const ROUTINES: Routine[] = [
  {
    id: "circuit-e",
    name: "E-Rank Circuit",
    focus: "Full Body",
    custom: false,
    items: [item("push-standard", 3, 10, 0, 60), item("squat", 3, 15, 0, 60), item("row-australian", 3, 8, 0, 60), item("plank", 3, 0, 30, 45)],
  },
  {
    id: "push-gate",
    name: "Push Gate",
    focus: "Chest",
    custom: false,
    items: [item("push-standard", 4, 8, 0, 70), item("push-diamond", 3, 6, 0, 75), item("push-pike", 3, 6, 0, 75), item("push-decline", 3, 8, 0, 70)],
  },
  {
    id: "pull-gate",
    name: "Pull Gate",
    focus: "Back",
    custom: false,
    items: [item("row-australian", 3, 10, 0, 60), item("row-inverted", 3, 8, 0, 70), item("pull-up", 4, 4, 0, 90), item("chin-up", 3, 4, 0, 90)],
  },
  {
    id: "lower-gate",
    name: "Lower Gate",
    focus: "Legs",
    custom: false,
    items: [item("squat", 4, 12, 0, 60), item("lunge", 3, 8, 0, 60), item("split-squat", 3, 6, 0, 75), item("nordic", 3, 3, 0, 90)],
  },
  {
    id: "core-gate",
    name: "Core Gate",
    focus: "Core",
    custom: false,
    items: [item("plank", 3, 0, 40, 40), item("hollow", 3, 0, 20, 40), item("leg-raise", 3, 8, 0, 50), item("sit-up", 3, 12, 0, 45)],
  },
  {
    id: "mobility-flow",
    name: "Mobility Flow",
    focus: "Mobility",
    custom: false,
    items: [item("hip-openers", 2, 0, 60, 15), item("shoulder-circles", 2, 0, 60, 15), item("hamstring-reach", 2, 0, 60, 15), item("wgs", 2, 5, 0, 20)],
  },
  {
    id: "skill-practice",
    name: "Skill Practice",
    focus: "Skills",
    custom: false,
    items: [item("lsit", 4, 0, 10, 70), item("handstand", 5, 0, 15, 60), item("hollow", 3, 0, 20, 40)],
  },
];

export function createInitial(): SaveData {
  const template = standardQuests();
  return {
    v: 1,
    player: {
      name: "THE PLAYER",
      title: "Unknown",
      level: 1,
      xp: 0,
      lifetimeXp: 0,
      points: 0,
      stats: { str: 8, agi: 8, vit: 8, end: 8, flex: 8, disc: 8 },
      streak: 0,
      longestStreak: 0,
      lastTrainingDate: null,
      lastMeaningfulDate: null,
      totalWorkouts: 0,
      recovery: false,
      recoveryNote: "",
    },
    settings: { sound: false },
    seenIntro: false,
    nationalSeen: false,
    questTemplate: template.map(freshQuest),
    daily: { date: todayKey(), rest: false, bonusClaimed: false, quests: template.map(freshQuest) },
    exercises: EXERCISES.map((e) => ({ ...e })),
    routines: ROUTINES.map((r) => ({ ...r, items: r.items.map((i) => ({ ...i })) })),
    session: null,
    logs: [],
    skills: SKILLS.map((s) => ({ ...s })),
    customDungeons: [],
    dungeonRecords: {},
    dungeonHistory: [],
    dungeonRun: null,
    measures: [],
    weeklyClaims: [],
    questDays: [],
    restDays: [],
  };
}

function normalizeQuest(raw: Partial<Quest> | undefined, fallback: Quest): Quest {
  if (!raw || typeof raw !== "object") return freshQuest(fallback);
  const unit: Unit = raw.unit === "sec" || raw.unit === "min" || raw.unit === "reps" ? raw.unit : fallback.unit;
  const bonus = raw.bonus
    ? {
        title: String(raw.bonus.title || "Bonus").slice(0, 48),
        target: clamp(num(raw.bonus.target, 0), 0, 100),
        xp: clamp(num(raw.bonus.xp, 10), 0, 200),
        rewarded: Boolean(raw.bonus.rewarded),
      }
    : null;
  return {
    id: String(raw.id || fallback.id),
    title: String(raw.title || fallback.title).slice(0, 48),
    detail: String(raw.detail || "").slice(0, 180),
    target: clamp(num(raw.target, fallback.target), 1, unit === "min" ? 45 : unit === "sec" ? 600 : 200),
    unit,
    progress: Math.max(0, num(raw.progress, 0)),
    xp: clamp(num(raw.xp, fallback.xp), 5, 300),
    difficulty: (["E", "D", "C", "B", "A", "S"] as Difficulty[]).includes(raw.difficulty as Difficulty)
      ? (raw.difficulty as Difficulty)
      : "E",
    link: raw.link === "push" || raw.link === "squat" || raw.link === "pull" || raw.link === "plank" || raw.link === "mobility" ? raw.link : null,
    bonus: bonus && bonus.target > 0 ? bonus : null,
    suspended: Boolean(raw.suspended),
    rewarded: Boolean(raw.rewarded),
    custom: Boolean(raw.custom),
  };
}

export function normalize(raw: unknown): SaveData {
  const base = createInitial();
  if (!raw || typeof raw !== "object") return base;
  const r = raw as Partial<SaveData>;
  const savedExercises = Array.isArray(r.exercises) ? r.exercises : [];
  const exercises = base.exercises.map((builtin) => {
    const saved = savedExercises.find((e) => e.id === builtin.id);
    if (!saved) return builtin;
    return {
      ...builtin,
      prReps: Math.max(0, num(saved.prReps, 0)),
      prHold: Math.max(0, num(saved.prHold, 0)),
      prAt: typeof saved.prAt === "string" ? saved.prAt : null,
    };
  });
  for (const saved of savedExercises) {
    if (!saved || exercises.some((e) => e.id === saved.id) || !saved.custom) continue;
    exercises.push({
      id: String(saved.id),
      name: String(saved.name || "Custom").slice(0, 40),
      category: (EXERCISES.map((e) => e.category) as string[]).includes(String(saved.category))
        ? (saved.category as Category)
        : "Full Body",
      mode: saved.mode === "hold" ? "hold" : "reps",
      link:
        saved.link === "push" || saved.link === "squat" || saved.link === "pull" || saved.link === "plank" || saved.link === "mobility"
          ? saved.link
          : null,
      instructions: String(saved.instructions || "").slice(0, 240),
      difficulty: (["E", "D", "C", "B", "A", "S"] as Difficulty[]).includes(saved.difficulty as Difficulty)
        ? (saved.difficulty as Difficulty)
        : "E",
      xpPerSet: clamp(num(saved.xpPerSet, 10), 4, 40),
      defaultSets: clamp(num(saved.defaultSets, 3), 1, 8),
      defaultReps: clamp(num(saved.defaultReps, 8), 0, 50),
      defaultHold: clamp(num(saved.defaultHold, 20), 0, 180),
      defaultRest: clamp(num(saved.defaultRest, 60), 10, 180),
      prReps: Math.max(0, num(saved.prReps, 0)),
      prHold: Math.max(0, num(saved.prHold, 0)),
      prAt: typeof saved.prAt === "string" ? saved.prAt : null,
      custom: true,
    });
  }
  const savedSkills = Array.isArray(r.skills) ? r.skills : [];
  const skills = base.skills.map((builtin) => {
    const saved = savedSkills.find((s) => s.id === builtin.id);
    return { ...builtin, unlockedAt: saved && typeof saved.unlockedAt === "string" ? saved.unlockedAt : null };
  });
  const customRoutines = (Array.isArray(r.routines) ? r.routines : []).filter((item) => item && item.custom);
  const routines = [
    ...base.routines,
    ...customRoutines.map((routine) => ({
      id: String(routine.id || uid("routine")),
      name: String(routine.name || "Custom mission").slice(0, 40),
      focus: String(routine.focus || "Custom").slice(0, 24),
      custom: true,
      items: Array.isArray(routine.items)
        ? routine.items
            .filter((it) => it && typeof it.exerciseId === "string")
            .slice(0, 12)
            .map((it) => ({
              exerciseId: it.exerciseId,
              sets: clamp(num(it.sets, 3), 1, 8),
              reps: clamp(num(it.reps, 8), 0, 50),
              hold: clamp(num(it.hold, 0), 0, 180),
              rest: clamp(num(it.rest, 60), 10, 180),
            }))
        : [],
    })),
  ].filter((routine) => routine.items.length > 0 || !routine.custom);

  const templateSrc = Array.isArray(r.questTemplate) && r.questTemplate.length ? r.questTemplate : base.questTemplate;
  const questTemplate = templateSrc.slice(0, 8).map((q, i) => normalizeQuest(q, base.questTemplate[i] || base.questTemplate[0]));
  const dailyRaw = r.daily;
  const daily = {
    date: dailyRaw && typeof dailyRaw.date === "string" ? dailyRaw.date : todayKey(),
    rest: Boolean(dailyRaw?.rest),
    bonusClaimed: Boolean(dailyRaw?.bonusClaimed),
    quests:
      dailyRaw && Array.isArray(dailyRaw.quests) && dailyRaw.quests.length
        ? dailyRaw.quests.slice(0, 8).map((q, i) => normalizeQuest(q, questTemplate[i] || questTemplate[0]))
        : questTemplate.map(freshQuest),
  };

  const playerRaw = r.player;
  const stats = { ...base.player.stats };
  for (const stat of STATS) stats[stat.key] = clamp(num(playerRaw?.stats?.[stat.key], 8), 1, 99);

  return {
    v: 1,
    player: {
      ...base.player,
      name: String(playerRaw?.name || base.player.name).slice(0, 24) || "THE PLAYER",
      title: String(playerRaw?.title || "Unknown").slice(0, 32) || "Unknown",
      level: clamp(num(playerRaw?.level, 1), 1, 200),
      xp: Math.max(0, num(playerRaw?.xp, 0)),
      lifetimeXp: Math.max(0, num(playerRaw?.lifetimeXp, 0)),
      points: clamp(num(playerRaw?.points, 0), 0, 999),
      stats,
      streak: Math.max(0, num(playerRaw?.streak, 0)),
      longestStreak: Math.max(0, num(playerRaw?.longestStreak, 0)),
      lastTrainingDate: typeof playerRaw?.lastTrainingDate === "string" ? playerRaw.lastTrainingDate : null,
      lastMeaningfulDate: typeof playerRaw?.lastMeaningfulDate === "string" ? playerRaw.lastMeaningfulDate : null,
      totalWorkouts: Math.max(0, num(playerRaw?.totalWorkouts, 0)),
      recovery: Boolean(playerRaw?.recovery),
      recoveryNote: String(playerRaw?.recoveryNote || "").slice(0, 140),
    },
    settings: { sound: Boolean(r.settings?.sound) },
    seenIntro: Boolean(r.seenIntro),
    nationalSeen: Boolean(r.nationalSeen),
    questTemplate,
    daily,
    exercises,
    routines,
    session: validateSession(r.session, exercises),
    logs: Array.isArray(r.logs) ? r.logs.slice(-400) : [],
    skills,
    customDungeons: Array.isArray(r.customDungeons) ? r.customDungeons.slice(0, 12) : [],
    dungeonRecords: r.dungeonRecords && typeof r.dungeonRecords === "object" ? r.dungeonRecords : {},
    dungeonHistory: Array.isArray(r.dungeonHistory) ? r.dungeonHistory.slice(-60) : [],
    dungeonRun: r.dungeonRun && typeof r.dungeonRun === "object" && Array.isArray(r.dungeonRun.objectives) ? r.dungeonRun : null,
    measures: Array.isArray(r.measures) ? r.measures.slice(-400) : [],
    weeklyClaims: Array.isArray(r.weeklyClaims) ? r.weeklyClaims : [],
    questDays: Array.isArray(r.questDays) ? r.questDays.filter((d) => typeof d === "string") : [],
    restDays: Array.isArray(r.restDays) ? r.restDays.filter((d) => typeof d === "string") : [],
  };
}

function validateSession(session: Session | null | undefined, exercises: Exercise[]): Session | null {
  if (!session || !Array.isArray(session.items) || session.items.length === 0) return null;
  if (!exercises.length) return null;
  return session;
}

export function xpForDifficulty(d: Difficulty) {
  return XP_FOR_DIFF[d];
}

export function formatProgress(progress: number, target: number, unit: Unit) {
  const shown = Math.min(progress, target);
  if (unit === "sec") return `${Math.floor(shown)}/${target}s`;
  if (unit === "min") return `${Math.floor(shown)}/${target}m`;
  return `${Math.floor(shown)}/${target}`;
}

export function dailyQuestDoneCount(data: SaveData) {
  const active = data.daily.quests.filter((q) => !q.suspended);
  const done = active.filter((q) => q.progress >= q.target).length;
  return { done, total: active.length, claimed: data.daily.bonusClaimed, rest: data.daily.rest };
}

export function trainingDaysThisWeek(data: SaveData) {
  const week = weekStartKey();
  const start = parseDay(week).getTime();
  const days = new Set<string>();
  for (const log of data.logs) if (log.at >= start) days.add(todayKey(new Date(log.at)));
  for (const day of data.questDays) if (day >= week) days.add(day);
  return days.size;
}

function exerciseOf(data: SaveData, id: string) {
  return data.exercises.find((e) => e.id === id);
}

export function buildSession(data: SaveData, name: string, items: RoutineItem[]): Session | null {
  const built: SessionItem[] = [];
  for (const spec of items) {
    const exercise = exerciseOf(data, spec.exerciseId);
    if (!exercise) continue;
    const sets = clamp(spec.sets, 1, 8);
    built.push({
      exerciseId: exercise.id,
      name: exercise.name,
      category: exercise.category,
      mode: exercise.mode,
      link: exercise.link,
      instructions: exercise.instructions,
      difficulty: exercise.difficulty,
      xpPerSet: exercise.xpPerSet,
      targetReps: exercise.mode === "reps" ? clamp(spec.reps || exercise.defaultReps, 1, 50) : 0,
      targetHold: exercise.mode === "hold" ? clamp(spec.hold || exercise.defaultHold, 5, 180) : 0,
      rest: clamp(spec.rest || exercise.defaultRest, 10, 180),
      sets: Array.from({ length: sets }, () => ({ reps: 0, hold: 0, done: false })),
      skipped: false,
      holdEndsAt: null,
      holdStartedAt: null,
    });
  }
  if (!built.length) return null;
  return { name, startedAt: Date.now(), index: 0, restEndsAt: null, items: built, xp: 0, prs: [] };
}

function currentSet(item: SessionItem) {
  return item.sets.find((set) => !set.done) ?? null;
}

function advanceSession(data: SaveData, fx: Fx) {
  const session = data.session;
  if (!session) return;
  const item = session.items[session.index];
  if (item && item.sets.some((set) => !set.done) && !item.skipped) {
    session.restEndsAt = Date.now() + item.rest * 1000;
    return;
  }
  let next = session.index + 1;
  while (next < session.items.length && session.items[next].skipped) next += 1;
  if (next >= session.items.length) finishSession(data, fx, false);
  else {
    session.index = next;
    session.restEndsAt = item ? Date.now() + Math.min(item.rest, 60) * 1000 : null;
  }
}

function recordPr(data: SaveData, session: Session, exerciseId: string, mode: "reps" | "hold", value: number, fx: Fx) {
  const exercise = exerciseOf(data, exerciseId);
  if (!exercise || value <= 0) return;
  const beaten = mode === "reps" ? value > exercise.prReps : value > exercise.prHold;
  if (!beaten) return;
  if (mode === "reps") exercise.prReps = value;
  else exercise.prHold = value;
  exercise.prAt = todayKey();
  if (!session.prs.includes(exercise.name)) session.prs.push(exercise.name);
  session.xp += 50;
  grantXp(data, 50, fx, { title: "PERSONAL RECORD", body: `${exercise.name} · ${value}${mode === "hold" ? "s" : ""}`, chime: true });
}

function awardSet(data: SaveData, session: Session, item: SessionItem, ratio: number, fx: Fx) {
  const xp = Math.max(4, Math.round(item.xpPerSet * clamp(ratio, 0.35, 1)));
  session.xp += xp;
  grantXp(data, xp, fx, { title: "SET CLEARED", body: `${item.name} · +${xp} XP` });
}

export function logRepSet(data: SaveData, repsIn: number, fx: Fx) {
  const session = data.session;
  if (!session) return;
  if (session.restEndsAt && Date.now() < session.restEndsAt) return;
  session.restEndsAt = null;
  const item = session.items[session.index];
  if (!item || item.mode !== "reps" || item.skipped) return;
  const set = currentSet(item);
  if (!set) return;
  const reps = clamp(Math.round(repsIn), 1, 80);
  set.reps = reps;
  set.done = true;
  awardSet(data, session, item, reps / Math.max(1, item.targetReps), fx);
  recordPr(data, session, item.exerciseId, "reps", reps, fx);
  applyLink(data, item.link, reps, "reps", fx);
  advanceSession(data, fx);
}

export function beginHold(data: SaveData) {
  const session = data.session;
  if (!session) return;
  if (session.restEndsAt && Date.now() < session.restEndsAt) return;
  session.restEndsAt = null;
  const item = session.items[session.index];
  if (!item || item.mode !== "hold" || item.holdEndsAt) return;
  item.holdStartedAt = Date.now();
  item.holdEndsAt = Date.now() + item.targetHold * 1000;
}

export function completeHold(data: SaveData, fx: Fx, early = false) {
  const session = data.session;
  if (!session) return;
  const item = session.items[session.index];
  if (!item || !item.holdStartedAt) return;
  const set = currentSet(item);
  if (!set) {
    item.holdEndsAt = null;
    item.holdStartedAt = null;
    return;
  }
  const elapsedRaw = Math.round((Date.now() - item.holdStartedAt) / 1000);
  const elapsed = clamp(early ? elapsedRaw : Math.max(elapsedRaw, item.targetHold), 1, item.targetHold);
  item.holdEndsAt = null;
  item.holdStartedAt = null;
  set.hold = elapsed;
  set.done = true;
  awardSet(data, session, item, elapsed / Math.max(1, item.targetHold), fx);
  recordPr(data, session, item.exerciseId, "hold", elapsed, fx);
  applyLink(data, item.link, elapsed, "sec", fx);
  advanceSession(data, fx);
}

export function pumpSession(data: SaveData, fx: Fx): boolean {
  const session = data.session;
  if (!session) return false;
  const item = session.items[session.index];
  if (item?.holdEndsAt && Date.now() >= item.holdEndsAt) {
    completeHold(data, fx, false);
    return true;
  }
  return false;
}

export function skipRest(data: SaveData) {
  if (data.session) data.session.restEndsAt = null;
}

export function adjustRest(data: SaveData, delta: number) {
  const session = data.session;
  if (!session) return;
  const item = session.items[session.index];
  if (!item) return;
  item.rest = clamp(item.rest + delta, 10, 180);
  if (session.restEndsAt) session.restEndsAt = Math.max(Date.now(), session.restEndsAt + delta * 1000);
}

export function skipExercise(data: SaveData, fx: Fx) {
  const session = data.session;
  if (!session) return;
  const item = session.items[session.index];
  if (!item) return;
  item.skipped = true;
  item.holdEndsAt = null;
  item.holdStartedAt = null;
  session.restEndsAt = null;
  advanceSession(data, fx);
}

function doneSetsOf(session: Session) {
  return session.items.reduce((sum, item) => sum + item.sets.filter((set) => set.done).length, 0);
}

export function finishSession(data: SaveData, fx: Fx, partial: boolean) {
  const session = data.session;
  if (!session) return;
  const doneSets = doneSetsOf(session);
  const full = !partial && session.items.every((item) => !item.skipped && item.sets.every((set) => set.done));
  const volumeReps = session.items.reduce((sum, item) => sum + item.sets.reduce((inner, set) => inner + (set.done ? set.reps : 0), 0), 0);
  const volumeHold = session.items.reduce((sum, item) => sum + item.sets.reduce((inner, set) => inner + (set.done ? set.hold : 0), 0), 0);
  const durationSec = Math.max(1, Math.round((Date.now() - session.startedAt) / 1000));
  if (full && doneSets > 0) {
    session.xp += 40;
    grantXp(data, 40, fx, { title: "MISSION COMPLETE", body: "Rewards have been distributed.", chime: true });
  } else if (doneSets > 0) {
    fx.notices.push(notice("EXTRACTED", "Partial credit kept. No clear bonus."));
  } else {
    fx.notices.push(notice("MISSION ABORTED", "Nothing was logged."));
  }
  const meaningful = full || doneSets >= 2 || volumeReps >= 15 || volumeHold >= 45;
  if (doneSets > 0) {
    data.logs.push({
      id: uid("log"),
      name: session.name,
      at: Date.now(),
      durationSec,
      volumeReps,
      volumeHold,
      xp: session.xp,
      kind: "workout",
      prs: session.prs,
      exercises: session.items
        .filter((item) => item.sets.some((set) => set.done))
        .map((item) => ({
          name: item.name,
          link: item.link,
          category: item.category,
          reps: item.sets.reduce((sum, set) => sum + (set.done ? set.reps : 0), 0),
          hold: item.sets.reduce((sum, set) => sum + (set.done ? set.hold : 0), 0),
          sets: item.sets.filter((set) => set.done).length,
        })),
    });
  }
  if (meaningful) {
    data.player.totalWorkouts += 1;
    markTraining(data, fx);
  }
  data.session = null;
}

export function startDungeon(data: SaveData, id: string, lighter: boolean, fx: Fx) {
  if (data.session) {
    fx.notices.push(notice("MISSION OPEN", "Extract from training before entering a gate."));
    return;
  }
  if (data.dungeonRun) {
    fx.notices.push(notice("GATE OPEN", "Finish or withdraw from the current gate."));
    return;
  }
  if (data.player.recovery) {
    fx.notices.push(notice("RECOVERY", "Gates stay shut while recovery is active."));
    return;
  }
  const def = allDungeons(data).find((d) => d.id === id);
  if (!def) return;
  if (!def.custom && data.player.level < def.levelRequired) {
    fx.notices.push(notice("SEALED", `Requires level ${def.levelRequired}.`));
    return;
  }
  data.dungeonRun = {
    dungeonId: def.id,
    name: def.name,
    rank: def.rank,
    startedAt: Date.now(),
    lighter,
    clearXp: def.clearXp,
    bossName: def.bossName,
    bossLabel: def.bossLabel,
    bossTarget: scaleTarget(def.bossTarget, def.bossUnit, lighter),
    bossProgress: 0,
    bossUnit: def.bossUnit,
    bossXp: def.bossXp,
    bossLink: def.bossLink,
    bossRewarded: false,
    xp: 0,
    objectives: def.objectives.map((o) => ({
      ...o,
      target: scaleTarget(o.target, o.unit, lighter),
      progress: 0,
      rewarded: false,
    })),
  };
  fx.notices.push(notice("GATE OPENED", lighter ? `${def.name} · lighter gate` : def.name));
}

function bossOpen(run: DungeonRun) {
  return run.objectives.every((o) => o.progress >= o.target);
}

function maybeClearDungeon(data: SaveData, fx: Fx) {
  const run = data.dungeonRun;
  if (!run || run.bossRewarded === false) return;
  if (!bossOpen(run)) return;
  endDungeon(data, fx, true);
}

export function bumpObjective(data: SaveData, id: string, delta: number, fx: Fx) {
  const run = data.dungeonRun;
  if (!run) return;
  const ob = run.objectives.find((o) => o.id === id);
  if (!ob) return;
  const next = clamp(ob.progress + delta, 0, ob.target);
  if (ob.rewarded && next < ob.target) return;
  const applied = next - ob.progress;
  ob.progress = next;
  if (applied > 0) applyLink(data, ob.link, applied, ob.unit, fx);
  if (ob.progress >= ob.target && !ob.rewarded) {
    ob.rewarded = true;
    run.xp += ob.xp;
    grantXp(data, ob.xp, fx, { title: "OBJECTIVE CLEARED", body: ob.label, chime: true });
  }
}

export function bumpBoss(data: SaveData, delta: number, fx: Fx) {
  const run = data.dungeonRun;
  if (!run || !bossOpen(run)) return;
  const next = clamp(run.bossProgress + delta, 0, run.bossTarget);
  if (run.bossRewarded && next < run.bossTarget) return;
  const applied = next - run.bossProgress;
  run.bossProgress = next;
  if (applied > 0) applyLink(data, run.bossLink, applied, run.bossUnit, fx);
  if (run.bossProgress >= run.bossTarget && !run.bossRewarded) {
    run.bossRewarded = true;
    run.xp += run.bossXp;
    grantXp(data, run.bossXp, fx, { title: "BOSS DEFEATED", body: run.bossName, chime: true });
    maybeClearDungeon(data, fx);
  }
}

export function endDungeon(data: SaveData, fx: Fx, cleared: boolean) {
  const run = data.dungeonRun;
  if (!run) return;
  const sec = Math.max(1, Math.round((Date.now() - run.startedAt) / 1000));
  if (cleared) {
    run.xp += run.clearXp;
    grantXp(data, run.clearXp, fx, { title: "GATE CLEARED", body: `${run.name}. Rewards have been distributed.`, chime: true });
    const rec = data.dungeonRecords[run.dungeonId] ?? { clears: 0, bestSec: null, lastClear: null };
    rec.clears += 1;
    rec.bestSec = rec.bestSec == null ? sec : Math.min(rec.bestSec, sec);
    rec.lastClear = todayKey();
    data.dungeonRecords[run.dungeonId] = rec;
  } else if (run.xp > 0 || run.objectives.some((o) => o.progress > 0)) {
    fx.notices.push(notice("WITHDREW", "The gate closed. Credit already earned stays."));
  }
  const reps = run.objectives.reduce((sum, o) => sum + (o.unit === "reps" ? o.progress : 0), 0) + (run.bossUnit === "reps" ? run.bossProgress : 0);
  const hold = run.objectives.reduce((sum, o) => sum + (o.unit === "sec" ? o.progress : 0), 0) + (run.bossUnit === "sec" ? run.bossProgress : 0);
  if (reps > 0 || hold > 0) {
    data.logs.push({
      id: uid("log"),
      name: run.name,
      at: Date.now(),
      durationSec: sec,
      volumeReps: reps,
      volumeHold: hold,
      xp: run.xp,
      kind: "dungeon",
      prs: [],
      exercises: [
        ...run.objectives.map((o) => ({
          name: o.label,
          link: o.link,
          category: "Full Body" as Category,
          reps: o.unit === "reps" ? o.progress : 0,
          hold: o.unit === "sec" ? o.progress : 0,
          sets: o.progress > 0 ? 1 : 0,
        })),
        {
          name: run.bossName,
          link: run.bossLink,
          category: "Full Body" as Category,
          reps: run.bossUnit === "reps" ? run.bossProgress : 0,
          hold: run.bossUnit === "sec" ? run.bossProgress : 0,
          sets: run.bossProgress > 0 ? 1 : 0,
        },
      ].filter((e) => e.reps > 0 || e.hold > 0),
    });
  }
  if (cleared || reps >= 15 || hold >= 45) {
    data.player.totalWorkouts += 1;
    markTraining(data, fx);
  }
  data.dungeonHistory.push({
    id: uid("clear"),
    dungeonId: run.dungeonId,
    name: run.name,
    rank: run.rank,
    at: Date.now(),
    sec,
    xp: run.xp,
    cleared,
  });
  data.dungeonRun = null;
}

export function claimWeek(data: SaveData, id: string, fx: Fx) {
  const challenge = weeklyChallenges(data).find((c) => c.id === id);
  if (!challenge || challenge.claimed || challenge.progress < challenge.target) return;
  const week = weekStartKey();
  const bucket = data.weeklyClaims.find((w) => w.week === week);
  if (bucket) bucket.ids.push(id);
  else data.weeklyClaims.push({ week, ids: [id] });
  grantXp(data, challenge.xp, fx, { title: "WEEKLY CLEARED", body: challenge.title, chime: true });
}

export function applyPreset(data: SaveData, preset: "awakening" | "standard" | "monarch", fx: Fx) {
  if (data.daily.quests.some((q) => q.rewarded || q.bonus?.rewarded)) {
    fx.notices.push(notice("LOCKED", "The protocol locks after the first reward today."));
    return;
  }
  const next = presetQuests(preset).map(freshQuest);
  data.questTemplate = next;
  data.daily = { date: todayKey(), rest: data.daily.rest, bonusClaimed: false, quests: next.map(freshQuest) };
  data.seenIntro = true;
  fx.notices.push(notice("PROTOCOL SET", preset === "awakening" ? "Awakening." : preset === "monarch" ? "Monarch." : "Standard."));
}

export function syncQuestEdit(data: SaveData, next: Quest) {
  const clean = freshQuest({ ...next, title: next.title.slice(0, 48), detail: next.detail.slice(0, 180) });
  clean.target = clamp(next.target, 1, next.unit === "min" ? 45 : next.unit === "sec" ? 600 : 200);
  clean.xp = clamp(next.xp, 5, 300);
  const applyToday = (q: Quest): Quest => ({
    ...clean,
    progress: Math.min(q.progress, clean.target + (clean.bonus?.target ?? 0)),
    rewarded: q.rewarded && q.progress >= clean.target,
    suspended: q.suspended,
    bonus: clean.bonus ? { ...clean.bonus, rewarded: Boolean(q.bonus?.rewarded) && q.progress >= clean.target + clean.bonus.target } : null,
  });
  data.questTemplate = data.questTemplate.map((q) => (q.id === clean.id ? clean : q));
  data.daily.quests = data.daily.quests.map((q) => (q.id === clean.id ? applyToday(q) : q));
}

export const CATEGORIES: Category[] = ["Chest", "Back", "Shoulders", "Biceps", "Triceps", "Legs", "Core", "Full Body", "Mobility", "Skills"];
export const DIFFICULTIES: Difficulty[] = ["E", "D", "C", "B", "A", "S"];
