import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shield, c as Castle, i as Sparkles, o as ScrollText, r as Swords, s as Lock, t as UserRound } from "../_libs/lucide-react.mjs";
import { n as motion, r as AnimatePresence, t as useReducedMotion } from "../_libs/framer-motion+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as Area, c as Tooltip, i as XAxis, n as BarChart, o as Bar, r as YAxis, s as ResponsiveContainer, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-0aM_nYGw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DB_NAME = "arise-player-system";
var STORE = "save";
var KEY = "main";
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("IndexedDB failed"));
	});
}
async function idbGet() {
	if (typeof indexedDB === "undefined") return null;
	const db = await openDb();
	try {
		return await new Promise((resolve, reject) => {
			const req = db.transaction(STORE, "readonly").objectStore(STORE).get(KEY);
			req.onsuccess = () => resolve(req.result ?? null);
			req.onerror = () => reject(req.error);
		});
	} finally {
		db.close();
	}
}
async function idbSet(data) {
	if (typeof indexedDB === "undefined") return;
	const db = await openDb();
	try {
		await new Promise((resolve, reject) => {
			const tx = db.transaction(STORE, "readwrite");
			tx.objectStore(STORE).put(data, KEY);
			tx.oncomplete = () => resolve();
			tx.onerror = () => reject(tx.error);
		});
	} finally {
		db.close();
	}
}
var STATS = [
	{
		key: "str",
		label: "STR",
		name: "Strength",
		blurb: "Force you choose to build."
	},
	{
		key: "agi",
		label: "AGI",
		name: "Agility",
		blurb: "Control under speed."
	},
	{
		key: "vit",
		label: "VIT",
		name: "Vitality",
		blurb: "How well you recover."
	},
	{
		key: "end",
		label: "END",
		name: "Endurance",
		blurb: "How long you can stay."
	},
	{
		key: "flex",
		label: "FLEX",
		name: "Flexibility",
		blurb: "Range you can actually use."
	},
	{
		key: "disc",
		label: "DISC",
		name: "Discipline",
		blurb: "Showing up again."
	}
];
var XP_FOR_DIFF = {
	E: 8,
	D: 10,
	C: 14,
	B: 18,
	A: 24,
	S: 30
};
function uid(prefix = "id") {
	return `${prefix}-${typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : Math.random().toString(36).slice(2, 12)}`;
}
function emptyFx() {
	return {
		notices: [],
		levels: []
	};
}
function notice(title, body, chime = false) {
	return {
		id: uid("n"),
		title,
		body,
		chime
	};
}
function todayKey(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function parseDay(key) {
	const [y, m, d] = key.split("-").map(Number);
	return new Date(y, (m || 1) - 1, d || 1);
}
function daysBetween(from, to) {
	return Math.round((parseDay(to).getTime() - parseDay(from).getTime()) / 864e5);
}
function weekStartKey(d = /* @__PURE__ */ new Date()) {
	const date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
	const day = date.getDay();
	const diff = day === 0 ? 6 : day - 1;
	date.setDate(date.getDate() - diff);
	return todayKey(date);
}
function xpNeeded(level) {
	const l = Math.max(1, level);
	return Math.round(100 + (l - 1) * 40 + (l - 1) ** 2 * 8);
}
function rankForLevel(level) {
	if (level >= 71) return {
		name: "S-RANK",
		code: "S"
	};
	if (level >= 51) return {
		name: "A-RANK",
		code: "A"
	};
	if (level >= 36) return {
		name: "B-RANK",
		code: "B"
	};
	if (level >= 21) return {
		name: "C-RANK",
		code: "C"
	};
	if (level >= 11) return {
		name: "D-RANK",
		code: "D"
	};
	return {
		name: "E-RANK",
		code: "E"
	};
}
function isNational(data) {
	const skills = [
		"lsit",
		"handstand",
		"front",
		"back",
		"planche"
	].every((id) => data.skills.some((s) => s.id === id && s.unlockedAt));
	return data.player.level >= 71 && skills && data.player.totalWorkouts >= 40 && data.player.longestStreak >= 14;
}
function rankLabel(data) {
	if (isNational(data)) return {
		name: "NATIONAL LEVEL",
		code: "N"
	};
	return rankForLevel(data.player.level);
}
function nationalGoals(data) {
	const need = [
		"lsit",
		"handstand",
		"front",
		"back",
		"planche"
	];
	const unlocked = need.filter((id) => data.skills.some((s) => s.id === id && s.unlockedAt)).length;
	return [
		{
			label: "Reach S-RANK (level 71)",
			done: data.player.level >= 71
		},
		{
			label: "Acquire all five calisthenics skills",
			done: unlocked === need.length,
			detail: `${unlocked}/5`
		},
		{
			label: "Log 40 workouts",
			done: data.player.totalWorkouts >= 40,
			detail: `${data.player.totalWorkouts}/40`
		},
		{
			label: "Hold a 14-day streak",
			done: data.player.longestStreak >= 14,
			detail: `${data.player.longestStreak}/14`
		}
	];
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function num(v, fallback) {
	return typeof v === "number" && Number.isFinite(v) ? v : fallback;
}
function grantXp(data, amount, fx, reason) {
	const gain = Math.round(amount);
	if (gain <= 0) return;
	data.player.xp += gain;
	data.player.lifetimeXp += gain;
	if (reason) fx.notices.push(notice(reason.title, reason.body, Boolean(reason.chime)));
	let guard = 0;
	while (data.player.xp >= xpNeeded(data.player.level) && guard++ < 40) {
		data.player.xp -= xpNeeded(data.player.level);
		data.player.level += 1;
		data.player.points += 3;
		const next = rankForLevel(data.player.level);
		const prev = rankForLevel(data.player.level - 1);
		fx.levels.push({
			id: uid("lv"),
			level: data.player.level,
			rank: isNational({
				...data,
				nationalSeen: true
			}) ? "NATIONAL LEVEL" : next.name,
			rankUp: next.name !== prev.name
		});
	}
}
function reconcileStreak(data) {
	if (data.player.recovery) return;
	const last = data.player.lastMeaningfulDate;
	if (!last) return;
	if (daysBetween(last, todayKey()) > 1) data.player.streak = 0;
}
function markTraining(data, fx) {
	const today = todayKey();
	reconcileStreak(data);
	if (data.player.lastTrainingDate === today) return;
	if (!data.player.recovery) {
		const last = data.player.lastMeaningfulDate;
		if (!last || daysBetween(last, today) > 1) data.player.streak = 1;
		else data.player.streak += 1;
		if (data.player.streak > data.player.longestStreak) data.player.longestStreak = data.player.streak;
		if (data.player.streak >= 3) fx.notices.push(notice("STREAK", `${data.player.streak} consecutive days.`));
	}
	data.player.lastTrainingDate = today;
	data.player.lastMeaningfulDate = today;
}
function questCap(q) {
	return q.target + (q.bonus?.target ?? 0);
}
function bumpQuest(data, id, delta, fx) {
	const q = data.daily.quests.find((item) => item.id === id);
	if (!q || q.suspended || delta === 0) return;
	const next = clamp(q.progress + delta, 0, questCap(q));
	if (q.rewarded && next < q.target) return;
	q.progress = next;
	if (q.progress >= q.target && !q.rewarded) {
		q.rewarded = true;
		grantXp(data, q.xp, fx, {
			title: "QUEST CLEARED",
			body: q.title,
			chime: true
		});
	}
	if (q.bonus && q.progress >= q.target + q.bonus.target && !q.bonus.rewarded) {
		q.bonus.rewarded = true;
		grantXp(data, q.bonus.xp, fx, {
			title: "BONUS OBJECTIVE",
			body: q.bonus.title,
			chime: true
		});
	}
	maybeDaily(data, fx);
}
function applyLink(data, link, amount, unit, fx) {
	if (!link || amount <= 0) return;
	const q = data.daily.quests.find((item) => item.link === link && !item.suspended);
	if (!q) return;
	if (q.unit === "reps" && unit !== "reps") return;
	let delta = amount;
	if (q.unit === "min" && unit === "sec") delta = amount / 60;
	if (q.unit === "sec" && unit === "min") delta = amount * 60;
	bumpQuest(data, q.id, delta, fx);
}
function recheckDaily(data, fx) {
	maybeDaily(data, fx);
}
function maybeDaily(data, fx) {
	if (data.daily.bonusClaimed || data.daily.rest) return;
	const active = data.daily.quests.filter((q) => !q.suspended);
	if (active.length === 0 || !active.every((q) => q.progress >= q.target)) return;
	data.daily.bonusClaimed = true;
	const today = todayKey();
	if (!data.questDays.includes(today)) data.questDays.push(today);
	grantXp(data, 80, fx, {
		title: "DAILY QUEST COMPLETED",
		body: "Rewards have been distributed.",
		chime: true
	});
	markTraining(data, fx);
}
function freshQuest(q) {
	return {
		...q,
		progress: 0,
		rewarded: false,
		suspended: false,
		bonus: q.bonus ? {
			...q.bonus,
			rewarded: false
		} : null
	};
}
function reconcile(data) {
	reconcileStreak(data);
	const today = todayKey();
	if (data.daily.date !== today) data.daily = {
		date: today,
		rest: false,
		bonusClaimed: false,
		quests: data.questTemplate.map(freshQuest)
	};
	if (data.logs.length > 400) data.logs = data.logs.slice(-400);
	if (data.measures.length > 400) data.measures = data.measures.slice(-400);
	if (data.questDays.length > 180) data.questDays = data.questDays.slice(-180);
	if (data.restDays.length > 180) data.restDays = data.restDays.slice(-180);
	if (data.dungeonHistory.length > 60) data.dungeonHistory = data.dungeonHistory.slice(-60);
}
function totalMinutes(data) {
	return data.logs.reduce((sum, log) => sum + log.durationSec, 0) / 60;
}
function bestSessionMin(data) {
	return data.logs.reduce((max, log) => Math.max(max, log.durationSec / 60), 0);
}
function skillProgress(data, skill) {
	if (skill.metric === "prReps" || skill.metric === "prHold") {
		const ex = data.exercises.find((e) => e.id === skill.exerciseId);
		const current = skill.metric === "prReps" ? ex?.prReps ?? 0 : ex?.prHold ?? 0;
		const unit = skill.metric === "prReps" ? "reps" : "sec";
		return {
			current,
			label: `${Math.floor(current)} / ${skill.threshold} ${unit}`
		};
	}
	if (skill.metric === "workouts") return {
		current: data.player.totalWorkouts,
		label: `${data.player.totalWorkouts} / ${skill.threshold} workouts`
	};
	if (skill.metric === "minutes") {
		const current = Math.floor(totalMinutes(data));
		return {
			current,
			label: `${current} / ${skill.threshold} min`
		};
	}
	if (skill.metric === "bestSessionMin") {
		const current = Math.floor(bestSessionMin(data));
		return {
			current,
			label: `${current} / ${skill.threshold} min in one mission`
		};
	}
	return {
		current: data.player.longestStreak,
		label: `${data.player.longestStreak} / ${skill.threshold} day streak`
	};
}
function touch(data, fx) {
	for (const skill of data.skills) {
		if (skill.unlockedAt) continue;
		if (skillProgress(data, skill).current + 1e-6 >= skill.threshold) {
			skill.unlockedAt = (/* @__PURE__ */ new Date()).toISOString();
			fx.notices.push(notice("SKILL ACQUIRED", skill.name, true));
			grantXp(data, 25, fx);
		}
	}
	if (isNational(data) && !data.nationalSeen) {
		data.nationalSeen = true;
		fx.notices.push(notice("NATIONAL LEVEL", "The System recognizes you.", true));
	}
}
function measured(data) {
	const pr = (id, mode) => {
		const ex = data.exercises.find((e) => e.id === id);
		if (!ex) return "—";
		if (mode === "reps") return ex.prReps > 0 ? String(ex.prReps) : "—";
		return ex.prHold > 0 ? `${ex.prHold}s` : "—";
	};
	const sleep = [...data.measures].reverse().find((m) => m.sleepH != null);
	return {
		str: pr("push-standard", "reps"),
		agi: pr("squat", "reps"),
		vit: sleep?.sleepH != null ? `${sleep.sleepH}h` : "—",
		end: pr("plank", "hold"),
		flex: pr("hamstring-reach", "hold"),
		disc: data.player.longestStreak > 0 ? `${data.player.longestStreak}d` : "—"
	};
}
function weeklyChallenges(data) {
	const week = weekStartKey();
	const start = parseDay(week).getTime();
	const claimed = new Set(data.weeklyClaims.find((w) => w.week === week)?.ids ?? []);
	const logs = data.logs.filter((log) => log.at >= start);
	const days = /* @__PURE__ */ new Set();
	for (const log of logs) days.add(todayKey(new Date(log.at)));
	for (const day of data.questDays) if (day >= week) days.add(day);
	const push = logs.reduce((sum, log) => sum + log.exercises.reduce((inner, ex) => inner + (ex.link === "push" ? ex.reps : 0), 0), 0);
	const boards = data.questDays.filter((day) => day >= week).length;
	const best = logs.reduce((max, log) => Math.max(max, log.durationSec / 60), 0);
	return [
		{
			id: "days",
			title: "Train 4 days",
			detail: "A workout log or a cleared daily board.",
			progress: days.size,
			target: 4,
			xp: 120,
			claimed: claimed.has("days")
		},
		{
			id: "push",
			title: "100 push-ups",
			detail: "Counted from logged sets and cleared gates.",
			progress: Math.round(push),
			target: 100,
			xp: 100,
			claimed: claimed.has("push")
		},
		{
			id: "boards",
			title: "Clear 3 daily boards",
			detail: "Full daily quest completion.",
			progress: boards,
			target: 3,
			xp: 150,
			claimed: claimed.has("boards")
		},
		{
			id: "long",
			title: "One 20-minute mission",
			detail: "A single logged session.",
			progress: Math.min(20, Math.floor(best)),
			target: 20,
			xp: 80,
			claimed: claimed.has("long")
		}
	];
}
function weekBuckets(logs) {
	const start = parseDay(weekStartKey());
	const buckets = [];
	for (let i = 7; i >= 0; i--) {
		const from = new Date(start);
		from.setDate(from.getDate() - i * 7);
		const to = new Date(from);
		to.setDate(to.getDate() + 7);
		const rows = logs.filter((log) => log.at >= from.getTime() && log.at < to.getTime());
		buckets.push({
			label: `${from.getMonth() + 1}/${from.getDate()}`,
			reps: rows.reduce((sum, log) => sum + log.volumeReps, 0),
			minutes: Math.round(rows.reduce((sum, log) => sum + log.durationSec, 0) / 60)
		});
	}
	return buckets;
}
function runPercent(run) {
	const open = run.objectives.every((o) => o.progress >= o.target);
	const ratios = run.objectives.map((o) => o.target ? o.progress / o.target : 0);
	if (open) ratios.push(run.bossTarget ? run.bossProgress / run.bossTarget : 0);
	if (!ratios.length) return 0;
	return Math.round(ratios.reduce((a, b) => a + b, 0) / ratios.length * 100);
}
function scaleTarget(n, unit, lighter) {
	if (!lighter) return n;
	const v = Math.round(n * .55);
	return unit === "reps" ? Math.max(8, v) : Math.max(30, v);
}
function allDungeons(data) {
	return [...DUNGEONS, ...data.customDungeons];
}
function chime(enabled, kind) {
	if (!enabled || typeof window === "undefined") return;
	const AudioCtx = window.AudioContext || window.webkitAudioContext;
	if (!AudioCtx) return;
	try {
		const ctx = new AudioCtx();
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = "sine";
		osc.frequency.value = kind === "level" ? 680 : 496;
		gain.gain.value = .035;
		osc.connect(gain);
		gain.connect(ctx.destination);
		osc.start();
		osc.frequency.exponentialRampToValueAtTime(kind === "level" ? 980 : 660, ctx.currentTime + .12);
		osc.stop(ctx.currentTime + .16);
		osc.onended = () => void ctx.close();
	} catch {}
}
function quest(partial) {
	return {
		...partial,
		progress: 0,
		suspended: false,
		rewarded: false,
		custom: false,
		bonus: partial.bonus ? {
			...partial.bonus,
			rewarded: false
		} : null
	};
}
function standardQuests() {
	return [
		quest({
			id: "push",
			title: "30 Push-ups",
			detail: "Stop the set if your hips collapse or your shoulders hurt.",
			target: 30,
			unit: "reps",
			xp: 40,
			difficulty: "E",
			link: "push",
			bonus: {
				title: "Bonus +10 push-ups",
				target: 10,
				xp: 15
			}
		}),
		quest({
			id: "squat",
			title: "40 Squats",
			detail: "Depth you control. Knees track over the toes.",
			target: 40,
			unit: "reps",
			xp: 40,
			difficulty: "E",
			link: "squat",
			bonus: {
				title: "Bonus +10 squats",
				target: 10,
				xp: 15
			}
		}),
		quest({
			id: "pull",
			title: "10 Pull-ups",
			detail: "Use Australian rows if you cannot hang yet. Edit the target.",
			target: 10,
			unit: "reps",
			xp: 50,
			difficulty: "D",
			link: "pull",
			bonus: null
		}),
		quest({
			id: "plank",
			title: "60-second Plank",
			detail: "Ribs down, glutes on. End it if your back starts to sag.",
			target: 60,
			unit: "sec",
			xp: 35,
			difficulty: "E",
			link: "plank",
			bonus: {
				title: "Bonus +30 seconds",
				target: 30,
				xp: 15
			}
		}),
		quest({
			id: "mobility",
			title: "10 minutes Mobility",
			detail: "Hips, shoulders, hamstrings. Breathe. Do not force range.",
			target: 10,
			unit: "min",
			xp: 30,
			difficulty: "E",
			link: "mobility",
			bonus: null
		})
	];
}
function presetQuests(preset) {
	if (preset === "standard") return standardQuests();
	if (preset === "awakening") return [
		quest({
			id: "push",
			title: "10 Push-ups",
			detail: "Knees or an incline are allowed. Pain is a stop.",
			target: 10,
			unit: "reps",
			xp: 30,
			difficulty: "E",
			link: "push",
			bonus: {
				title: "Bonus +5",
				target: 5,
				xp: 10
			}
		}),
		quest({
			id: "squat",
			title: "15 Squats",
			detail: "Sit to a chair if you need a target depth.",
			target: 15,
			unit: "reps",
			xp: 30,
			difficulty: "E",
			link: "squat",
			bonus: null
		}),
		quest({
			id: "pull",
			title: "8 Australian Rows",
			detail: "A table or bar you trust. Keep the body rigid.",
			target: 8,
			unit: "reps",
			xp: 30,
			difficulty: "E",
			link: "pull",
			bonus: null
		}),
		quest({
			id: "plank",
			title: "20-second Plank",
			detail: "Short and honest beats a long sag.",
			target: 20,
			unit: "sec",
			xp: 25,
			difficulty: "E",
			link: "plank",
			bonus: null
		}),
		quest({
			id: "mobility",
			title: "5 minutes Mobility",
			detail: "Easy range only.",
			target: 5,
			unit: "min",
			xp: 25,
			difficulty: "E",
			link: "mobility",
			bonus: null
		})
	];
	return [
		quest({
			id: "push",
			title: "50 Push-ups",
			detail: "Break into sets. Form ends the set, not pride.",
			target: 50,
			unit: "reps",
			xp: 55,
			difficulty: "D",
			link: "push",
			bonus: {
				title: "Bonus +10",
				target: 10,
				xp: 15
			}
		}),
		quest({
			id: "squat",
			title: "60 Squats",
			detail: "Leave two reps in reserve.",
			target: 60,
			unit: "reps",
			xp: 55,
			difficulty: "D",
			link: "squat",
			bonus: null
		}),
		quest({
			id: "pull",
			title: "15 Pull-ups",
			detail: "Rows count if the bar is not available. Edit if needed.",
			target: 15,
			unit: "reps",
			xp: 60,
			difficulty: "C",
			link: "pull",
			bonus: null
		}),
		quest({
			id: "plank",
			title: "90-second Plank",
			detail: "Split it if one hold is too long.",
			target: 90,
			unit: "sec",
			xp: 45,
			difficulty: "D",
			link: "plank",
			bonus: null
		}),
		quest({
			id: "mobility",
			title: "15 minutes Mobility",
			detail: "Unhurried. No bouncing into pain.",
			target: 15,
			unit: "min",
			xp: 40,
			difficulty: "D",
			link: "mobility",
			bonus: null
		})
	];
}
function ex(partial) {
	return {
		...partial,
		prReps: 0,
		prHold: 0,
		prAt: null,
		custom: false
	};
}
var EXERCISES = [
	ex({
		id: "push-standard",
		name: "Standard Push-ups",
		category: "Chest",
		mode: "reps",
		link: "push",
		difficulty: "E",
		xpPerSet: 10,
		defaultSets: 3,
		defaultReps: 10,
		defaultHold: 0,
		defaultRest: 60,
		instructions: "Hands under shoulders. Body one line. Chest travels to just above the floor. Full lockout."
	}),
	ex({
		id: "push-diamond",
		name: "Diamond Push-ups",
		category: "Triceps",
		mode: "reps",
		link: "push",
		difficulty: "C",
		xpPerSet: 14,
		defaultSets: 3,
		defaultReps: 6,
		defaultHold: 0,
		defaultRest: 75,
		instructions: "Hands together under the chest, thumbs and index fingers forming a diamond. Elbows track back, not flared."
	}),
	ex({
		id: "push-archer",
		name: "Archer Push-ups",
		category: "Chest",
		mode: "reps",
		link: "push",
		difficulty: "C",
		xpPerSet: 16,
		defaultSets: 3,
		defaultReps: 4,
		defaultHold: 0,
		defaultRest: 80,
		instructions: "Wide hands. Bend one arm while the other stays mostly straight. Alternate sides. Count a rep per working arm."
	}),
	ex({
		id: "push-pike",
		name: "Pike Push-ups",
		category: "Shoulders",
		mode: "reps",
		link: "push",
		difficulty: "C",
		xpPerSet: 14,
		defaultSets: 3,
		defaultReps: 6,
		defaultHold: 0,
		defaultRest: 75,
		instructions: "Hips high, body an inverted V. Lower the crown between the hands. Elevate the feet only when the floor version is easy."
	}),
	ex({
		id: "push-decline",
		name: "Decline Push-ups",
		category: "Chest",
		mode: "reps",
		link: "push",
		difficulty: "D",
		xpPerSet: 12,
		defaultSets: 3,
		defaultReps: 8,
		defaultHold: 0,
		defaultRest: 70,
		instructions: "Feet on a low step. Keep the ribs tucked so the low back does not dump."
	}),
	ex({
		id: "pull-up",
		name: "Pull-ups",
		category: "Back",
		mode: "reps",
		link: "pull",
		difficulty: "C",
		xpPerSet: 16,
		defaultSets: 3,
		defaultReps: 5,
		defaultHold: 0,
		defaultRest: 90,
		instructions: "Dead hang to chin over the bar. No kipping. Step down if the shoulder complains."
	}),
	ex({
		id: "chin-up",
		name: "Chin-ups",
		category: "Biceps",
		mode: "reps",
		link: "pull",
		difficulty: "C",
		xpPerSet: 16,
		defaultSets: 3,
		defaultReps: 5,
		defaultHold: 0,
		defaultRest: 90,
		instructions: "Palms toward you. Same full hang. Elbows drive down, not forward into a shrug."
	}),
	ex({
		id: "row-australian",
		name: "Australian Rows",
		category: "Back",
		mode: "reps",
		link: "pull",
		difficulty: "E",
		xpPerSet: 10,
		defaultSets: 3,
		defaultReps: 8,
		defaultHold: 0,
		defaultRest: 60,
		instructions: "Bar or sturdy table at hip height. Body straight, pull the chest to the bar. Walk your feet back to make it harder."
	}),
	ex({
		id: "row-inverted",
		name: "Inverted Rows",
		category: "Back",
		mode: "reps",
		link: "pull",
		difficulty: "D",
		xpPerSet: 12,
		defaultSets: 3,
		defaultReps: 8,
		defaultHold: 0,
		defaultRest: 70,
		instructions: "Lower bar than the Australian row, body closer to the floor. Pause at the chest."
	}),
	ex({
		id: "squat",
		name: "Squats",
		category: "Legs",
		mode: "reps",
		link: "squat",
		difficulty: "E",
		xpPerSet: 10,
		defaultSets: 3,
		defaultReps: 15,
		defaultHold: 0,
		defaultRest: 60,
		instructions: "Feet about shoulder width. Sit between the hips. Heels stay down. Stand tall without locking hard."
	}),
	ex({
		id: "split-squat",
		name: "Bulgarian Split Squats",
		category: "Legs",
		mode: "reps",
		link: "squat",
		difficulty: "D",
		xpPerSet: 14,
		defaultSets: 3,
		defaultReps: 6,
		defaultHold: 0,
		defaultRest: 70,
		instructions: "Rear foot on a low bench. Short stance. Front knee tracks the toes. Count reps per leg, then switch."
	}),
	ex({
		id: "lunge",
		name: "Lunges",
		category: "Legs",
		mode: "reps",
		link: "squat",
		difficulty: "E",
		xpPerSet: 10,
		defaultSets: 3,
		defaultReps: 8,
		defaultHold: 0,
		defaultRest: 60,
		instructions: "Step long enough that the back knee lowers under the hip. Torso tall. Alternate or complete one side."
	}),
	ex({
		id: "pistol",
		name: "Pistol Squats",
		category: "Legs",
		mode: "reps",
		link: "squat",
		difficulty: "A",
		xpPerSet: 22,
		defaultSets: 3,
		defaultReps: 3,
		defaultHold: 0,
		defaultRest: 90,
		instructions: "Hold a support. Free leg forward. Only go as deep as the knee allows. Pain in the joint means regress to a box pistol."
	}),
	ex({
		id: "nordic",
		name: "Nordic Curls",
		category: "Legs",
		mode: "reps",
		link: null,
		difficulty: "A",
		xpPerSet: 20,
		defaultSets: 3,
		defaultReps: 3,
		defaultHold: 0,
		defaultRest: 90,
		instructions: "Anchor the ankles safely. Lower as slowly as you can and push back up with your hands. Skip if the knee is irritated."
	}),
	ex({
		id: "plank",
		name: "Plank",
		category: "Core",
		mode: "hold",
		link: "plank",
		difficulty: "E",
		xpPerSet: 10,
		defaultSets: 3,
		defaultReps: 0,
		defaultHold: 30,
		defaultRest: 45,
		instructions: "Forearms down, pelvis slightly tucked, neck long. End the hold when the back sags."
	}),
	ex({
		id: "hollow",
		name: "Hollow Body Hold",
		category: "Core",
		mode: "hold",
		link: "plank",
		difficulty: "D",
		xpPerSet: 12,
		defaultSets: 3,
		defaultReps: 0,
		defaultHold: 20,
		defaultRest: 45,
		instructions: "Low back pressed into the floor. Arms and legs long. Bend the knees if the back peels up."
	}),
	ex({
		id: "lsit",
		name: "L-Sit",
		category: "Skills",
		mode: "hold",
		link: null,
		difficulty: "B",
		xpPerSet: 18,
		defaultSets: 3,
		defaultReps: 0,
		defaultHold: 10,
		defaultRest: 75,
		instructions: "Hands beside the hips, fingers forward. Lift the feet. Tuck the knees if a full L is not there yet. Log the honest variation."
	}),
	ex({
		id: "leg-raise",
		name: "Leg Raises",
		category: "Core",
		mode: "reps",
		link: null,
		difficulty: "D",
		xpPerSet: 12,
		defaultSets: 3,
		defaultReps: 8,
		defaultHold: 0,
		defaultRest: 50,
		instructions: "Lying or hanging. Low back stays quiet. Lower only as far as you can keep it there."
	}),
	ex({
		id: "sit-up",
		name: "Sit-ups",
		category: "Core",
		mode: "reps",
		link: null,
		difficulty: "E",
		xpPerSet: 8,
		defaultSets: 3,
		defaultReps: 10,
		defaultHold: 0,
		defaultRest: 45,
		instructions: "Feet free or lightly anchored. Do not yank the neck. A crunch is enough if a full sit-up bothers the back."
	}),
	ex({
		id: "handstand",
		name: "Handstand",
		category: "Skills",
		mode: "hold",
		link: null,
		difficulty: "B",
		xpPerSet: 18,
		defaultSets: 4,
		defaultReps: 0,
		defaultHold: 15,
		defaultRest: 70,
		instructions: "Face a wall. Kick up with control. Bail by stepping down, not crashing. Chest-to-wall is the cleaner version."
	}),
	ex({
		id: "front-lever",
		name: "Front Lever",
		category: "Skills",
		mode: "hold",
		link: null,
		difficulty: "A",
		xpPerSet: 22,
		defaultSets: 3,
		defaultReps: 0,
		defaultHold: 8,
		defaultRest: 90,
		instructions: "Tuck, advanced tuck, or one-leg. Hips level with shoulders. A short clean tuck outranks a sagging full lever."
	}),
	ex({
		id: "back-lever",
		name: "Back Lever",
		category: "Skills",
		mode: "hold",
		link: null,
		difficulty: "A",
		xpPerSet: 22,
		defaultSets: 3,
		defaultReps: 0,
		defaultHold: 8,
		defaultRest: 90,
		instructions: "Rings or bar. Tuck first. Shoulders stay depressed. Stop at any sharp front-shoulder pain."
	}),
	ex({
		id: "planche",
		name: "Planche",
		category: "Skills",
		mode: "hold",
		link: null,
		difficulty: "S",
		xpPerSet: 24,
		defaultSets: 3,
		defaultReps: 0,
		defaultHold: 8,
		defaultRest: 90,
		instructions: "Lean forward in a planche lean or tuck planche. Protract the shoulders. Wrists warm. Stop if they ache."
	}),
	ex({
		id: "hspu",
		name: "Handstand Push-ups",
		category: "Shoulders",
		mode: "reps",
		link: null,
		difficulty: "A",
		xpPerSet: 22,
		defaultSets: 3,
		defaultReps: 3,
		defaultHold: 0,
		defaultRest: 90,
		instructions: "Wall behind you. Head to a pad, not the bare floor, until you own the range. Partial range counts if you log it honestly."
	}),
	ex({
		id: "hip-openers",
		name: "Hip Openers",
		category: "Mobility",
		mode: "hold",
		link: "mobility",
		difficulty: "E",
		xpPerSet: 8,
		defaultSets: 2,
		defaultReps: 0,
		defaultHold: 60,
		defaultRest: 20,
		instructions: "Half-kneeling hip flexor. Tuck the pelvis. A gentle stretch, not a shove. 60 calm seconds."
	}),
	ex({
		id: "shoulder-circles",
		name: "Shoulder Circles",
		category: "Mobility",
		mode: "hold",
		link: "mobility",
		difficulty: "E",
		xpPerSet: 8,
		defaultSets: 2,
		defaultReps: 0,
		defaultHold: 60,
		defaultRest: 20,
		instructions: "Slow arm circles and a light sleeper or doorway chest opener. No pinching. Log the time you spent moving well."
	}),
	ex({
		id: "hamstring-reach",
		name: "Hamstring Reach",
		category: "Mobility",
		mode: "hold",
		link: "mobility",
		difficulty: "E",
		xpPerSet: 8,
		defaultSets: 2,
		defaultReps: 0,
		defaultHold: 60,
		defaultRest: 20,
		instructions: "One leg long, hinge from the hips with a flat back. Reach until strong tension, never nerve pain."
	}),
	ex({
		id: "wgs",
		name: "World's Greatest Stretch",
		category: "Mobility",
		mode: "reps",
		link: "mobility",
		difficulty: "E",
		xpPerSet: 8,
		defaultSets: 2,
		defaultReps: 5,
		defaultHold: 0,
		defaultRest: 20,
		instructions: "Deep lunge, elbow toward the instep, rotate the chest open. Slow reps. Each rep is one side."
	}),
	ex({
		id: "squat-thrust",
		name: "Squat Thrusts",
		category: "Full Body",
		mode: "reps",
		link: null,
		difficulty: "D",
		xpPerSet: 14,
		defaultSets: 3,
		defaultReps: 8,
		defaultHold: 0,
		defaultRest: 60,
		instructions: "Squat, step or jump the feet back to a plank, return, stand. Step back if impact is unwelcome. No flopping the hips."
	})
];
function skill(partial) {
	return {
		...partial,
		unlockedAt: null
	};
}
var SKILLS = [
	skill({
		id: "push-mastery",
		branch: "Strength",
		name: "Push-up Mastery",
		description: "A single clean set of thirty. The floor stopped being an excuse.",
		requirement: "30 standard push-ups in one logged set.",
		metric: "prReps",
		exerciseId: "push-standard",
		threshold: 30
	}),
	skill({
		id: "pull-mastery",
		branch: "Strength",
		name: "Pull-up Mastery",
		description: "Chin over the bar, eight times, without a kip.",
		requirement: "8 pull-ups in one logged set.",
		metric: "prReps",
		exerciseId: "pull-up",
		threshold: 8
	}),
	skill({
		id: "explosive",
		branch: "Strength",
		name: "Explosive Strength",
		description: "The diamond variation yields. Triceps and chest agree.",
		requirement: "15 diamond push-ups in one logged set.",
		metric: "prReps",
		exerciseId: "push-diamond",
		threshold: 15
	}),
	skill({
		id: "lsit",
		branch: "Calisthenics",
		name: "L-Sit",
		description: "The body leaves the floor and holds a line.",
		requirement: "Hold an L-sit, tuck allowed, for 15 seconds.",
		metric: "prHold",
		exerciseId: "lsit",
		threshold: 15
	}),
	skill({
		id: "handstand",
		branch: "Calisthenics",
		name: "Handstand",
		description: "Balance becomes a place you can stand.",
		requirement: "Hold a handstand for 20 seconds.",
		metric: "prHold",
		exerciseId: "handstand",
		threshold: 20
	}),
	skill({
		id: "front",
		branch: "Calisthenics",
		name: "Front Lever",
		description: "A straight line facing the sky. Tuck counts.",
		requirement: "Hold a front lever variation for 10 seconds.",
		metric: "prHold",
		exerciseId: "front-lever",
		threshold: 10
	}),
	skill({
		id: "back",
		branch: "Calisthenics",
		name: "Back Lever",
		description: "Shoulders open. The body hangs behind the hands.",
		requirement: "Hold a back lever variation for 10 seconds.",
		metric: "prHold",
		exerciseId: "back-lever",
		threshold: 10
	}),
	skill({
		id: "planche",
		branch: "Calisthenics",
		name: "Planche",
		description: "Weight shifts forward until the feet no longer matter.",
		requirement: "Hold a planche lean or tuck for 10 seconds.",
		metric: "prHold",
		exerciseId: "planche",
		threshold: 10
	}),
	skill({
		id: "conditioning",
		branch: "Endurance",
		name: "Conditioning",
		description: "Work stops feeling like an event and starts feeling like weather.",
		requirement: "Log 120 total training minutes.",
		metric: "minutes",
		exerciseId: null,
		threshold: 120
	}),
	skill({
		id: "capacity",
		branch: "Endurance",
		name: "Work Capacity",
		description: "You return often enough that the System expects you.",
		requirement: "Finish 12 meaningful workouts.",
		metric: "workouts",
		exerciseId: null,
		threshold: 12
	}),
	skill({
		id: "cardio",
		branch: "Endurance",
		name: "Cardiovascular Endurance",
		description: "One mission long enough to change your breathing.",
		requirement: "Complete a single session of 25 minutes.",
		metric: "bestSessionMin",
		exerciseId: null,
		threshold: 25
	}),
	skill({
		id: "hip",
		branch: "Mobility",
		name: "Hip Mobility",
		description: "The front of the hip learns to yield.",
		requirement: "Hold Hip Openers for 60 seconds in one set.",
		metric: "prHold",
		exerciseId: "hip-openers",
		threshold: 60
	}),
	skill({
		id: "shoulder",
		branch: "Mobility",
		name: "Shoulder Mobility",
		description: "The joint moves without a story of pinching.",
		requirement: "Log 60 seconds of Shoulder Circles in one set.",
		metric: "prHold",
		exerciseId: "shoulder-circles",
		threshold: 60
	}),
	skill({
		id: "hamstring",
		branch: "Mobility",
		name: "Hamstring Flexibility",
		description: "A hinge, not a yank. Tension without nerve pain.",
		requirement: "Hold Hamstring Reach for 60 seconds.",
		metric: "prHold",
		exerciseId: "hamstring-reach",
		threshold: 60
	})
];
function gate(partial) {
	return {
		...partial,
		custom: false
	};
}
var DUNGEONS = [
	gate({
		id: "goblin-cave",
		name: "Goblin Cave",
		rank: "E",
		levelRequired: 1,
		lore: "A low gate. The things inside are not impressive. Quitting is.",
		clearXp: 120,
		objectives: [
			{
				id: "g-push",
				label: "50 Push-ups",
				target: 50,
				unit: "reps",
				xp: 40,
				link: "push"
			},
			{
				id: "g-squat",
				label: "50 Squats",
				target: 50,
				unit: "reps",
				xp: 40,
				link: "squat"
			},
			{
				id: "g-sit",
				label: "30 Sit-ups",
				target: 30,
				unit: "reps",
				xp: 30,
				link: null
			},
			{
				id: "g-core",
				label: "5 minutes Core Work",
				target: 300,
				unit: "sec",
				xp: 40,
				link: "plank"
			}
		],
		bossName: "Hobgoblin",
		bossLabel: "20 Push-ups",
		bossTarget: 20,
		bossUnit: "reps",
		bossXp: 60,
		bossLink: "push"
	}),
	gate({
		id: "ash-wolf",
		name: "Ash Wolf Den",
		rank: "D",
		levelRequired: 11,
		lore: "The pack does not rush. It waits for your elbows to drop.",
		clearXp: 160,
		objectives: [
			{
				id: "w-row",
				label: "40 Australian Rows",
				target: 40,
				unit: "reps",
				xp: 45,
				link: "pull"
			},
			{
				id: "w-lunge",
				label: "40 Lunges",
				target: 40,
				unit: "reps",
				xp: 40,
				link: "squat"
			},
			{
				id: "w-hollow",
				label: "90-second Hollow Hold",
				target: 90,
				unit: "sec",
				xp: 40,
				link: "plank"
			}
		],
		bossName: "Den Mother",
		bossLabel: "12 Pull-ups or rows",
		bossTarget: 12,
		bossUnit: "reps",
		bossXp: 70,
		bossLink: "pull"
	}),
	gate({
		id: "frost",
		name: "Frost Cistern",
		rank: "C",
		levelRequired: 21,
		lore: "Cold stone. The only heat is the work.",
		clearXp: 200,
		objectives: [
			{
				id: "f-squat",
				label: "60 Squats",
				target: 60,
				unit: "reps",
				xp: 50,
				link: "squat"
			},
			{
				id: "f-push",
				label: "40 Push-ups",
				target: 40,
				unit: "reps",
				xp: 45,
				link: "push"
			},
			{
				id: "f-plank",
				label: "2-minute Plank",
				target: 120,
				unit: "sec",
				xp: 45,
				link: "plank"
			}
		],
		bossName: "Cistern Warden",
		bossLabel: "20 Pike Push-ups",
		bossTarget: 20,
		bossUnit: "reps",
		bossXp: 80,
		bossLink: "push"
	}),
	gate({
		id: "crimson",
		name: "Crimson Gate",
		rank: "B",
		levelRequired: 36,
		lore: "A gate that prefers quality. Sloppy reps do not count. You are the referee.",
		clearXp: 260,
		objectives: [
			{
				id: "c-diamond",
				label: "25 Diamond Push-ups",
				target: 25,
				unit: "reps",
				xp: 55,
				link: "push"
			},
			{
				id: "c-pull",
				label: "20 Pull-ups",
				target: 20,
				unit: "reps",
				xp: 60,
				link: "pull"
			},
			{
				id: "c-lunge",
				label: "40 Walking Lunges",
				target: 40,
				unit: "reps",
				xp: 50,
				link: "squat"
			}
		],
		bossName: "Gate Knight",
		bossLabel: "30-second L-Sit",
		bossTarget: 30,
		bossUnit: "sec",
		bossXp: 90,
		bossLink: null
	}),
	gate({
		id: "obsidian",
		name: "Obsidian Keep",
		rank: "A",
		levelRequired: 51,
		lore: "The keep does not care how many times you have cleared easier doors.",
		clearXp: 340,
		objectives: [
			{
				id: "o-archer",
				label: "30 Archer Push-ups",
				target: 30,
				unit: "reps",
				xp: 70,
				link: "push"
			},
			{
				id: "o-pull",
				label: "25 Pull-ups",
				target: 25,
				unit: "reps",
				xp: 70,
				link: "pull"
			},
			{
				id: "o-core",
				label: "3 minutes Core",
				target: 180,
				unit: "sec",
				xp: 55,
				link: "plank"
			}
		],
		bossName: "Keep Warden",
		bossLabel: "20-second Handstand",
		bossTarget: 20,
		bossUnit: "sec",
		bossXp: 100,
		bossLink: null
	}),
	gate({
		id: "ordeal",
		name: "Final Gate: Ordeal",
		rank: "S",
		levelRequired: 71,
		lore: "Not a monster. A mirror. Leave if anything hurts in the wrong way.",
		clearXp: 420,
		objectives: [
			{
				id: "s-pike",
				label: "40 Pike Push-ups",
				target: 40,
				unit: "reps",
				xp: 80,
				link: "push"
			},
			{
				id: "s-pull",
				label: "20 Pull-ups",
				target: 20,
				unit: "reps",
				xp: 70,
				link: "pull"
			},
			{
				id: "s-skill",
				label: "20-second Skill Hold",
				target: 20,
				unit: "sec",
				xp: 80,
				link: null
			}
		],
		bossName: "The Quiet",
		bossLabel: "40 Push-ups",
		bossTarget: 40,
		bossUnit: "reps",
		bossXp: 120,
		bossLink: "push"
	})
];
function item(exerciseId, sets, reps, hold, rest) {
	return {
		exerciseId,
		sets,
		reps,
		hold,
		rest
	};
}
var ROUTINES = [
	{
		id: "circuit-e",
		name: "E-Rank Circuit",
		focus: "Full Body",
		custom: false,
		items: [
			item("push-standard", 3, 10, 0, 60),
			item("squat", 3, 15, 0, 60),
			item("row-australian", 3, 8, 0, 60),
			item("plank", 3, 0, 30, 45)
		]
	},
	{
		id: "push-gate",
		name: "Push Gate",
		focus: "Chest",
		custom: false,
		items: [
			item("push-standard", 4, 8, 0, 70),
			item("push-diamond", 3, 6, 0, 75),
			item("push-pike", 3, 6, 0, 75),
			item("push-decline", 3, 8, 0, 70)
		]
	},
	{
		id: "pull-gate",
		name: "Pull Gate",
		focus: "Back",
		custom: false,
		items: [
			item("row-australian", 3, 10, 0, 60),
			item("row-inverted", 3, 8, 0, 70),
			item("pull-up", 4, 4, 0, 90),
			item("chin-up", 3, 4, 0, 90)
		]
	},
	{
		id: "lower-gate",
		name: "Lower Gate",
		focus: "Legs",
		custom: false,
		items: [
			item("squat", 4, 12, 0, 60),
			item("lunge", 3, 8, 0, 60),
			item("split-squat", 3, 6, 0, 75),
			item("nordic", 3, 3, 0, 90)
		]
	},
	{
		id: "core-gate",
		name: "Core Gate",
		focus: "Core",
		custom: false,
		items: [
			item("plank", 3, 0, 40, 40),
			item("hollow", 3, 0, 20, 40),
			item("leg-raise", 3, 8, 0, 50),
			item("sit-up", 3, 12, 0, 45)
		]
	},
	{
		id: "mobility-flow",
		name: "Mobility Flow",
		focus: "Mobility",
		custom: false,
		items: [
			item("hip-openers", 2, 0, 60, 15),
			item("shoulder-circles", 2, 0, 60, 15),
			item("hamstring-reach", 2, 0, 60, 15),
			item("wgs", 2, 5, 0, 20)
		]
	},
	{
		id: "skill-practice",
		name: "Skill Practice",
		focus: "Skills",
		custom: false,
		items: [
			item("lsit", 4, 0, 10, 70),
			item("handstand", 5, 0, 15, 60),
			item("hollow", 3, 0, 20, 40)
		]
	}
];
function createInitial() {
	const template = standardQuests();
	return {
		v: 1,
		player: {
			name: "THE PLAYER",
			title: "Unknown",
			level: 1,
			xp: 0,
			lifetimeXp: 0,
			points: 0,
			stats: {
				str: 8,
				agi: 8,
				vit: 8,
				end: 8,
				flex: 8,
				disc: 8
			},
			streak: 0,
			longestStreak: 0,
			lastTrainingDate: null,
			lastMeaningfulDate: null,
			totalWorkouts: 0,
			recovery: false,
			recoveryNote: ""
		},
		settings: { sound: false },
		seenIntro: false,
		nationalSeen: false,
		questTemplate: template.map(freshQuest),
		daily: {
			date: todayKey(),
			rest: false,
			bonusClaimed: false,
			quests: template.map(freshQuest)
		},
		exercises: EXERCISES.map((e) => ({ ...e })),
		routines: ROUTINES.map((r) => ({
			...r,
			items: r.items.map((i) => ({ ...i }))
		})),
		session: null,
		logs: [],
		skills: SKILLS.map((s) => ({ ...s })),
		customDungeons: [],
		dungeonRecords: {},
		dungeonHistory: [],
		dungeonRun: null,
		measures: [],
		weeklyClaims: [],
		questDays: [],
		restDays: []
	};
}
function normalizeQuest(raw, fallback) {
	if (!raw || typeof raw !== "object") return freshQuest(fallback);
	const unit = raw.unit === "sec" || raw.unit === "min" || raw.unit === "reps" ? raw.unit : fallback.unit;
	const bonus = raw.bonus ? {
		title: String(raw.bonus.title || "Bonus").slice(0, 48),
		target: clamp(num(raw.bonus.target, 0), 0, 100),
		xp: clamp(num(raw.bonus.xp, 10), 0, 200),
		rewarded: Boolean(raw.bonus.rewarded)
	} : null;
	return {
		id: String(raw.id || fallback.id),
		title: String(raw.title || fallback.title).slice(0, 48),
		detail: String(raw.detail || "").slice(0, 180),
		target: clamp(num(raw.target, fallback.target), 1, unit === "min" ? 45 : unit === "sec" ? 600 : 200),
		unit,
		progress: Math.max(0, num(raw.progress, 0)),
		xp: clamp(num(raw.xp, fallback.xp), 5, 300),
		difficulty: [
			"E",
			"D",
			"C",
			"B",
			"A",
			"S"
		].includes(raw.difficulty) ? raw.difficulty : "E",
		link: raw.link === "push" || raw.link === "squat" || raw.link === "pull" || raw.link === "plank" || raw.link === "mobility" ? raw.link : null,
		bonus: bonus && bonus.target > 0 ? bonus : null,
		suspended: Boolean(raw.suspended),
		rewarded: Boolean(raw.rewarded),
		custom: Boolean(raw.custom)
	};
}
function normalize(raw) {
	const base = createInitial();
	if (!raw || typeof raw !== "object") return base;
	const r = raw;
	const savedExercises = Array.isArray(r.exercises) ? r.exercises : [];
	const exercises = base.exercises.map((builtin) => {
		const saved = savedExercises.find((e) => e.id === builtin.id);
		if (!saved) return builtin;
		return {
			...builtin,
			prReps: Math.max(0, num(saved.prReps, 0)),
			prHold: Math.max(0, num(saved.prHold, 0)),
			prAt: typeof saved.prAt === "string" ? saved.prAt : null
		};
	});
	for (const saved of savedExercises) {
		if (!saved || exercises.some((e) => e.id === saved.id) || !saved.custom) continue;
		exercises.push({
			id: String(saved.id),
			name: String(saved.name || "Custom").slice(0, 40),
			category: EXERCISES.map((e) => e.category).includes(String(saved.category)) ? saved.category : "Full Body",
			mode: saved.mode === "hold" ? "hold" : "reps",
			link: saved.link === "push" || saved.link === "squat" || saved.link === "pull" || saved.link === "plank" || saved.link === "mobility" ? saved.link : null,
			instructions: String(saved.instructions || "").slice(0, 240),
			difficulty: [
				"E",
				"D",
				"C",
				"B",
				"A",
				"S"
			].includes(saved.difficulty) ? saved.difficulty : "E",
			xpPerSet: clamp(num(saved.xpPerSet, 10), 4, 40),
			defaultSets: clamp(num(saved.defaultSets, 3), 1, 8),
			defaultReps: clamp(num(saved.defaultReps, 8), 0, 50),
			defaultHold: clamp(num(saved.defaultHold, 20), 0, 180),
			defaultRest: clamp(num(saved.defaultRest, 60), 10, 180),
			prReps: Math.max(0, num(saved.prReps, 0)),
			prHold: Math.max(0, num(saved.prHold, 0)),
			prAt: typeof saved.prAt === "string" ? saved.prAt : null,
			custom: true
		});
	}
	const savedSkills = Array.isArray(r.skills) ? r.skills : [];
	const skills = base.skills.map((builtin) => {
		const saved = savedSkills.find((s) => s.id === builtin.id);
		return {
			...builtin,
			unlockedAt: saved && typeof saved.unlockedAt === "string" ? saved.unlockedAt : null
		};
	});
	const customRoutines = (Array.isArray(r.routines) ? r.routines : []).filter((item) => item && item.custom);
	const routines = [...base.routines, ...customRoutines.map((routine) => ({
		id: String(routine.id || uid("routine")),
		name: String(routine.name || "Custom mission").slice(0, 40),
		focus: String(routine.focus || "Custom").slice(0, 24),
		custom: true,
		items: Array.isArray(routine.items) ? routine.items.filter((it) => it && typeof it.exerciseId === "string").slice(0, 12).map((it) => ({
			exerciseId: it.exerciseId,
			sets: clamp(num(it.sets, 3), 1, 8),
			reps: clamp(num(it.reps, 8), 0, 50),
			hold: clamp(num(it.hold, 0), 0, 180),
			rest: clamp(num(it.rest, 60), 10, 180)
		})) : []
	}))].filter((routine) => routine.items.length > 0 || !routine.custom);
	const questTemplate = (Array.isArray(r.questTemplate) && r.questTemplate.length ? r.questTemplate : base.questTemplate).slice(0, 8).map((q, i) => normalizeQuest(q, base.questTemplate[i] || base.questTemplate[0]));
	const dailyRaw = r.daily;
	const daily = {
		date: dailyRaw && typeof dailyRaw.date === "string" ? dailyRaw.date : todayKey(),
		rest: Boolean(dailyRaw?.rest),
		bonusClaimed: Boolean(dailyRaw?.bonusClaimed),
		quests: dailyRaw && Array.isArray(dailyRaw.quests) && dailyRaw.quests.length ? dailyRaw.quests.slice(0, 8).map((q, i) => normalizeQuest(q, questTemplate[i] || questTemplate[0])) : questTemplate.map(freshQuest)
	};
	const playerRaw = r.player;
	const stats = { ...base.player.stats };
	for (const stat of STATS) stats[stat.key] = clamp(num(playerRaw?.stats?.[stat.key], 8), 1, 99);
	return {
		v: 1,
		player: {
			...base.player,
			name: String(playerRaw?.name || base.player.name).slice(0, 24) || "THE PLAYER",
			title: String(playerRaw?.title || "Unknown").slice(0, 32) || "Unknown",
			level: clamp(num(playerRaw?.level, 1), 1, 200),
			xp: Math.max(0, num(playerRaw?.xp, 0)),
			lifetimeXp: Math.max(0, num(playerRaw?.lifetimeXp, 0)),
			points: clamp(num(playerRaw?.points, 0), 0, 999),
			stats,
			streak: Math.max(0, num(playerRaw?.streak, 0)),
			longestStreak: Math.max(0, num(playerRaw?.longestStreak, 0)),
			lastTrainingDate: typeof playerRaw?.lastTrainingDate === "string" ? playerRaw.lastTrainingDate : null,
			lastMeaningfulDate: typeof playerRaw?.lastMeaningfulDate === "string" ? playerRaw.lastMeaningfulDate : null,
			totalWorkouts: Math.max(0, num(playerRaw?.totalWorkouts, 0)),
			recovery: Boolean(playerRaw?.recovery),
			recoveryNote: String(playerRaw?.recoveryNote || "").slice(0, 140)
		},
		settings: { sound: Boolean(r.settings?.sound) },
		seenIntro: Boolean(r.seenIntro),
		nationalSeen: Boolean(r.nationalSeen),
		questTemplate,
		daily,
		exercises,
		routines,
		session: validateSession(r.session, exercises),
		logs: Array.isArray(r.logs) ? r.logs.slice(-400) : [],
		skills,
		customDungeons: Array.isArray(r.customDungeons) ? r.customDungeons.slice(0, 12) : [],
		dungeonRecords: r.dungeonRecords && typeof r.dungeonRecords === "object" ? r.dungeonRecords : {},
		dungeonHistory: Array.isArray(r.dungeonHistory) ? r.dungeonHistory.slice(-60) : [],
		dungeonRun: r.dungeonRun && typeof r.dungeonRun === "object" && Array.isArray(r.dungeonRun.objectives) ? r.dungeonRun : null,
		measures: Array.isArray(r.measures) ? r.measures.slice(-400) : [],
		weeklyClaims: Array.isArray(r.weeklyClaims) ? r.weeklyClaims : [],
		questDays: Array.isArray(r.questDays) ? r.questDays.filter((d) => typeof d === "string") : [],
		restDays: Array.isArray(r.restDays) ? r.restDays.filter((d) => typeof d === "string") : []
	};
}
function validateSession(session, exercises) {
	if (!session || !Array.isArray(session.items) || session.items.length === 0) return null;
	if (!exercises.length) return null;
	return session;
}
function xpForDifficulty(d) {
	return XP_FOR_DIFF[d];
}
function formatProgress(progress, target, unit) {
	const shown = Math.min(progress, target);
	if (unit === "sec") return `${Math.floor(shown)}/${target}s`;
	if (unit === "min") return `${Math.floor(shown)}/${target}m`;
	return `${Math.floor(shown)}/${target}`;
}
function dailyQuestDoneCount(data) {
	const active = data.daily.quests.filter((q) => !q.suspended);
	return {
		done: active.filter((q) => q.progress >= q.target).length,
		total: active.length,
		claimed: data.daily.bonusClaimed,
		rest: data.daily.rest
	};
}
function trainingDaysThisWeek(data) {
	const week = weekStartKey();
	const start = parseDay(week).getTime();
	const days = /* @__PURE__ */ new Set();
	for (const log of data.logs) if (log.at >= start) days.add(todayKey(new Date(log.at)));
	for (const day of data.questDays) if (day >= week) days.add(day);
	return days.size;
}
function exerciseOf(data, id) {
	return data.exercises.find((e) => e.id === id);
}
function buildSession(data, name, items) {
	const built = [];
	for (const spec of items) {
		const exercise = exerciseOf(data, spec.exerciseId);
		if (!exercise) continue;
		const sets = clamp(spec.sets, 1, 8);
		built.push({
			exerciseId: exercise.id,
			name: exercise.name,
			category: exercise.category,
			mode: exercise.mode,
			link: exercise.link,
			instructions: exercise.instructions,
			difficulty: exercise.difficulty,
			xpPerSet: exercise.xpPerSet,
			targetReps: exercise.mode === "reps" ? clamp(spec.reps || exercise.defaultReps, 1, 50) : 0,
			targetHold: exercise.mode === "hold" ? clamp(spec.hold || exercise.defaultHold, 5, 180) : 0,
			rest: clamp(spec.rest || exercise.defaultRest, 10, 180),
			sets: Array.from({ length: sets }, () => ({
				reps: 0,
				hold: 0,
				done: false
			})),
			skipped: false,
			holdEndsAt: null,
			holdStartedAt: null
		});
	}
	if (!built.length) return null;
	return {
		name,
		startedAt: Date.now(),
		index: 0,
		restEndsAt: null,
		items: built,
		xp: 0,
		prs: []
	};
}
function currentSet(item) {
	return item.sets.find((set) => !set.done) ?? null;
}
function advanceSession(data, fx) {
	const session = data.session;
	if (!session) return;
	const item = session.items[session.index];
	if (item && item.sets.some((set) => !set.done) && !item.skipped) {
		session.restEndsAt = Date.now() + item.rest * 1e3;
		return;
	}
	let next = session.index + 1;
	while (next < session.items.length && session.items[next].skipped) next += 1;
	if (next >= session.items.length) finishSession(data, fx, false);
	else {
		session.index = next;
		session.restEndsAt = item ? Date.now() + Math.min(item.rest, 60) * 1e3 : null;
	}
}
function recordPr(data, session, exerciseId, mode, value, fx) {
	const exercise = exerciseOf(data, exerciseId);
	if (!exercise || value <= 0) return;
	if (!(mode === "reps" ? value > exercise.prReps : value > exercise.prHold)) return;
	if (mode === "reps") exercise.prReps = value;
	else exercise.prHold = value;
	exercise.prAt = todayKey();
	if (!session.prs.includes(exercise.name)) session.prs.push(exercise.name);
	session.xp += 50;
	grantXp(data, 50, fx, {
		title: "PERSONAL RECORD",
		body: `${exercise.name} · ${value}${mode === "hold" ? "s" : ""}`,
		chime: true
	});
}
function awardSet(data, session, item, ratio, fx) {
	const xp = Math.max(4, Math.round(item.xpPerSet * clamp(ratio, .35, 1)));
	session.xp += xp;
	grantXp(data, xp, fx, {
		title: "SET CLEARED",
		body: `${item.name} · +${xp} XP`
	});
}
function logRepSet(data, repsIn, fx) {
	const session = data.session;
	if (!session) return;
	if (session.restEndsAt && Date.now() < session.restEndsAt) return;
	session.restEndsAt = null;
	const item = session.items[session.index];
	if (!item || item.mode !== "reps" || item.skipped) return;
	const set = currentSet(item);
	if (!set) return;
	const reps = clamp(Math.round(repsIn), 1, 80);
	set.reps = reps;
	set.done = true;
	awardSet(data, session, item, reps / Math.max(1, item.targetReps), fx);
	recordPr(data, session, item.exerciseId, "reps", reps, fx);
	applyLink(data, item.link, reps, "reps", fx);
	advanceSession(data, fx);
}
function beginHold(data) {
	const session = data.session;
	if (!session) return;
	if (session.restEndsAt && Date.now() < session.restEndsAt) return;
	session.restEndsAt = null;
	const item = session.items[session.index];
	if (!item || item.mode !== "hold" || item.holdEndsAt) return;
	item.holdStartedAt = Date.now();
	item.holdEndsAt = Date.now() + item.targetHold * 1e3;
}
function completeHold(data, fx, early = false) {
	const session = data.session;
	if (!session) return;
	const item = session.items[session.index];
	if (!item || !item.holdStartedAt) return;
	const set = currentSet(item);
	if (!set) {
		item.holdEndsAt = null;
		item.holdStartedAt = null;
		return;
	}
	const elapsedRaw = Math.round((Date.now() - item.holdStartedAt) / 1e3);
	const elapsed = clamp(early ? elapsedRaw : Math.max(elapsedRaw, item.targetHold), 1, item.targetHold);
	item.holdEndsAt = null;
	item.holdStartedAt = null;
	set.hold = elapsed;
	set.done = true;
	awardSet(data, session, item, elapsed / Math.max(1, item.targetHold), fx);
	recordPr(data, session, item.exerciseId, "hold", elapsed, fx);
	applyLink(data, item.link, elapsed, "sec", fx);
	advanceSession(data, fx);
}
function pumpSession(data, fx) {
	const session = data.session;
	if (!session) return false;
	const item = session.items[session.index];
	if (item?.holdEndsAt && Date.now() >= item.holdEndsAt) {
		completeHold(data, fx, false);
		return true;
	}
	return false;
}
function skipRest(data) {
	if (data.session) data.session.restEndsAt = null;
}
function adjustRest(data, delta) {
	const session = data.session;
	if (!session) return;
	const item = session.items[session.index];
	if (!item) return;
	item.rest = clamp(item.rest + delta, 10, 180);
	if (session.restEndsAt) session.restEndsAt = Math.max(Date.now(), session.restEndsAt + delta * 1e3);
}
function skipExercise(data, fx) {
	const session = data.session;
	if (!session) return;
	const item = session.items[session.index];
	if (!item) return;
	item.skipped = true;
	item.holdEndsAt = null;
	item.holdStartedAt = null;
	session.restEndsAt = null;
	advanceSession(data, fx);
}
function doneSetsOf(session) {
	return session.items.reduce((sum, item) => sum + item.sets.filter((set) => set.done).length, 0);
}
function finishSession(data, fx, partial) {
	const session = data.session;
	if (!session) return;
	const doneSets = doneSetsOf(session);
	const full = !partial && session.items.every((item) => !item.skipped && item.sets.every((set) => set.done));
	const volumeReps = session.items.reduce((sum, item) => sum + item.sets.reduce((inner, set) => inner + (set.done ? set.reps : 0), 0), 0);
	const volumeHold = session.items.reduce((sum, item) => sum + item.sets.reduce((inner, set) => inner + (set.done ? set.hold : 0), 0), 0);
	const durationSec = Math.max(1, Math.round((Date.now() - session.startedAt) / 1e3));
	if (full && doneSets > 0) {
		session.xp += 40;
		grantXp(data, 40, fx, {
			title: "MISSION COMPLETE",
			body: "Rewards have been distributed.",
			chime: true
		});
	} else if (doneSets > 0) fx.notices.push(notice("EXTRACTED", "Partial credit kept. No clear bonus."));
	else fx.notices.push(notice("MISSION ABORTED", "Nothing was logged."));
	const meaningful = full || doneSets >= 2 || volumeReps >= 15 || volumeHold >= 45;
	if (doneSets > 0) data.logs.push({
		id: uid("log"),
		name: session.name,
		at: Date.now(),
		durationSec,
		volumeReps,
		volumeHold,
		xp: session.xp,
		kind: "workout",
		prs: session.prs,
		exercises: session.items.filter((item) => item.sets.some((set) => set.done)).map((item) => ({
			name: item.name,
			link: item.link,
			category: item.category,
			reps: item.sets.reduce((sum, set) => sum + (set.done ? set.reps : 0), 0),
			hold: item.sets.reduce((sum, set) => sum + (set.done ? set.hold : 0), 0),
			sets: item.sets.filter((set) => set.done).length
		}))
	});
	if (meaningful) {
		data.player.totalWorkouts += 1;
		markTraining(data, fx);
	}
	data.session = null;
}
function startDungeon(data, id, lighter, fx) {
	if (data.session) {
		fx.notices.push(notice("MISSION OPEN", "Extract from training before entering a gate."));
		return;
	}
	if (data.dungeonRun) {
		fx.notices.push(notice("GATE OPEN", "Finish or withdraw from the current gate."));
		return;
	}
	if (data.player.recovery) {
		fx.notices.push(notice("RECOVERY", "Gates stay shut while recovery is active."));
		return;
	}
	const def = allDungeons(data).find((d) => d.id === id);
	if (!def) return;
	if (!def.custom && data.player.level < def.levelRequired) {
		fx.notices.push(notice("SEALED", `Requires level ${def.levelRequired}.`));
		return;
	}
	data.dungeonRun = {
		dungeonId: def.id,
		name: def.name,
		rank: def.rank,
		startedAt: Date.now(),
		lighter,
		clearXp: def.clearXp,
		bossName: def.bossName,
		bossLabel: def.bossLabel,
		bossTarget: scaleTarget(def.bossTarget, def.bossUnit, lighter),
		bossProgress: 0,
		bossUnit: def.bossUnit,
		bossXp: def.bossXp,
		bossLink: def.bossLink,
		bossRewarded: false,
		xp: 0,
		objectives: def.objectives.map((o) => ({
			...o,
			target: scaleTarget(o.target, o.unit, lighter),
			progress: 0,
			rewarded: false
		}))
	};
	fx.notices.push(notice("GATE OPENED", lighter ? `${def.name} · lighter gate` : def.name));
}
function bossOpen(run) {
	return run.objectives.every((o) => o.progress >= o.target);
}
function maybeClearDungeon(data, fx) {
	const run = data.dungeonRun;
	if (!run || run.bossRewarded === false) return;
	if (!bossOpen(run)) return;
	endDungeon(data, fx, true);
}
function bumpObjective(data, id, delta, fx) {
	const run = data.dungeonRun;
	if (!run) return;
	const ob = run.objectives.find((o) => o.id === id);
	if (!ob) return;
	const next = clamp(ob.progress + delta, 0, ob.target);
	if (ob.rewarded && next < ob.target) return;
	const applied = next - ob.progress;
	ob.progress = next;
	if (applied > 0) applyLink(data, ob.link, applied, ob.unit, fx);
	if (ob.progress >= ob.target && !ob.rewarded) {
		ob.rewarded = true;
		run.xp += ob.xp;
		grantXp(data, ob.xp, fx, {
			title: "OBJECTIVE CLEARED",
			body: ob.label,
			chime: true
		});
	}
}
function bumpBoss(data, delta, fx) {
	const run = data.dungeonRun;
	if (!run || !bossOpen(run)) return;
	const next = clamp(run.bossProgress + delta, 0, run.bossTarget);
	if (run.bossRewarded && next < run.bossTarget) return;
	const applied = next - run.bossProgress;
	run.bossProgress = next;
	if (applied > 0) applyLink(data, run.bossLink, applied, run.bossUnit, fx);
	if (run.bossProgress >= run.bossTarget && !run.bossRewarded) {
		run.bossRewarded = true;
		run.xp += run.bossXp;
		grantXp(data, run.bossXp, fx, {
			title: "BOSS DEFEATED",
			body: run.bossName,
			chime: true
		});
		maybeClearDungeon(data, fx);
	}
}
function endDungeon(data, fx, cleared) {
	const run = data.dungeonRun;
	if (!run) return;
	const sec = Math.max(1, Math.round((Date.now() - run.startedAt) / 1e3));
	if (cleared) {
		run.xp += run.clearXp;
		grantXp(data, run.clearXp, fx, {
			title: "GATE CLEARED",
			body: `${run.name}. Rewards have been distributed.`,
			chime: true
		});
		const rec = data.dungeonRecords[run.dungeonId] ?? {
			clears: 0,
			bestSec: null,
			lastClear: null
		};
		rec.clears += 1;
		rec.bestSec = rec.bestSec == null ? sec : Math.min(rec.bestSec, sec);
		rec.lastClear = todayKey();
		data.dungeonRecords[run.dungeonId] = rec;
	} else if (run.xp > 0 || run.objectives.some((o) => o.progress > 0)) fx.notices.push(notice("WITHDREW", "The gate closed. Credit already earned stays."));
	const reps = run.objectives.reduce((sum, o) => sum + (o.unit === "reps" ? o.progress : 0), 0) + (run.bossUnit === "reps" ? run.bossProgress : 0);
	const hold = run.objectives.reduce((sum, o) => sum + (o.unit === "sec" ? o.progress : 0), 0) + (run.bossUnit === "sec" ? run.bossProgress : 0);
	if (reps > 0 || hold > 0) data.logs.push({
		id: uid("log"),
		name: run.name,
		at: Date.now(),
		durationSec: sec,
		volumeReps: reps,
		volumeHold: hold,
		xp: run.xp,
		kind: "dungeon",
		prs: [],
		exercises: [...run.objectives.map((o) => ({
			name: o.label,
			link: o.link,
			category: "Full Body",
			reps: o.unit === "reps" ? o.progress : 0,
			hold: o.unit === "sec" ? o.progress : 0,
			sets: o.progress > 0 ? 1 : 0
		})), {
			name: run.bossName,
			link: run.bossLink,
			category: "Full Body",
			reps: run.bossUnit === "reps" ? run.bossProgress : 0,
			hold: run.bossUnit === "sec" ? run.bossProgress : 0,
			sets: run.bossProgress > 0 ? 1 : 0
		}].filter((e) => e.reps > 0 || e.hold > 0)
	});
	if (cleared || reps >= 15 || hold >= 45) {
		data.player.totalWorkouts += 1;
		markTraining(data, fx);
	}
	data.dungeonHistory.push({
		id: uid("clear"),
		dungeonId: run.dungeonId,
		name: run.name,
		rank: run.rank,
		at: Date.now(),
		sec,
		xp: run.xp,
		cleared
	});
	data.dungeonRun = null;
}
function claimWeek(data, id, fx) {
	const challenge = weeklyChallenges(data).find((c) => c.id === id);
	if (!challenge || challenge.claimed || challenge.progress < challenge.target) return;
	const week = weekStartKey();
	const bucket = data.weeklyClaims.find((w) => w.week === week);
	if (bucket) bucket.ids.push(id);
	else data.weeklyClaims.push({
		week,
		ids: [id]
	});
	grantXp(data, challenge.xp, fx, {
		title: "WEEKLY CLEARED",
		body: challenge.title,
		chime: true
	});
}
function applyPreset(data, preset, fx) {
	if (data.daily.quests.some((q) => q.rewarded || q.bonus?.rewarded)) {
		fx.notices.push(notice("LOCKED", "The protocol locks after the first reward today."));
		return;
	}
	const next = presetQuests(preset).map(freshQuest);
	data.questTemplate = next;
	data.daily = {
		date: todayKey(),
		rest: data.daily.rest,
		bonusClaimed: false,
		quests: next.map(freshQuest)
	};
	data.seenIntro = true;
	fx.notices.push(notice("PROTOCOL SET", preset === "awakening" ? "Awakening." : preset === "monarch" ? "Monarch." : "Standard."));
}
function syncQuestEdit(data, next) {
	const clean = freshQuest({
		...next,
		title: next.title.slice(0, 48),
		detail: next.detail.slice(0, 180)
	});
	clean.target = clamp(next.target, 1, next.unit === "min" ? 45 : next.unit === "sec" ? 600 : 200);
	clean.xp = clamp(next.xp, 5, 300);
	const applyToday = (q) => ({
		...clean,
		progress: Math.min(q.progress, clean.target + (clean.bonus?.target ?? 0)),
		rewarded: q.rewarded && q.progress >= clean.target,
		suspended: q.suspended,
		bonus: clean.bonus ? {
			...clean.bonus,
			rewarded: Boolean(q.bonus?.rewarded) && q.progress >= clean.target + clean.bonus.target
		} : null
	});
	data.questTemplate = data.questTemplate.map((q) => q.id === clean.id ? clean : q);
	data.daily.quests = data.daily.quests.map((q) => q.id === clean.id ? applyToday(q) : q);
}
var CATEGORIES = [
	"Chest",
	"Back",
	"Shoulders",
	"Biceps",
	"Triceps",
	"Legs",
	"Core",
	"Full Body",
	"Mobility",
	"Skills"
];
var DIFFICULTIES = [
	"E",
	"D",
	"C",
	"B",
	"A",
	"S"
];
function commit(set, get, mut) {
	const fx = emptyFx();
	set((state) => {
		const data = structuredClone(state.data);
		mut(data, fx);
		touch(data, fx);
		return {
			data,
			notices: fx.notices.length ? [...state.notices, ...fx.notices].slice(-5) : state.notices,
			levelUps: fx.levels.length ? [...state.levelUps, ...fx.levels] : state.levelUps
		};
	});
	const next = get();
	idbSet(next.data);
	if (next.data.settings.sound && (fx.levels.length > 0 || fx.notices.some((n) => n.chime))) chime(true, fx.levels.length > 0 ? "level" : "quest");
}
var useArise = create((set, get) => ({
	ready: false,
	data: createInitial(),
	tab: "home",
	notices: [],
	levelUps: [],
	boot: async () => {
		if (get().ready) return;
		try {
			const saved = await idbGet();
			const data = saved ? normalize(saved) : createInitial();
			reconcile(data);
			set({
				data,
				ready: true
			});
			await idbSet(data);
		} catch {
			const data = createInitial();
			reconcile(data);
			set({
				data,
				ready: true
			});
		}
	},
	pump: () => {
		const state = get();
		if (!state.ready) return;
		const session = state.data.session;
		const item = session?.items[session.index];
		const holdDue = Boolean(item?.holdEndsAt && Date.now() >= item.holdEndsAt);
		const dayDue = state.data.daily.date !== todayKey();
		if (!holdDue && !dayDue) return;
		const fx = emptyFx();
		const data = structuredClone(state.data);
		if (holdDue) pumpSession(data, fx);
		if (data.daily.date !== todayKey()) reconcile(data);
		touch(data, fx);
		set({
			data,
			notices: fx.notices.length ? [...state.notices, ...fx.notices].slice(-5) : state.notices,
			levelUps: fx.levels.length ? [...state.levelUps, ...fx.levels] : state.levelUps
		});
		idbSet(get().data);
		if (get().data.settings.sound && (fx.levels.length > 0 || fx.notices.some((n) => n.chime))) chime(true, fx.levels.length > 0 ? "level" : "quest");
	},
	dismissNotice: () => set((state) => ({ notices: state.notices.slice(1) })),
	dismissLevel: () => set((state) => ({ levelUps: state.levelUps.slice(1) })),
	setTab: (tab) => set({ tab }),
	allocate: (stat) => commit(set, get, (data, fx) => {
		if (data.player.points <= 0) return;
		if (data.player.stats[stat] >= 99) {
			fx.notices.push(notice("CAP", "That attribute is full."));
			return;
		}
		data.player.points -= 1;
		data.player.stats[stat] += 1;
	}),
	setIdentity: (name, title) => commit(set, get, (data) => {
		data.player.name = name.trim().slice(0, 24) || "THE PLAYER";
		data.player.title = title.trim().slice(0, 32) || "Unknown";
	}),
	toggleSound: () => commit(set, get, (data) => {
		data.settings.sound = !data.settings.sound;
	}),
	toggleRecovery: () => commit(set, get, (data, fx) => {
		data.player.recovery = !data.player.recovery;
		data.player.lastMeaningfulDate = todayKey();
		if (data.player.recovery) {
			data.session = null;
			if (data.dungeonRun) endDungeon(data, fx, false);
			fx.notices.push(notice("RECOVERY", "Quests may be suspended. The streak will hold."));
		} else fx.notices.push(notice("RECOVERY LIFTED", "Train only if you are ready."));
	}),
	setRecoveryNote: (note) => commit(set, get, (data) => {
		data.player.recoveryNote = note.slice(0, 140);
	}),
	toggleRest: () => commit(set, get, (data, fx) => {
		const today = todayKey();
		data.daily.rest = !data.daily.rest;
		if (data.daily.rest) {
			if (!data.restDays.includes(today)) data.restDays.push(today);
			data.player.lastMeaningfulDate = today;
			fx.notices.push(notice("REST DAY", "The streak is protected. Nothing is required."));
		} else {
			data.restDays = data.restDays.filter((day) => day !== today);
			fx.notices.push(notice("REST CANCELLED", "Today is a training day again."));
		}
	}),
	addQuestProgress: (id, delta) => commit(set, get, (data, fx) => bumpQuest(data, id, delta, fx)),
	suspendQuest: (id) => commit(set, get, (data, fx) => {
		const q = data.daily.quests.find((item) => item.id === id);
		if (!q) return;
		q.suspended = !q.suspended;
		recheckDaily(data, fx);
		fx.notices.push(notice(q.suspended ? "QUEST SUSPENDED" : "QUEST RESTORED", q.title));
	}),
	saveQuest: (quest) => commit(set, get, (data, fx) => {
		syncQuestEdit(data, quest);
		recheckDaily(data, fx);
	}),
	addQuest: (quest) => commit(set, get, (data, fx) => {
		if (data.questTemplate.length >= 8) {
			fx.notices.push(notice("LIMIT", "Eight quests is the board's limit."));
			return;
		}
		const next = freshQuest({
			...quest,
			id: uid("quest"),
			custom: true
		});
		data.questTemplate.push(next);
		data.daily.quests.push(freshQuest(next));
	}),
	deleteQuest: (id) => commit(set, get, (data, fx) => {
		if (data.questTemplate.length <= 1) {
			fx.notices.push(notice("LIMIT", "The board needs at least one quest."));
			return;
		}
		data.questTemplate = data.questTemplate.filter((q) => q.id !== id);
		data.daily.quests = data.daily.quests.filter((q) => q.id !== id);
		recheckDaily(data, fx);
	}),
	acceptProtocol: (preset) => commit(set, get, (data, fx) => applyPreset(data, preset, fx)),
	dismissIntro: () => commit(set, get, (data) => {
		data.seenIntro = true;
	}),
	addExercise: (exercise) => commit(set, get, (data, fx) => {
		const difficulty = exercise.difficulty;
		data.exercises.push({
			...exercise,
			id: uid("ex"),
			name: exercise.name.trim().slice(0, 40) || "Custom exercise",
			instructions: exercise.instructions.trim().slice(0, 240),
			xpPerSet: xpForDifficulty(difficulty),
			prReps: 0,
			prHold: 0,
			prAt: null,
			custom: true
		});
		fx.notices.push(notice("EXERCISE RECORDED", exercise.name.trim() || "Custom exercise"));
	}),
	deleteExercise: (id) => commit(set, get, (data, fx) => {
		if (!data.exercises.find((e) => e.id === id)?.custom) return;
		if (data.session?.items.some((item) => item.exerciseId === id)) {
			fx.notices.push(notice("IN USE", "Extract from the open mission first."));
			return;
		}
		data.exercises = data.exercises.filter((e) => e.id !== id);
		data.routines = data.routines.map((routine) => ({
			...routine,
			items: routine.items.filter((item) => item.exerciseId !== id)
		})).filter((routine) => !routine.custom || routine.items.length > 0);
	}),
	startRoutine: (routineId) => commit(set, get, (data, fx) => {
		if (data.session) {
			fx.notices.push(notice("MISSION OPEN", "Extract before starting another."));
			return;
		}
		if (data.dungeonRun) {
			fx.notices.push(notice("GATE OPEN", "Withdraw from the gate before another mission."));
			return;
		}
		const routine = data.routines.find((r) => r.id === routineId);
		if (!routine) return;
		const session = buildSession(data, routine.name, routine.items);
		if (!session) {
			fx.notices.push(notice("EMPTY", "That routine has no available exercises."));
			return;
		}
		data.session = session;
	}),
	startItems: (name, items) => commit(set, get, (data, fx) => {
		if (data.session) {
			fx.notices.push(notice("MISSION OPEN", "Extract before starting another."));
			return;
		}
		if (data.dungeonRun) {
			fx.notices.push(notice("GATE OPEN", "Withdraw from the gate before another mission."));
			return;
		}
		const session = buildSession(data, name, items);
		if (!session) return;
		data.session = session;
	}),
	saveRoutine: (name, focus, items) => commit(set, get, (data, fx) => {
		if (!items.length) return;
		data.routines.push({
			id: uid("routine"),
			name: name.trim().slice(0, 40) || "Custom mission",
			focus: focus.trim().slice(0, 24) || "Custom",
			custom: true,
			items
		});
		fx.notices.push(notice("ROUTINE SAVED", name.trim() || "Custom mission"));
	}),
	deleteRoutine: (id) => commit(set, get, (data) => {
		data.routines = data.routines.filter((routine) => routine.id !== id || !routine.custom);
	}),
	logReps: (reps) => commit(set, get, (data, fx) => logRepSet(data, reps, fx)),
	startHold: () => commit(set, get, (data) => {
		beginHold(data);
	}),
	finishHold: (early) => commit(set, get, (data, fx) => completeHold(data, fx, early)),
	restSkip: () => commit(set, get, (data) => {
		skipRest(data);
	}),
	restAdjust: (delta) => commit(set, get, (data) => {
		adjustRest(data, delta);
	}),
	skipCurrent: () => commit(set, get, (data, fx) => skipExercise(data, fx)),
	extractMission: () => commit(set, get, (data, fx) => finishSession(data, fx, true)),
	openGate: (id, lighter) => commit(set, get, (data, fx) => startDungeon(data, id, lighter, fx)),
	logObjective: (id, delta) => commit(set, get, (data, fx) => bumpObjective(data, id, delta, fx)),
	logBoss: (delta) => commit(set, get, (data, fx) => bumpBoss(data, delta, fx)),
	withdrawGate: () => commit(set, get, (data, fx) => endDungeon(data, fx, false)),
	forgeGate: (def) => commit(set, get, (data, fx) => {
		if (data.customDungeons.length >= 8) {
			fx.notices.push(notice("LIMIT", "Eight forged gates is enough."));
			return;
		}
		data.customDungeons.push(def);
		fx.notices.push(notice("GATE FORGED", def.name));
	}),
	deleteGate: (id) => commit(set, get, (data, fx) => {
		if (data.dungeonRun?.dungeonId === id) {
			fx.notices.push(notice("IN USE", "Withdraw before deleting this gate."));
			return;
		}
		data.customDungeons = data.customDungeons.filter((d) => d.id !== id);
	}),
	addMeasure: (measure) => commit(set, get, (data, fx) => {
		data.measures.push({
			id: uid("m"),
			at: Date.now(),
			weightKg: measure.weightKg,
			sleepH: measure.sleepH,
			fatigue: measure.fatigue,
			soreness: measure.soreness,
			note: measure.note.slice(0, 140)
		});
		if (measure.sleepH != null && measure.sleepH > 0) data.player.lastMeaningfulDate = todayKey();
		fx.notices.push(notice("RECORD FILED", "Recovery log updated."));
	}),
	claimChallenge: (id) => commit(set, get, (data, fx) => claimWeek(data, id, fx)),
	importSave: (raw) => {
		try {
			const data = normalize(JSON.parse(raw));
			reconcile(data);
			set({
				data,
				notices: [notice("IMPORT COMPLETE", "The System restored your record.")],
				levelUps: []
			});
			idbSet(data);
			return null;
		} catch {
			return "The System could not read that file.";
		}
	},
	resetAll: () => {
		const data = createInitial();
		data.seenIntro = true;
		set({
			data,
			notices: [notice("SYSTEM RESET", "All progress was erased.")],
			levelUps: [],
			tab: "home"
		});
		idbSet(data);
	}
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Panel({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("sys-panel p-4", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "corner tl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "corner tr" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "corner bl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "corner br" }),
			children
		]
	});
}
var VARIANTS = {
	primary: "border border-blue bg-blue text-abyss hover:bg-cyan",
	ghost: "border border-blue/50 bg-transparent text-cyan hover:border-cyan",
	danger: "border border-danger/60 bg-transparent text-danger hover:bg-danger/10",
	legend: "border border-legend/50 bg-legend/10 text-legend hover:bg-legend/20"
};
function SysButton({ variant = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 px-4 text-base font-semibold tracking-wide", "transition-transform duration-150 ease-out active:scale-[0.96] disabled:cursor-not-allowed disabled:opacity-40 disabled:active:scale-100", VARIANTS[variant], className),
		...props
	});
}
function XpBar({ value, max }) {
	const pct = max <= 0 ? 0 : Math.max(0, Math.min(1, value / max));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "xp-track",
		role: "meter",
		"aria-valuenow": Math.round(value),
		"aria-valuemax": max,
		"aria-label": "Experience",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "xp-fill",
			style: { transform: `scaleX(${pct})` }
		})
	});
}
function rankTone(code) {
	if (code === "N" || code === "S" || code === "A") return "text-legend";
	if (code === "B" || code === "C") return "text-cyan";
	return "text-blue";
}
function diffTone(d) {
	if (d === "S" || d === "A") return "text-legend";
	if (d === "B" || d === "C") return "text-cyan";
	return "text-blue";
}
function formatUnit(value, unit) {
	if (unit === "sec") return `${Math.floor(value)}s`;
	if (unit === "min") return `${Math.floor(value)}m`;
	return `${Math.floor(value)}`;
}
function HomeScreen({ data }) {
	const allocate = useArise((s) => s.allocate);
	const setTab = useArise((s) => s.setTab);
	const rank = rankLabel(data);
	const need = xpNeeded(data.player.level);
	const quests = dailyQuestDoneCount(data);
	const records = measured(data);
	const week = trainingDaysThisWeek(data);
	const level = String(data.player.level).padStart(2, "0");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "[ System ] · Player status"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display mt-1 text-4xl",
				children: "Status window"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-[15rem_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					className: "overflow-hidden p-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative aspect-[4/5] max-h-80 md:max-h-none md:aspect-[3/4]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/art/hunter.jpg",
								alt: "A hunter standing in a field of cyan light",
								className: "h-full w-full object-cover object-top"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-t from-abyss via-abyss/20 to-transparent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `display text-2xl ${rankTone(rank.code)}`,
									children: rank.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-mist",
									children: ["Level ", level]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `display grid h-14 w-14 place-items-center border border-cyan text-2xl ${rankTone(rank.code)}`,
									"aria-hidden": true,
									children: rank.code
								})]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Player information"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusLine, {
								label: "Name",
								value: data.player.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusLine, {
								label: "Title",
								value: data.player.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusLine, {
								label: "Rank",
								value: rank.name,
								tone: rankTone(rank.code)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusLine, {
								label: "Level",
								value: level
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-mist",
							children: [
								"EXP ",
								Math.floor(data.player.xp),
								" / ",
								need
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-cyan",
							children: [data.player.points, " stat points"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(XpBar, {
							value: data.player.xp,
							max: need
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-mist",
						children: "Points are a reward. The numbers under each attribute are what you actually logged."
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Attributes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children: STATS.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-14 items-center gap-2 border-b border-blue/30 py-2 last:border-b-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker w-12 shrink-0",
							children: stat.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-ink",
								children: stat.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-mist",
								children: [
									stat.blurb,
									" · ",
									records[stat.key]
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display w-8 shrink-0 text-right text-2xl",
							children: data.player.stats[stat.key]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							variant: "ghost",
							className: "min-h-11 min-w-11 shrink-0 px-0",
							disabled: data.player.points <= 0 || data.player.stats[stat.key] >= 99,
							onClick: () => allocate(stat.key),
							"aria-label": `Invest one point in ${stat.name}`,
							children: "+"
						})
					]
				}, stat.key))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 md:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Daily quests",
						value: data.daily.rest ? "REST" : `${quests.done}/${quests.total || 0}`,
						detail: quests.claimed ? "Board cleared" : "In progress"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Streak",
						value: `${data.player.streak}`,
						detail: `Best ${data.player.longestStreak}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Workouts",
						value: `${data.player.totalWorkouts}`,
						detail: "Logged missions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "This week",
						value: `${week}/4`,
						detail: "Training days"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Daily quest"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
					variant: "ghost",
					className: "px-3",
					onClick: () => setTab("quests"),
					children: "Open board"
				})]
			}), data.daily.rest ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-mist",
				children: "Rest day. The streak holds. Nothing on this board is required."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2",
				children: data.daily.quests.map((quest) => {
					const done = quest.rewarded || quest.suspended;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTab("quests"),
						className: "flex min-h-11 w-full items-center gap-3 text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `h-4 w-4 shrink-0 border ${quest.rewarded ? "border-cyan bg-cyan" : quest.suspended ? "border-legend" : "border-blue"}`,
								"aria-hidden": true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `min-w-0 flex-1 truncate ${done ? "text-mist" : "text-ink"}`,
								children: quest.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-mist",
								children: quest.suspended ? "Held" : formatProgress(quest.progress, quest.target, quest.unit)
							})
						]
					}) }, quest.id);
				})
			})] }),
			data.player.recovery && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker text-legend",
					children: "Recovery active"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-mist",
					children: "Gates are shut. The streak will not break. Train only if it helps."
				}),
				data.player.recoveryNote && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-ink",
					children: data.player.recoveryNote
				})
			] })
		]
	});
}
function StatusLine({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "status-line",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "kicker",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: `truncate text-lg font-semibold ${tone ?? "text-ink"}`,
			children: value
		})]
	});
}
function Metric({ label, value, detail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "display mt-2 text-2xl",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: detail
			})
		]
	});
}
var LINKS = [
	{
		id: "none",
		label: "No auto-count"
	},
	{
		id: "push",
		label: "Push-ups"
	},
	{
		id: "squat",
		label: "Squats"
	},
	{
		id: "pull",
		label: "Pulls / rows"
	},
	{
		id: "plank",
		label: "Core holds"
	},
	{
		id: "mobility",
		label: "Mobility"
	}
];
function QuestsScreen({ data }) {
	const addQuestProgress = useArise((s) => s.addQuestProgress);
	const suspendQuest = useArise((s) => s.suspendQuest);
	const saveQuest = useArise((s) => s.saveQuest);
	const addQuest = useArise((s) => s.addQuest);
	const deleteQuest = useArise((s) => s.deleteQuest);
	const toggleRest = useArise((s) => s.toggleRest);
	const acceptProtocol = useArise((s) => s.acceptProtocol);
	const claimChallenge = useArise((s) => s.claimChallenge);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [creating, setCreating] = (0, import_react.useState)(false);
	const week = weeklyChallenges(data);
	const lockedPreset = data.daily.quests.some((q) => q.rewarded || q.bonus?.rewarded);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "System // Daily quest"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-1 text-3xl",
					children: "Quests"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
					variant: data.daily.rest ? "legend" : "ghost",
					onClick: toggleRest,
					children: data.daily.rest ? "Resting" : "Rest day"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Pain, illness, or a joint that complains means suspend the quest. A rest day protects the streak. The System will not demand an unsafe volume — edit every target."
			}),
			data.daily.rest && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Rest day"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-ink",
				children: "Nothing is required. Training still counts if you choose it. The daily clear bonus waits."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: data.daily.quests.map((quest, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestCard, {
					index: index + 1,
					quest,
					editing: editing === quest.id,
					onEdit: () => setEditing(editing === quest.id ? null : quest.id),
					onProgress: addQuestProgress,
					onSuspend: suspendQuest,
					onSave: (next) => {
						saveQuest(next);
						setEditing(null);
					},
					onDelete: deleteQuest
				}, quest.id))
			}),
			creating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestForm, {
				title: "New quest",
				initial: {
					id: "new",
					title: "",
					detail: "",
					target: 10,
					unit: "reps",
					progress: 0,
					xp: 25,
					difficulty: "E",
					link: null,
					bonus: null,
					suspended: false,
					rewarded: false,
					custom: true
				},
				onCancel: () => setCreating(false),
				onSubmit: (quest) => {
					addQuest(quest);
					setCreating(false);
				}
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
				variant: "ghost",
				onClick: () => setCreating(true),
				children: "Create quest"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Protocol"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-mist",
					children: lockedPreset ? "Locked after the first reward today." : "Replace today's board. Progress today is cleared."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid gap-2 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							variant: "ghost",
							disabled: lockedPreset,
							onClick: () => acceptProtocol("awakening"),
							children: "Awakening"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							variant: "ghost",
							disabled: lockedPreset,
							onClick: () => acceptProtocol("standard"),
							children: "Standard"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							variant: "legend",
							disabled: lockedPreset,
							onClick: () => acceptProtocol("monarch"),
							children: "Monarch"
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Weekly challenges"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-3",
				children: week.map((challenge) => {
					const pct = Math.min(100, Math.round(challenge.progress / challenge.target * 100));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-semibold",
								children: challenge.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-mist",
								children: challenge.detail
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-cyan",
								children: [
									"+",
									challenge.xp,
									" XP"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-mist",
							children: [
								Math.min(challenge.progress, challenge.target),
								" / ",
								challenge.target
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "xp-track mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "xp-fill",
								style: { transform: `scaleX(${pct / 100})` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							className: "mt-3",
							disabled: challenge.claimed || challenge.progress < challenge.target,
							onClick: () => claimChallenge(challenge.id),
							children: challenge.claimed ? "Claimed" : "Claim reward"
						})
					] }, challenge.id);
				})
			})] })
		]
	});
}
function QuestCard({ index, quest, editing, onEdit, onProgress, onSuspend, onSave, onDelete }) {
	const main = Math.min(quest.progress, quest.target);
	const bonusProgress = quest.bonus ? Math.max(0, quest.progress - quest.target) : 0;
	const step = quest.unit === "sec" ? 15 : 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: quest.suspended ? "opacity-60" : void 0,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "kicker",
						children: [
							String(index).padStart(2, "0"),
							" · ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: diffTone(quest.difficulty),
								children: [quest.difficulty, "-RANK"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-semibold",
						children: quest.title
					}),
					quest.detail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-mist",
						children: quest.detail
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "shrink-0 text-cyan",
					children: [
						"+",
						quest.xp,
						" XP"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-mist",
				children: [
					formatUnit(main, quest.unit),
					" / ",
					formatUnit(quest.target, quest.unit),
					quest.rewarded ? " · cleared" : "",
					quest.suspended ? " · suspended" : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "xp-track mt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "xp-fill",
					style: { transform: `scaleX(${quest.target ? main / quest.target : 0})` }
				})
			}),
			quest.bonus && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-legend",
				children: [
					quest.bonus.title,
					": ",
					formatUnit(Math.min(bonusProgress, quest.bonus.target), quest.unit),
					" / ",
					formatUnit(quest.bonus.target, quest.unit),
					" · +",
					quest.bonus.xp,
					" XP"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
						variant: "ghost",
						className: "min-w-11 px-3",
						onClick: () => onProgress(quest.id, -step),
						"aria-label": "Decrease progress",
						children: "−"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SysButton, {
						className: "min-w-11 px-3",
						onClick: () => onProgress(quest.id, step),
						disabled: quest.suspended,
						children: ["+", step]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
						variant: "ghost",
						disabled: quest.suspended || quest.rewarded,
						onClick: () => onProgress(quest.id, Math.max(0, quest.target - quest.progress)),
						children: "Complete"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
						variant: "ghost",
						onClick: () => onSuspend(quest.id),
						children: quest.suspended ? "Restore" : "Suspend"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
						variant: "ghost",
						onClick: onEdit,
						children: editing ? "Close" : "Edit"
					})
				]
			}),
			editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestForm, {
				className: "mt-4",
				title: "Edit quest",
				initial: quest,
				submitLabel: "Save",
				onSubmit: onSave,
				onDelete: () => onDelete(quest.id)
			})
		]
	});
}
function QuestForm({ title, initial, submitLabel = "Add quest", onSubmit, onCancel, onDelete, className }) {
	const [draft, setDraft] = (0, import_react.useState)(initial);
	const [bonusOn, setBonusOn] = (0, import_react.useState)(Boolean(initial.bonus));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: className ? `mt-4 grid gap-3 ${className}` : "sys-panel grid gap-3 p-4",
		onSubmit: (event) => {
			event.preventDefault();
			onSubmit({
				...draft,
				title: draft.title.trim() || "Untitled quest",
				bonus: bonusOn ? {
					title: draft.bonus?.title?.trim() || "Bonus",
					target: Math.max(1, draft.bonus?.target || 5),
					xp: draft.bonus?.xp || 10,
					rewarded: draft.bonus?.rewarded || false
				} : null
			});
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 text-sm text-mist",
				children: ["Title", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: draft.title,
					maxLength: 48,
					onChange: (e) => setDraft({
						...draft,
						title: e.target.value
					}),
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 text-sm text-mist",
				children: ["Note", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: draft.detail,
					maxLength: 180,
					onChange: (e) => setDraft({
						...draft,
						detail: e.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm text-mist",
						children: ["Target", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "number",
							min: 1,
							max: draft.unit === "min" ? 45 : draft.unit === "sec" ? 600 : 200,
							value: draft.target,
							onChange: (e) => setDraft({
								...draft,
								target: Number(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm text-mist",
						children: ["Unit", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field",
							value: draft.unit,
							onChange: (e) => setDraft({
								...draft,
								unit: e.target.value
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "reps",
									children: "Reps"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "sec",
									children: "Seconds"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "min",
									children: "Minutes"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm text-mist",
						children: ["XP", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "number",
							min: 5,
							max: 300,
							value: draft.xp,
							onChange: (e) => setDraft({
								...draft,
								xp: Number(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm text-mist",
						children: ["Rank", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field",
							value: draft.difficulty,
							onChange: (e) => setDraft({
								...draft,
								difficulty: e.target.value
							}),
							children: DIFFICULTIES.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: d,
								children: d
							}, d))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 text-sm text-mist",
				children: ["Counts from training", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "field",
					value: draft.link ?? "none",
					onChange: (e) => setDraft({
						...draft,
						link: e.target.value === "none" ? null : e.target.value
					}),
					children: LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: link.id,
						children: link.label
					}, link.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: bonusOn,
					onChange: (e) => setBonusOn(e.target.checked)
				}), "Optional bonus objective"]
			}),
			bonusOn && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field col-span-2",
						placeholder: "Bonus title",
						value: draft.bonus?.title ?? "",
						onChange: (e) => setDraft({
							...draft,
							bonus: {
								title: e.target.value,
								target: draft.bonus?.target || 5,
								xp: draft.bonus?.xp || 10,
								rewarded: false
							}
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "number",
						min: 1,
						max: 100,
						value: draft.bonus?.target ?? 5,
						onChange: (e) => setDraft({
							...draft,
							bonus: {
								title: draft.bonus?.title || "Bonus",
								target: Number(e.target.value),
								xp: draft.bonus?.xp || 10,
								rewarded: false
							}
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "number",
						min: 5,
						max: 200,
						value: draft.bonus?.xp ?? 10,
						onChange: (e) => setDraft({
							...draft,
							bonus: {
								title: draft.bonus?.title || "Bonus",
								target: draft.bonus?.target || 5,
								xp: Number(e.target.value),
								rewarded: false
							}
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
						type: "submit",
						children: submitLabel
					}),
					onCancel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
						variant: "ghost",
						onClick: onCancel,
						children: "Cancel"
					}),
					onDelete && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
						variant: "danger",
						onClick: onDelete,
						children: "Delete"
					})
				]
			})
		]
	});
}
function WorkoutScreen({ data }) {
	const startRoutine = useArise((s) => s.startRoutine);
	const startItems = useArise((s) => s.startItems);
	const saveRoutine = useArise((s) => s.saveRoutine);
	const deleteRoutine = useArise((s) => s.deleteRoutine);
	const addExercise = useArise((s) => s.addExercise);
	const deleteExercise = useArise((s) => s.deleteExercise);
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [builder, setBuilder] = (0, import_react.useState)([]);
	const [routineName, setRoutineName] = (0, import_react.useState)("Custom mission");
	const [creating, setCreating] = (0, import_react.useState)(false);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	function updateRow(index, patch) {
		setBuilder((rows) => rows.map((row, i) => i === index ? {
			...row,
			...patch
		} : row));
	}
	const exercises = (0, import_react.useMemo)(() => data.exercises.filter((exercise) => filter === "All" || exercise.category === filter), [data.exercises, filter]);
	function addToBuilder(exercise) {
		setBuilder((rows) => [...rows, {
			exerciseId: exercise.id,
			sets: exercise.defaultSets,
			reps: exercise.defaultReps,
			hold: exercise.defaultHold,
			rest: exercise.defaultRest
		}]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "System // Training"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-1 text-3xl",
					children: "Workout"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-mist",
					children: "Home training only. Leave a rep in reserve. If a joint speaks, the mission is over."
				})
			] }),
			builder.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Mission builder"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 grid gap-1 text-sm text-mist",
					children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: routineName,
						maxLength: 40,
						onChange: (e) => setRoutineName(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-2",
					children: builder.map((row, index) => {
						const exercise = data.exercises.find((e) => e.id === row.exerciseId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-center gap-2 border border-blue/30 p-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-32 flex-1 text-ink",
									children: exercise?.name ?? "Missing"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
									label: "Sets",
									value: row.sets,
									min: 1,
									max: 8,
									onChange: (sets) => updateRow(index, { sets })
								}),
								exercise?.mode === "hold" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
									label: "Sec",
									value: row.hold,
									min: 5,
									max: 180,
									step: 5,
									onChange: (hold) => updateRow(index, { hold })
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Count, {
									label: "Reps",
									value: row.reps,
									min: 1,
									max: 50,
									onChange: (reps) => updateRow(index, { reps })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
									variant: "ghost",
									className: "px-3",
									onClick: () => setBuilder((rows) => rows.filter((_, i) => i !== index)),
									children: "Remove"
								})
							]
						}, `${row.exerciseId}-${index}`);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							onClick: () => startItems(routineName.trim() || "Custom mission", builder),
							children: "Start mission"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							variant: "ghost",
							onClick: () => saveRoutine(routineName, "Custom", builder),
							children: "Save routine"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							variant: "danger",
							onClick: () => setBuilder([]),
							children: "Clear"
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Routines"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-3",
				children: data.routines.map((routine) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: routine.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-mist",
						children: [
							routine.focus,
							" · ",
							routine.items.length,
							" exercises"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							onClick: () => startRoutine(routine.id),
							children: "Start"
						}), routine.custom && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							variant: "danger",
							onClick: () => deleteRoutine(routine.id),
							children: "Delete"
						})]
					})]
				}, routine.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Library"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex gap-2 overflow-x-auto pb-1",
					children: ["All", ...CATEGORIES].map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter(category),
						className: `min-h-11 shrink-0 border px-3 text-sm ${filter === category ? "border-cyan text-cyan" : "border-blue/40 text-mist"}`,
						children: category
					}, category))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid gap-3",
					children: exercises.map((exercise) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-start justify-between gap-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: `kicker ${diffTone(exercise.difficulty)}`,
									children: [
										exercise.category,
										" · ",
										exercise.difficulty
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-lg font-semibold",
									children: exercise.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-mist",
									children: [
										exercise.mode === "reps" ? `${exercise.defaultSets} × ${exercise.defaultReps}` : `${exercise.defaultSets} × ${exercise.defaultHold}s`,
										" · +",
										exercise.xpPerSet,
										" XP / set"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-cyan",
									children: [
										"Record ",
										exercise.mode === "reps" ? exercise.prReps ? `${exercise.prReps} reps` : "none" : exercise.prHold ? `${exercise.prHold}s` : "none",
										exercise.prAt ? ` · ${exercise.prAt}` : ""
									]
								})
							] })
						}),
						openId === exercise.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-mist",
							children: exercise.instructions
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
									onClick: () => startItems(exercise.name, [{
										exerciseId: exercise.id,
										sets: exercise.defaultSets,
										reps: exercise.defaultReps,
										hold: exercise.defaultHold,
										rest: exercise.defaultRest
									}]),
									children: "Start"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
									variant: "ghost",
									onClick: () => addToBuilder(exercise),
									children: "Add"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
									variant: "ghost",
									onClick: () => setOpenId(openId === exercise.id ? null : exercise.id),
									children: openId === exercise.id ? "Hide" : "How"
								}),
								exercise.custom && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
									variant: "danger",
									onClick: () => deleteExercise(exercise.id),
									children: "Delete"
								})
							]
						})
					] }, exercise.id))
				})
			] }),
			creating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExerciseForm, {
				onCancel: () => setCreating(false),
				onSubmit: (draft) => {
					addExercise(draft);
					setCreating(false);
				}
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
				variant: "ghost",
				onClick: () => setCreating(true),
				children: "Create exercise"
			})
		]
	});
}
function Count({ label, value, min, max, step = 1, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1 text-sm text-mist",
		children: [
			label,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11 min-w-11 border border-blue/40 text-ink",
				onClick: () => onChange(Math.max(min, value - step)),
				children: "−"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-8 text-center text-ink",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11 min-w-11 border border-blue/40 text-ink",
				onClick: () => onChange(Math.min(max, value + step)),
				children: "+"
			})
		]
	});
}
function ExerciseForm({ onSubmit, onCancel }) {
	const [name, setName] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("Full Body");
	const [mode, setMode] = (0, import_react.useState)("reps");
	const [difficulty, setDifficulty] = (0, import_react.useState)("E");
	const [link, setLink] = (0, import_react.useState)(null);
	const [instructions, setInstructions] = (0, import_react.useState)("");
	const [sets, setSets] = (0, import_react.useState)(3);
	const [reps, setReps] = (0, import_react.useState)(8);
	const [hold, setHold] = (0, import_react.useState)(30);
	const [rest, setRest] = (0, import_react.useState)(60);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "sys-panel grid gap-3 p-4",
		onSubmit: (event) => {
			event.preventDefault();
			onSubmit({
				name,
				category,
				mode,
				link,
				instructions,
				difficulty,
				defaultSets: sets,
				defaultReps: mode === "reps" ? reps : 0,
				defaultHold: mode === "hold" ? hold : 0,
				defaultRest: rest
			});
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Custom exercise"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: "Name",
				value: name,
				maxLength: 40,
				required: true,
				onChange: (e) => setName(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: category,
						onChange: (e) => setCategory(e.target.value),
						children: CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						value: mode,
						onChange: (e) => setMode(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "reps",
							children: "Reps"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "hold",
							children: "Hold"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field",
						value: difficulty,
						onChange: (e) => setDifficulty(e.target.value),
						children: [
							"E",
							"D",
							"C",
							"B",
							"A",
							"S"
						].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "field",
						value: link ?? "",
						onChange: (e) => setLink(e.target.value || null),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "No quest link"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "push",
								children: "Push"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "squat",
								children: "Squat"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "pull",
								children: "Pull"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "plank",
								children: "Plank"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "mobility",
								children: "Mobility"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: "field min-h-24",
				placeholder: "Instructions",
				maxLength: 240,
				value: instructions,
				onChange: (e) => setInstructions(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "number",
						min: 1,
						max: 8,
						value: sets,
						onChange: (e) => setSets(Number(e.target.value)),
						"aria-label": "Sets"
					}),
					mode === "reps" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "number",
						min: 1,
						max: 50,
						value: reps,
						onChange: (e) => setReps(Number(e.target.value)),
						"aria-label": "Reps"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "number",
						min: 5,
						max: 180,
						value: hold,
						onChange: (e) => setHold(Number(e.target.value)),
						"aria-label": "Hold seconds"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "number",
						min: 10,
						max: 180,
						value: rest,
						onChange: (e) => setRest(Number(e.target.value)),
						"aria-label": "Rest seconds"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
					type: "submit",
					children: "Save exercise"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
					variant: "ghost",
					onClick: onCancel,
					children: "Cancel"
				})]
			})
		]
	});
}
var ClockContext = (0, import_react.createContext)(null);
function ClockProvider({ children }) {
	const pump = useArise((s) => s.pump);
	const nowRef = (0, import_react.useRef)(Date.now());
	const subs = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const api = (0, import_react.useMemo)(() => ({
		now: () => nowRef.current,
		subscribe: (fn) => {
			subs.current.add(fn);
			return () => subs.current.delete(fn);
		}
	}), []);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			nowRef.current = Date.now();
			pump();
			subs.current.forEach((fn) => fn());
		}, 250);
		return () => window.clearInterval(id);
	}, [pump]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockContext.Provider, {
		value: api,
		children
	});
}
function useNow() {
	const clock = (0, import_react.useContext)(ClockContext);
	const [now, setNow] = (0, import_react.useState)(() => clock?.now() ?? Date.now());
	(0, import_react.useEffect)(() => {
		if (!clock) return;
		return clock.subscribe(() => setNow(clock.now()));
	}, [clock]);
	return now;
}
function SessionScreen({ data }) {
	const session = data.session;
	const now = useNow();
	const logReps = useArise((s) => s.logReps);
	const startHold = useArise((s) => s.startHold);
	const finishHold = useArise((s) => s.finishHold);
	const restSkip = useArise((s) => s.restSkip);
	const restAdjust = useArise((s) => s.restAdjust);
	const skipCurrent = useArise((s) => s.skipCurrent);
	const extractMission = useArise((s) => s.extractMission);
	const [reps, setReps] = (0, import_react.useState)(10);
	const [showHow, setShowHow] = (0, import_react.useState)(false);
	const item = session?.items[session.index];
	const doneCount = item?.sets.filter((set) => set.done).length ?? 0;
	(0, import_react.useEffect)(() => {
		if (item?.mode === "reps") setReps(item.targetReps);
		setShowHow(false);
	}, [
		item?.exerciseId,
		item?.mode,
		item?.targetReps,
		session?.index,
		doneCount
	]);
	if (!session || !item) return null;
	const resting = session.restEndsAt != null && now < session.restEndsAt;
	const restLeft = resting ? Math.ceil((session.restEndsAt - now) / 1e3) : 0;
	const holding = item.holdEndsAt != null && item.holdStartedAt != null;
	const holdLeft = holding ? Math.max(0, Math.ceil((item.holdEndsAt - now) / 1e3)) : item.targetHold;
	const cleared = session.items.filter((row) => row.skipped || row.sets.every((set) => set.done)).length;
	const elapsed = Math.max(0, Math.floor((now - session.startedAt) / 1e3));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Combat mission"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-3xl",
					children: session.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mist",
					children: formatClock$1(elapsed)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "xp-track",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "xp-fill",
					style: { transform: `scaleX(${cleared / session.items.length})` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mist",
				children: [
					"Target ",
					session.index + 1,
					" / ",
					session.items.length,
					" · ",
					session.xp,
					" XP earned · ",
					session.prs.length ? `Records: ${session.prs.join(", ")}` : "No records yet"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: `kicker ${diffTone(item.difficulty)}`,
					children: [
						item.category,
						" · ",
						item.difficulty,
						"-RANK"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mt-2 text-4xl",
					children: item.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-mist",
					children: [
						"Set ",
						Math.min(doneCount + 1, item.sets.length),
						" / ",
						item.sets.length,
						item.mode === "reps" ? ` · target ${item.targetReps} reps` : ` · target ${item.targetHold}s`
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex gap-2",
					children: item.sets.map((set, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-2 flex-1 ${set.done ? "bg-cyan" : "bg-blue/20"}` }, i))
				}),
				resting ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "Rest"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display mt-2 text-6xl text-cyan",
							children: restLeft
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap justify-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
									variant: "ghost",
									onClick: () => restAdjust(-15),
									children: "−15s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
									onClick: restSkip,
									children: "Skip rest"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
									variant: "ghost",
									onClick: () => restAdjust(15),
									children: "+15s"
								})
							]
						})
					]
				}) : item.mode === "reps" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-6 grid gap-3",
					onSubmit: (event) => {
						event.preventDefault();
						logReps(reps);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm text-mist",
						children: ["Reps completed", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field text-center text-2xl",
							type: "number",
							min: 1,
							max: 80,
							value: reps,
							onChange: (e) => setReps(Number(e.target.value))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
						type: "submit",
						children: "Set cleared"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: holding ? "Hold" : "Ready"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display mt-2 text-6xl text-cyan",
							children: holdLeft
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-wrap justify-center gap-2",
							children: !holding ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
								onClick: startHold,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Start hold" })
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
								variant: "ghost",
								onClick: () => finishHold(true),
								children: "End early"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-4 min-h-11 text-sm text-cyan",
					onClick: () => setShowHow((v) => !v),
					children: showHow ? "Hide instructions" : "Instructions"
				}),
				showHow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-mist",
					children: item.instructions
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
					variant: "ghost",
					onClick: skipCurrent,
					children: "Skip exercise"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
					variant: "danger",
					onClick: extractMission,
					children: "Extract"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Extract keeps credit for sets already logged. A skipped exercise forfeits the clear bonus."
			})
		]
	});
}
function formatClock$1(total) {
	const m = Math.floor(total / 60);
	const s = total % 60;
	return `${m}:${String(s).padStart(2, "0")}`;
}
var BRANCHES = [
	"Strength",
	"Calisthenics",
	"Endurance",
	"Mobility"
];
function SkillsScreen({ data }) {
	const owned = data.skills.filter((skill) => skill.unlockedAt).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/art/shadows.jpg",
						alt: "",
						className: "h-36 w-full object-cover opacity-70"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-abyss via-abyss/30 to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-x-0 bottom-0 p-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "System // Skill tree"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "display text-3xl",
							children: "Skills"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mist",
				children: [
					owned,
					" / ",
					data.skills.length,
					" acquired. Locked skills open only when the training log crosses the line. No purchase. No shortcut."
				]
			}),
			BRANCHES.map((branch) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "kicker",
					children: branch
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 md:grid-cols-2",
					children: data.skills.filter((skill) => skill.branch === branch).map((skill) => {
						const progress = skillProgress(data, skill);
						const unlocked = Boolean(skill.unlockedAt);
						const pct = Math.min(1, progress.current / skill.threshold);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
							className: unlocked ? "border-cyan" : "opacity-80",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative h-16 w-16 shrink-0 overflow-hidden border border-blue/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: "/art/shadows.jpg",
											alt: "",
											className: `h-full w-full object-cover ${unlocked ? "opacity-90" : "opacity-30 grayscale"}`
										}), !unlocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "absolute inset-0 flex items-center justify-center text-cyan",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
												size: 16,
												"aria-hidden": true
											})
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "kicker",
												children: unlocked ? "Acquired" : "Sealed"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-lg font-semibold",
												children: skill.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm text-mist",
												children: unlocked ? skill.description : skill.requirement
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-cyan",
									children: progress.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "xp-track mt-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "xp-fill",
										style: { transform: `scaleX(${pct})` }
									})
								})
							]
						}, skill.id);
					})
				})]
			}, branch))
		]
	});
}
function DungeonsScreen({ data }) {
	const openGate = useArise((s) => s.openGate);
	const logObjective = useArise((s) => s.logObjective);
	const logBoss = useArise((s) => s.logBoss);
	const withdrawGate = useArise((s) => s.withdrawGate);
	const forgeGate = useArise((s) => s.forgeGate);
	const deleteGate = useArise((s) => s.deleteGate);
	const [lighter, setLighter] = (0, import_react.useState)(true);
	const [forging, setForging] = (0, import_react.useState)(false);
	const now = useNow();
	const run = data.dungeonRun;
	const gates = allDungeons(data);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/art/gate.jpg",
						alt: "A circular gate of cyan fire over a dark street",
						className: "h-40 w-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-abyss via-abyss/20 to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-x-0 bottom-0 p-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "System // Gates"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "display text-3xl",
							children: "Dungeons"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Volume is a ceiling, not a dare. The lighter gate is the default. Recovery seals every door. Log only what you completed."
			}),
			run && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "kicker",
					children: [
						"Active · ",
						run.rank,
						"-RANK ",
						run.lighter ? "· lighter" : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mt-1 text-2xl",
					children: run.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-mist",
					children: [
						runPercent(run),
						"% · ",
						formatClock(Math.floor((now - run.startedAt) / 1e3)),
						" · ",
						run.xp,
						" XP"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "xp-track mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "xp-fill",
						style: { transform: `scaleX(${runPercent(run) / 100})` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [run.objectives.map((objective) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ObjectiveRow, {
						label: objective.label,
						progress: objective.progress,
						target: objective.target,
						unit: objective.unit,
						done: objective.rewarded,
						onAdd: (delta) => logObjective(objective.id, delta)
					}, objective.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ObjectiveRow, {
						label: `${run.bossName} — ${run.bossLabel}`,
						progress: run.bossProgress,
						target: run.bossTarget,
						unit: run.bossUnit,
						done: run.bossRewarded,
						locked: !run.objectives.every((o) => o.progress >= o.target),
						onAdd: (delta) => logBoss(delta)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
					variant: "danger",
					className: "mt-4",
					onClick: withdrawGate,
					children: "Withdraw"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 items-center gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: lighter,
					onChange: (e) => setLighter(e.target.checked)
				}), "Enter on the lighter gate (about half volume, full credit)"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: gates.map((gate) => {
					const record = data.dungeonRecords[gate.id];
					const sealed = !gate.custom && data.player.level < gate.levelRequired;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: `kicker ${diffTone(gate.rank)}`,
							children: [
								gate.rank,
								"-RANK ",
								sealed ? `· level ${gate.levelRequired}` : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-xl font-semibold",
							children: gate.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-mist",
							children: gate.lore
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-3 grid gap-1 text-sm text-ink",
							children: [gate.objectives.map((objective) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: objective.label }, objective.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"Boss · ",
								gate.bossName,
								": ",
								gate.bossLabel
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-cyan",
							children: [
								"Clear +",
								gate.clearXp,
								" XP",
								record ? ` · ${record.clears} clear${record.clears === 1 ? "" : "s"}` : "",
								record?.bestSec ? ` · best ${formatClock(record.bestSec)}` : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
								disabled: sealed || Boolean(run) || data.player.recovery,
								onClick: () => openGate(gate.id, lighter),
								children: sealed ? "Sealed" : "Enter"
							}), gate.custom && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
								variant: "danger",
								onClick: () => deleteGate(gate.id),
								children: "Delete"
							})]
						})
					] }, gate.id);
				})
			}),
			forging ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ForgeForm, {
				onCancel: () => setForging(false),
				onSubmit: (def) => {
					forgeGate(def);
					setForging(false);
				}
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
				variant: "ghost",
				onClick: () => setForging(true),
				children: "Forge a gate"
			}),
			data.dungeonHistory.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "History"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-2 text-sm",
				children: [...data.dungeonHistory].reverse().slice(0, 8).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-3 border-b border-blue/20 pb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						row.name,
						" · ",
						row.rank,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-mist",
							children: [" ", row.cleared ? "cleared" : "withdrew"]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-mist",
						children: [
							formatClock(row.sec),
							" · ",
							row.xp,
							" XP"
						]
					})]
				}, row.id))
			})] })
		]
	});
}
function ObjectiveRow({ label, progress, target, unit, done, locked, onAdd }) {
	const step = unit === "sec" ? 15 : 5;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: locked ? "opacity-50" : void 0,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-mist",
					children: [
						progress,
						"/",
						target,
						unit === "sec" ? "s" : "",
						" ",
						done ? "· cleared" : "",
						" ",
						locked ? "· sealed" : ""
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "xp-track mt-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "xp-fill",
					style: { transform: `scaleX(${target ? progress / target : 0})` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SysButton, {
						variant: "ghost",
						className: "px-3",
						disabled: locked,
						onClick: () => onAdd(-step),
						children: ["−", step]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SysButton, {
						className: "px-3",
						disabled: locked || done,
						onClick: () => onAdd(step),
						children: ["+", step]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
						variant: "ghost",
						disabled: locked || done,
						onClick: () => onAdd(target - progress),
						children: "Finish"
					})
				]
			})
		]
	});
}
function ForgeForm({ onSubmit, onCancel }) {
	const [name, setName] = (0, import_react.useState)("Unnamed Gate");
	const [rank, setRank] = (0, import_react.useState)("E");
	const [a, setA] = (0, import_react.useState)("20 Push-ups");
	const [b, setB] = (0, import_react.useState)("20 Squats");
	const [boss, setBoss] = (0, import_react.useState)("Final effort");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "sys-panel grid gap-3 p-4",
		onSubmit: (event) => {
			event.preventDefault();
			const id = uid("gate");
			onSubmit({
				id,
				name: name.trim().slice(0, 40) || "Unnamed Gate",
				rank,
				levelRequired: 1,
				lore: "A gate you forged. Keep the targets honest.",
				custom: true,
				clearXp: 100,
				bossName: "Warden",
				bossLabel: boss.trim().slice(0, 40) || "Final effort",
				bossTarget: 15,
				bossUnit: "reps",
				bossXp: 40,
				bossLink: null,
				objectives: [{
					id: `${id}-a`,
					label: a.trim().slice(0, 40) || "Objective A",
					target: 20,
					unit: "reps",
					xp: 30,
					link: "push"
				}, {
					id: `${id}-b`,
					label: b.trim().slice(0, 40) || "Objective B",
					target: 20,
					unit: "reps",
					xp: 30,
					link: "squat"
				}]
			});
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Forge"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Two objectives, twenty reps each, and a fifteen-rep boss. Caps stay low on purpose."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				value: name,
				maxLength: 40,
				onChange: (e) => setName(e.target.value),
				"aria-label": "Gate name"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: "field",
				value: rank,
				onChange: (e) => setRank(e.target.value),
				"aria-label": "Rank",
				children: DIFFICULTIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				value: a,
				maxLength: 40,
				onChange: (e) => setA(e.target.value),
				"aria-label": "First objective"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				value: b,
				maxLength: 40,
				onChange: (e) => setB(e.target.value),
				"aria-label": "Second objective"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				value: boss,
				maxLength: 40,
				onChange: (e) => setBoss(e.target.value),
				"aria-label": "Boss label"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
					type: "submit",
					children: "Forge"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
					variant: "ghost",
					onClick: onCancel,
					children: "Cancel"
				})]
			})
		]
	});
}
function formatClock(total) {
	const m = Math.floor(total / 60);
	const s = total % 60;
	return `${m}:${String(s).padStart(2, "0")}`;
}
function ProfileScreen({ data }) {
	const setIdentity = useArise((s) => s.setIdentity);
	const toggleSound = useArise((s) => s.toggleSound);
	const toggleRecovery = useArise((s) => s.toggleRecovery);
	const setRecoveryNote = useArise((s) => s.setRecoveryNote);
	const addMeasure = useArise((s) => s.addMeasure);
	const importSave = useArise((s) => s.importSave);
	const resetAll = useArise((s) => s.resetAll);
	const [name, setName] = (0, import_react.useState)(data.player.name);
	const [title, setTitle] = (0, import_react.useState)(data.player.title);
	const [weight, setWeight] = (0, import_react.useState)("");
	const [sleep, setSleep] = (0, import_react.useState)("");
	const [fatigue, setFatigue] = (0, import_react.useState)(2);
	const [soreness, setSoreness] = (0, import_react.useState)(2);
	const [note, setNote] = (0, import_react.useState)(data.player.recoveryNote);
	const [importError, setImportError] = (0, import_react.useState)(null);
	const [armed, setArmed] = (0, import_react.useState)(false);
	const rank = rankLabel(data);
	const buckets = weekBuckets(data.logs);
	const weights = data.measures.filter((m) => m.weightKg != null).slice(-12).map((m) => ({
		label: new Date(m.at).toLocaleDateString(void 0, {
			month: "numeric",
			day: "numeric"
		}),
		kg: m.weightKg
	}));
	const records = data.exercises.filter((exercise) => exercise.prReps > 0 || exercise.prHold > 0);
	const goals = nationalGoals(data);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "System // Profile"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display mt-1 text-3xl",
				children: "Profile"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `kicker ${rankTone(rank.code)}`,
					children: rank.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 grid gap-3",
					onSubmit: (event) => {
						event.preventDefault();
						setIdentity(name, title);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm text-mist",
							children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								value: name,
								maxLength: 24,
								onChange: (e) => setName(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm text-mist",
							children: ["Title", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field",
								value: title,
								maxLength: 32,
								onChange: (e) => setTitle(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							type: "submit",
							children: "Update identity"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-mist",
					children: [
						"Level ",
						data.player.level,
						" · lifetime ",
						data.player.lifetimeXp,
						" XP · ",
						data.player.totalWorkouts,
						" workouts · streak ",
						data.player.streak
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "National level"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-2 text-sm",
				children: goals.map((goal) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: goal.done ? "text-cyan" : "text-mist",
						children: goal.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-ink",
						children: goal.done ? "Done" : goal.detail || "Open"
					})]
				}, goal.label))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Recovery"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-mist",
					children: "Pauses gate entry and streak loss. Quests can still be suspended one by one."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
					variant: data.player.recovery ? "legend" : "ghost",
					onClick: toggleRecovery,
					children: data.player.recovery ? "Active" : "Off"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-3 grid gap-1 text-sm text-mist",
				children: ["Note", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: note,
					maxLength: 140,
					onChange: (e) => setNote(e.target.value),
					onBlur: () => setRecoveryNote(note)
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Body and recovery log"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 grid gap-3",
					onSubmit: (event) => {
						event.preventDefault();
						const weightKg = weight.trim() === "" ? null : Number(weight);
						const sleepH = sleep.trim() === "" ? null : Number(sleep);
						addMeasure({
							weightKg: weightKg != null && Number.isFinite(weightKg) ? Math.min(400, Math.max(20, weightKg)) : null,
							sleepH: sleepH != null && Number.isFinite(sleepH) ? Math.min(16, Math.max(0, sleepH)) : null,
							fatigue,
							soreness,
							note
						});
						setWeight("");
						setSleep("");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-1 text-sm text-mist",
								children: ["Weight (kg)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field",
									inputMode: "decimal",
									value: weight,
									onChange: (e) => setWeight(e.target.value)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-1 text-sm text-mist",
								children: ["Sleep (hours)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field",
									inputMode: "decimal",
									value: sleep,
									onChange: (e) => setSleep(e.target.value)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Range, {
							label: "Fatigue",
							value: fatigue,
							onChange: setFatigue
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Range, {
							label: "Soreness",
							value: soreness,
							onChange: setSoreness
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							type: "submit",
							children: "File measurement"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 grid gap-2 text-sm",
					children: [[...data.measures].reverse().slice(0, 6).map((measure) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "text-mist",
						children: [
							new Date(measure.at).toLocaleDateString(),
							" · ",
							measure.weightKg != null ? `${measure.weightKg} kg` : "no weight",
							" · sleep ",
							measure.sleepH ?? "—",
							"h · fatigue ",
							measure.fatigue,
							" · sore ",
							measure.soreness
						]
					}, measure.id)), data.measures.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-mist",
						children: "No measurements yet."
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Training minutes · 8 weeks"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-48",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
						data: buckets,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "label",
								stroke: "var(--color-mist)",
								fontSize: 12,
								tickLine: false,
								axisLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								stroke: "var(--color-mist)",
								fontSize: 12,
								tickLine: false,
								axisLine: false,
								width: 28
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
								background: "var(--color-panel)",
								border: "1px solid var(--color-blue)",
								color: "var(--color-ink)"
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
								dataKey: "minutes",
								stroke: "#63D9FF",
								fill: "#258BFF",
								fillOpacity: .25
							})
						]
					})
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Rep volume · 8 weeks"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-48",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: buckets,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "label",
									stroke: "var(--color-mist)",
									fontSize: 12,
									tickLine: false,
									axisLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									stroke: "var(--color-mist)",
									fontSize: 12,
									tickLine: false,
									axisLine: false,
									width: 32
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									background: "var(--color-panel)",
									border: "1px solid var(--color-blue)",
									color: "var(--color-ink)"
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "reps",
									fill: "#258BFF"
								})
							]
						})
					})
				}),
				data.logs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-mist",
					children: "Charts fill in after the first logged mission."
				})
			] }),
			weights.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Bodyweight"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-48",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
						data: weights,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "label",
								stroke: "var(--color-mist)",
								fontSize: 12,
								tickLine: false,
								axisLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								stroke: "var(--color-mist)",
								fontSize: 12,
								tickLine: false,
								axisLine: false,
								width: 32,
								domain: ["dataMin - 1", "dataMax + 1"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
								background: "var(--color-panel)",
								border: "1px solid var(--color-blue)",
								color: "var(--color-ink)"
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
								dataKey: "kg",
								stroke: "#D6A7FF",
								fill: "#D6A7FF",
								fillOpacity: .2
							})
						]
					})
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Personal records"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 grid gap-2 text-sm",
				children: [records.map((exercise) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: exercise.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-cyan",
						children: exercise.prReps > 0 ? `${exercise.prReps} reps` : `${exercise.prHold}s`
					})]
				}, exercise.id)), records.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-mist",
					children: "Records appear when a logged set beats the previous best."
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "System data"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							variant: "ghost",
							onClick: () => {
								const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
								const url = URL.createObjectURL(blob);
								const link = document.createElement("a");
								link.href = url;
								link.download = `arise-${data.daily.date}.json`;
								link.click();
								URL.revokeObjectURL(url);
							},
							children: "Export"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "inline-flex min-h-11 cursor-pointer items-center border border-blue/50 px-4 text-cyan",
							children: ["Import", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "application/json",
								className: "sr-only",
								onChange: async (event) => {
									const file = event.target.files?.[0];
									event.target.value = "";
									if (!file) return;
									const text = await file.text();
									setImportError(importSave(text));
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SysButton, {
							variant: data.settings.sound ? "primary" : "ghost",
							onClick: toggleSound,
							children: ["Sound ", data.settings.sound ? "on" : "off"]
						})
					]
				}),
				importError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-danger",
					children: importError
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [armed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							variant: "danger",
							onClick: resetAll,
							children: "Confirm wipe"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
							variant: "ghost",
							onClick: () => setArmed(false),
							children: "Cancel"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
						variant: "danger",
						onClick: () => setArmed(true),
						children: "Reset system"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-mist",
						children: "Reset erases this device's record. Export first if you want it back."
					})]
				})
			] })
		]
	});
}
function Range({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between text-sm text-mist",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-ink",
			children: [value, "/5"]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: "mt-1 w-full accent-blue",
		type: "range",
		min: 0,
		max: 5,
		value,
		onChange: (e) => onChange(Number(e.target.value))
	})] });
}
var TABS = [
	{
		id: "home",
		label: "Home",
		icon: Shield
	},
	{
		id: "quests",
		label: "Quests",
		icon: ScrollText
	},
	{
		id: "workout",
		label: "Workout",
		icon: Swords
	},
	{
		id: "skills",
		label: "Skills",
		icon: Sparkles
	},
	{
		id: "dungeons",
		label: "Dungeons",
		icon: Castle
	},
	{
		id: "profile",
		label: "Profile",
		icon: UserRound
	}
];
function AriseApp() {
	const ready = useArise((s) => s.ready);
	const boot = useArise((s) => s.boot);
	(0, import_react.useEffect)(() => {
		boot();
	}, [boot]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {}) });
}
function BootScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "vignette relative flex min-h-dvh items-center justify-center overflow-hidden px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "boot-scan pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-transparent via-cyan/20 to-transparent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Establishing link"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-3 text-5xl text-ink",
					children: "ARISE"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-mist",
					children: "The Player System"
				})
			]
		})]
	});
}
function Shell() {
	const data = useArise((s) => s.data);
	const tab = useArise((s) => s.tab);
	const setTab = useArise((s) => s.setTab);
	const notices = useArise((s) => s.notices);
	const dismissNotice = useArise((s) => s.dismissNotice);
	const levelUps = useArise((s) => s.levelUps);
	const dismissLevel = useArise((s) => s.dismissLevel);
	const reduce = useReducedMotion();
	const notice = notices[0];
	const level = levelUps[0];
	const inMission = Boolean(data.session);
	(0, import_react.useEffect)(() => {
		if (!notice) return;
		const id = window.setTimeout(dismissNotice, 3200);
		return () => window.clearTimeout(id);
	}, [notice, dismissNotice]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "vignette min-h-dvh text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Particles, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "scanlines pointer-events-none fixed inset-0 z-[1]",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex min-h-dvh max-w-5xl md:pl-52",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "fixed inset-y-0 left-0 z-20 hidden w-52 flex-col border-r border-blue/30 bg-panel/90 px-3 py-6 md:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display px-2 text-xl",
							children: "ARISE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker px-2",
							children: "Player system"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "mt-8 grid gap-1",
							children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								item,
								active: tab === item.id,
								onClick: () => setTab(item.id)
							}, item.id))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: `relative z-10 w-full px-4 pt-5 ${inMission ? "pb-8" : "pb-28 md:pb-10"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
						mode: "wait",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							initial: reduce ? false : {
								opacity: 0,
								y: 10
							},
							animate: {
								opacity: 1,
								y: 0
							},
							exit: reduce ? void 0 : {
								opacity: 0,
								y: -8
							},
							transition: { duration: .22 },
							children: inMission ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionScreen, { data }) : tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, { data }) : tab === "quests" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestsScreen, { data }) : tab === "workout" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkoutScreen, { data }) : tab === "skills" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillsScreen, { data }) : tab === "dungeons" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DungeonsScreen, { data }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileScreen, { data })
						}, inMission ? "mission" : tab)
					})
				})]
			}),
			!inMission && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-blue/30 bg-panel/95 backdrop-blur md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-6",
					children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
						item,
						active: tab === item.id,
						compact: true,
						onClick: () => setTab(item.id)
					}, item.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: notice && !level && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					y: -12
				},
				animate: {
					opacity: 1,
					y: 0
				},
				exit: {
					opacity: 0,
					y: -8
				},
				className: "fixed inset-x-4 top-4 z-40 mx-auto max-w-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "sys-toast",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "[ System ]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-lg font-semibold",
							children: notice.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-mist",
							children: notice.body
						})
					]
				})
			}, notice.id) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: level && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: reduce ? false : { opacity: 0 },
				animate: { opacity: 1 },
				exit: reduce ? void 0 : { opacity: 0 },
				className: "fixed inset-0 z-50 flex items-center justify-center bg-abyss/85 px-6 backdrop-blur-sm",
				children: [!reduce && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "level-ring",
					"aria-hidden": true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "level-ring late",
					"aria-hidden": true
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					className: "relative w-full max-w-sm",
					initial: reduce ? false : {
						scale: .86,
						opacity: 0
					},
					animate: {
						scale: 1,
						opacity: 1
					},
					transition: {
						type: "spring",
						stiffness: 260,
						damping: 22
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: "[ System ]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "display mt-3 text-5xl text-cyan",
								children: "Level up"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "display mt-2 text-7xl",
								children: String(level.level).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-legend",
								children: level.rankUp ? `Rank ascended · ${level.rank}` : level.rank
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-mist",
								children: "3 stat points have been granted. Place them on the status window."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
								className: "mt-5 w-full",
								onClick: dismissLevel,
								children: "Accept"
							})
						]
					})
				})]
			}, level.id) }),
			!data.seenIntro && !inMission && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Intro, {})
		]
	});
}
function NavButton({ item, active, compact, onClick }) {
	const Icon = item.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		"aria-current": active ? "page" : void 0,
		className: `relative flex min-h-11 items-center gap-2 px-2 py-2 text-xs ${compact ? "flex-col justify-center" : "w-full"} ${active ? "text-cyan" : "text-mist"}`,
		children: [
			active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: compact ? "absolute inset-x-3 top-0 h-0.5 bg-cyan" : "absolute inset-y-2 left-0 w-0.5 bg-cyan",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				size: 18,
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })
		]
	});
}
function Intro() {
	const acceptProtocol = useArise((s) => s.acceptProtocol);
	const dismissIntro = useArise((s) => s.dismissIntro);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40 overflow-y-auto bg-abyss",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/art/hunter.jpg",
				alt: "",
				className: "absolute inset-0 h-full w-full object-cover opacity-40"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-abyss via-abyss/75 to-abyss" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "boot-scan pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-transparent via-cyan/30 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative flex min-h-dvh items-end px-4 py-8 sm:items-center sm:justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "[ System ]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display mt-3 text-5xl",
							children: "You have awakened."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-mist",
							children: "The Player System is online. Rank moves only when the work is real. The standard board is 30 push-ups, 40 squats, 10 pull-ups, a 60-second plank, and 10 minutes of mobility."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-mist",
							children: "Choose the volume your body can finish cleanly. Pain is a stop, not a quest."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
									variant: "ghost",
									onClick: () => acceptProtocol("awakening"),
									children: "Awakening — lighter"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
									onClick: dismissIntro,
									children: "Accept standard"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SysButton, {
									variant: "legend",
									onClick: () => acceptProtocol("monarch"),
									children: "Monarch — harder"
								})
							]
						})
					]
				})
			})
		]
	});
}
function Particles() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const dots = Array.from({ length: 36 }, () => ({
			x: Math.random(),
			y: Math.random(),
			r: Math.random() * 1.4 + .4,
			s: Math.random() * 25e-5 + 8e-5
		}));
		let frame = 0;
		const draw = () => {
			const width = canvas.clientWidth;
			const height = canvas.clientHeight;
			if (canvas.width !== width || canvas.height !== height) {
				canvas.width = width;
				canvas.height = height;
			}
			ctx.clearRect(0, 0, width, height);
			for (const dot of dots) {
				dot.y -= dot.s;
				if (dot.y < 0) dot.y = 1;
				ctx.beginPath();
				ctx.fillStyle = "rgba(99, 217, 255, 0.45)";
				ctx.arc(dot.x * width, dot.y * height, dot.r, 0, Math.PI * 2);
				ctx.fill();
			}
			frame = window.requestAnimationFrame(draw);
		};
		frame = window.requestAnimationFrame(draw);
		return () => window.cancelAnimationFrame(frame);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		className: "pointer-events-none fixed inset-0 z-0 h-full w-full",
		"aria-hidden": true
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AriseApp, {});
}
//#endregion
export { Home as component };
